// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

/**
 * UAT ENVIRONMENT : L3
 */
export const environment = {
  production: false,
  URL: 'https://knight.emea.fedex.com:443/uat/',
  TNT_URL: 'https://knight.emea.fedex.com/digital/',
  SPIRIT_TOKEN_URL: 'https://knight.emea.fedex.com:8443/',
  FDX_TOKEN_URL: 'https://apidrt.idev.fedex.com:8443/',
  CONST_LOGIN: 'https://apidrt.idev.fedex.com:8443',
  CONST_AUTH_TOKEN_CLIENT_ID: '9866dc5c-6657-4af5-9288-7caa1666d7c0',
  CONST_AUTH_TOKEN_CLIENT_SECRET: '808bbd07-9896-445b-8f54-bbe989663ed0',
  CONST_FDX_AUTH_TOKEN_CLIENT_ID: 'l7xx8471591940a34c5989dcad05abce4060',
  CONST_FDX_AUTH_TOKEN_CLIENT_SECRET: '0087dd9fd7704afdba692cfe7e36fa71',
  GOOGLE_CHANNEL_ID: 'spiritL3',
};
