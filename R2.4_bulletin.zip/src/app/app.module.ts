/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* Fedex 2018
 *
 * Typescript code in this page
 */
import { LabelsAndEmailsService } from './services/labels-and-emails.service';
import { RouterGuardService } from './services/router-guard.service';
import { BookingService } from './services/booking.service';
import { CommonSharedModule } from './shared/shared.module';
import { LoginService } from './services/login.service';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { routing } from './app.routes';
import { ComponentsModule } from './components/components.module';
import { HeaderComponent } from './components/header/header.component';
import { ApiService } from './services/api.service';
import { SharedataService } from './services/sharedata.service';
import { TemplateService } from './services/template.service';
import { FedexAddressbookService } from './services/fedex-addressbook.service';
import { TokenService } from './services/token.service';
import { BookingModule } from './booking/booking.module';
import { AngularMaterialModule } from './angular-material.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BaseService } from './services/base.service';
import { JsEncoderService } from './services/js-encoder.service';
import { ProductsOfferedService } from './services/products-offered.service';
import { AllPrivilegesService } from './services/privilege/allprivileges.service';
import { FedexLogonService } from './services/fedex-logon.service';
import { AddressbookPrivilegeService } from './services/privilege/addressbook-privilege.service';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent
  ],
  imports: [
    HttpModule,
    HttpClientModule,
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    ComponentsModule,
    routing,
    CommonSharedModule,
    BookingModule,
    AngularMaterialModule
  ],
  providers: [SharedataService,
    FedexLogonService,
    RouterGuardService,
    TemplateService,
    FedexAddressbookService,
    TokenService,
    ApiService,
    LoginService,
    BookingService,
    LabelsAndEmailsService,
    ProductsOfferedService,
    JsEncoderService,
    AddressbookPrivilegeService,
    AllPrivilegesService,
    BaseService],
  bootstrap: [AppComponent]
})
export class AppModule { }
