/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { PipeTransform, Pipe } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Pipe({ name: 'highlight' })
export class HighlightPipe implements PipeTransform {
    constructor(public sanitizer: DomSanitizer) {
    }
    transform(text: string, search): SafeHtml {
        if (search && text) {

            let pattern = search.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, '\\$&');
            pattern = pattern.split(' ').filter((t) => {
                return t.length > 0;
            }).join('|');

            const regex = new RegExp(pattern, 'gi');
            const castText = text.toString();
            return this.sanitizer.bypassSecurityTrustHtml(
                castText.replace(regex, (match) =>
                    `<mark style='background: #f5d3ff; padding:0'>${match}</mark>`
                )
            );
        } else {
            return text;
        }
    }
}
