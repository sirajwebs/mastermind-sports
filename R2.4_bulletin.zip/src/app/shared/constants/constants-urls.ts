/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* Fedex 2018
 *
 * Typescript code in this page
 */

import { environment } from '../../../environments/environment';

const URL = environment.URL;

const SPIRIT_V1 = 'spirit/v1';
const ROOT_BOOKINGS = SPIRIT_V1 + '/bookings';
const ROOT_TEMPLATES = SPIRIT_V1 + '/templates';
const OAUTH = 'auth/oauth/v2/token';

const TNT_URL = environment.TNT_URL;
const SPIRIT_TOKEN_URL = environment.SPIRIT_TOKEN_URL;
const FDX_TOKEN_URL = environment.FDX_TOKEN_URL;

export const ConstantsURL = {
    GOOGLE_APIS: 'https://maps.googleapis.com/maps/api/timezone/json?location=',
    // GOOGLE_CLIENT_ID: 'gme-fedexcorporation1',
    GOOGLE_API_KEY: 'AIzaSyAoJDZEpagoRZtbfgQmjcL9BH1QXIUEg1E',
    GOOGLE_CHANNEL_ID: environment.GOOGLE_CHANNEL_ID,
    GOOGLE_ROOT_URL: 'https://maps.googleapis.com/maps/api/js?v=3',
    GOOGLE_ROOT_URL_KEY: '&key=',
    GOOGLE_ROOT_URL_CHANNEL: '&channel=',
    GOOGLE_ROOT_URL_ENDPOINT: '&libraries=places&language=en',
    // GOOGLE_GET_SIGNATURE: URL + ROOT_BOOKINGS +'/signature',
    // GOOGLE_CLIENT_SIGNATURE: '&signature=',

    // Google geocode url
    GOOGLE_GEOCODE_ROOT_URL: 'https://maps.googleapis.com/maps/api/geocode/json?',
    GOOGLE_GEOCODE_ROOT_URL_COMPONENT: '&components=country:',

    CONST_INBOUND_BOOKING: URL + ROOT_BOOKINGS + '/',
    CONST_TEMPLATE_CONTEXT: URL + ROOT_TEMPLATES + '/',
    CONST_CREATE_TEMPLATE_DROPDOWN_SERVICE_LIST_URL: URL + ROOT_TEMPLATES + '/services/',
    CONST_CREATE_TEMPLATE_DROPDOWN_PACKAGE_LIST_URL: URL + ROOT_TEMPLATES + '/packages/',
    CONST_CREATE_TEMPLATE_SAVE_TEMPLATE_URL: URL + ROOT_TEMPLATES + '/new',
    CONST_UPDATE_EDIT_TEMPLATE: 'alter',
    CONST_FETCH_TEMPLATE_DETAILS_URL: URL + ROOT_TEMPLATES + '/',
    CONST_FETCH_BOOKING_EDIT_DETAILS_URL: URL + ROOT_BOOKINGS + '/',
    CONST_TEMPLATE_LIST_DASHBOARD_URL: URL + ROOT_TEMPLATES + '/dashboard',
    CONST_MAKE_TEMPLATE_DEFAULT_URL: '/default/?customer_no=',
    CONST_ACT_DEACT_TEMPLATE_URL: '/status/?status=',
    CONST_DELETE_SERVICE: '/archive',
    CONST_DUPLICATE_TEMPLATE: '/duplicate?template_name=',
    CONST_SAVE_NEW_BOOKING_URL: URL + ROOT_BOOKINGS + '/new',
    CONST_UPDATE_BOOKING_URL: URL + ROOT_BOOKINGS + '/alter',
    CONST_SAVE_AS_DRAFT_BOOKING_URL: URL + ROOT_BOOKINGS + '/draft',
    CONST_BOOKING_LIST_DASHBOARD_URL: URL + ROOT_BOOKINGS + '/dashboard',
    CONST_GENERATE_BOOKINGREF_URL: 'generator/sid?template_id=',
    CONST_CHECK_BOOKINGREF_URL: 'validator/sid?customer_no=',
    CONST_CHECK_BOOKINGREF_CHILDURL: '&same_booking_name=',
    CONST_CHECK_BOOKINGREF_CHILD_2_URL: '&booking_name=',
    CONST_DEFAULT_SERVICES: URL + SPIRIT_V1 + '/exconnect/pricing/products-offered',
    CONST_GET_DEFAULT_SERVICE_URL: '/default_service',
    CONST_VALIDATE_CITY_CHILD_URL: '&limit=10000&postCode=',
    CONST_VALIDATE_CITY_CHILD_NOPOSTAL: '&limit=10000&q=',
    CONST_CHECK_CUSTOMER_REF: 'validator/customer?customer_no=',
    CONST_CHECK_CONTENT_REF: 'validator/content?content_ref_no=',
    CONST_CNF_DATE_PICKUP_URL: URL + ROOT_BOOKINGS + '/dates/pickup',
    CONST_ASC_DASHBOARD_1: URL + ROOT_BOOKINGS + '/dashboard-asc',
    CONST_ASC_DASHBOARD_2: 'newest_top=',
    CONST_CMPLTE_BKNG_DASHBOARD: URL + ROOT_BOOKINGS + '/complete',
    CONST_EXPECT_DUE_DT: URL + ROOT_BOOKINGS + '/date/due',
    CONST_GET_BOOKING_LABELS_2: '/labels',
    CONST_BOOKING_NOTIFY: URL + ROOT_BOOKINGS + '/notify',
    CONST_TRIGGER_EMAIL: URL + ROOT_BOOKINGS + '/email',
    CONST_RESEND_EMAIL: URL + ROOT_BOOKINGS + '/email/resend',
    CONST_RESEND_ASC_EMAIL: URL + ROOT_BOOKINGS + '/email/resend-asc',
    CONST_BOOKING_EXISTS: URL + ROOT_BOOKINGS + '/exists',
    CONST_TEMPLATE_EXISTS: URL + ROOT_TEMPLATES + '/exists',
    CONST_CHECK_TEMPLATE_NAME: URL + ROOT_TEMPLATES + '/validator',
    CONST_TEMPLATE_BASIC_CREATE: URL + ROOT_TEMPLATES + '/wizard',
    CONST_BOOKING_SEARCH: URL + ROOT_BOOKINGS + '/search',
    CONST_BOOKING_DOWNLOAD: URL + ROOT_BOOKINGS + '/paperwork',
    CONST_TEMP_DELETE_GET: '/archive/validator?customer_no=',
    CONST_TEMP_BOOKING_DELETE: '/archive/booking?customer_no=',
    CONST_TNT_TRACKER: 'http://webtracker.tnt.com/webtracker/tracking.do?respLang=EN',
    CONST_TNT_TRACKER_RES_CNTRY: '&respCountry=',
    CONT_TNT_TRACKER_CON_NO: '&searchType=CON&cons=',
    CONST_PRINT_URL: '/print',
    CONST_PRINT_URL_BID: '#/print?bId=',
    CONST_MULTIPLE_BOOKINGS_URL_WITH_PARAM: '/multiple-bookings?',
    CONST_UPLOAD_BOOKING_URL: URL + SPIRIT_V1 + '/edi/upload',
    CONST_UPLOAD_BOOKING_DOWNLOAD_URL: URL + SPIRIT_V1 + '/edi/download',
    CONST_UPLOADED_BOOKING_LIST_URL: URL + SPIRIT_V1 + '/edi/dashboard?user=',
    FORGET_PASSWORD_LINK: 'https://www.fedex.com/fcl/web/jsp/forgotPassword.jsp?appName=fclfsm&locale=' + 'en_US',

    CONST_LOGIN_URL: '/login',
    CONST_LOGIN_V2: '/user/v2/login/validate',
    CONST_LOGOUT_V1: '/user/v1/logout',
    CONST_LOGIN_ACTC: '/account/v1/associatedaccounts/search',
    CONST_LOGIN: environment.CONST_LOGIN,

    // fedex-login integration
    CONST_SHIPADMIN_INFO_V1: '/administration/v1/shipadmininfo',
    CONST_ADMINISTRATION_USERS_V1: '/administration/v1/users/',
    CONST_PRIVILEGE_V1: '/privileges',

    // FEDEX ADDRESS BOOK
    FEDEX_ADDRESS_BOOK: {
        SEARCH: environment.CONST_LOGIN + '/contact/v3/addressbooks/contacts/search',
        SAVE: environment.CONST_LOGIN + '/contact/v2/parties',
        GET: environment.CONST_LOGIN + '/contact/v2/parties/',
        EMAIL: {
            URL: environment.CONST_LOGIN + '/contact/v2/parties/',
            PREFERENCES: '/preferences'
        }
    },

    CONST_COUNTRY_POSTAL_CHECK: TNT_URL + 'country/v1/countryprofile?channel=MYTNT&countrycode=',  // tnt
    CONST_VALIDATE_CITY: TNT_URL + 'address/v2/towns?countryCode=', // tnt
    CONST_VALIDATE_CITY_NOPOSTAL: TNT_URL + 'address/v2/location?countryCode=',  // tnt

    // TOKEN -----------
    CONST_AUTH_TOKEN_URL: SPIRIT_TOKEN_URL + OAUTH,
    CONST_FEDEX_AUTH_TOKEN_URL: FDX_TOKEN_URL + OAUTH,

    // OAUTH KEYS ------------
    CONST_AUTH_TOKEN_CLIENT_ID: environment.CONST_AUTH_TOKEN_CLIENT_ID,
    CONST_AUTH_TOKEN_CLIENT_SECRET: environment.CONST_AUTH_TOKEN_CLIENT_SECRET,

    CONST_FDX_AUTH_TOKEN_CLIENT_ID: environment.CONST_FDX_AUTH_TOKEN_CLIENT_ID,
    CONST_FDX_AUTH_TOKEN_CLIENT_SECRET: environment.CONST_FDX_AUTH_TOKEN_CLIENT_SECRET,

    // FORGOT PASSWORD
    CONST_FORGOT_PASSWORD: 'https://www.fedex.com/fcl/web/jsp/forgotPassword.jsp?appName=fclfsm&locale=',
    CONST_LOCALE: 'en_US'
};

export const ConstantsURL_Others = {
    GOOGLE_SCRIPT_TAG: 'googleMapURL',
    GOOGLE_MAP_SCRIPT: ConstantsURL.GOOGLE_ROOT_URL + ConstantsURL.GOOGLE_ROOT_URL_KEY + ConstantsURL.GOOGLE_API_KEY
        + ConstantsURL.GOOGLE_ROOT_URL_CHANNEL + ConstantsURL.GOOGLE_CHANNEL_ID + ConstantsURL.GOOGLE_ROOT_URL_ENDPOINT,
};

