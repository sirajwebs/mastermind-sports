/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved (c) Fedex 2018
 *
 * Typescript code in this page
 */
export const FORMS = {
    ADDRESS: {
        COMPANY_MAXLENGTH: 40,
        COMPANY_PATTERN: '',
        ADDR_LINE1_MAXLENGTH: 30,
        ADDR_LINE1_PATTERN: '',
        ADDR_LINE2_MAXLENGTH: 30,
        ADDR_LINE2_PATTERN: '',
        COUNTRY_MAXLENGTH: 70,
        COUNTRY_PATTERN: '[a-zA-Z ]+',
        COUNTRY_CODE_MAXLENGTH: 3,
        COUNTRY_CODE_PATTERN: '',
        POSTAL_MAXLENGTH: 9,
        POSTAL_PATTERN: '[a-zA-Z0-9 -]*',
        CITY_MAXLENGTH: 30,
        CITY_PATTERN: '',
        PHONE_MAXLENGTH: 16,
        PHONE_PATTERN: '^([+]{1})*([0-9]){5,16}$',
        EMAIL_MAXLENGTH: 50,
        EMAIL_PATTERN: '',
        CONTACT_PERSON_MAXLENGTH: 30,
        CONTACT_PERSON_PATTERN: '[a-zA-Z ]+',
        INSTRUCTION_MAXLENGTH: 50,
        INSTRUCTION_PATTERN: '',
    },
    SAVEADDRESS : {
        NICK_NAME_MAXLENGTH : 35
    }
};
