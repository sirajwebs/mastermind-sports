/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */

export const ConstantsVAR = {
    COMPANY_IDENTIFIER: ['TNT', 'TNTD'],
    draftId: 1,
    errorId: 2,
    awaitingId: 3,
    bookedId: 4,
    collectedId: 5,
    exceptionId: 6,
    intransitId: 7,
    outfordelivery: 8,
    deliveredId: 9,
    closedId: 10,
    deletedId: 11,
    expiredId: 12,
    goodsNonDocs: 'Goods (non documents)',
    editSenderFlag: 'SA',
    editReceiverFlag: 'RA',
    editPickupFlag: 'PA',
    editDestinationFlag: 'DA',
    rcvrIdFlg: 'r', // DO NOT CHANGE
    sndrIdFlg: 's', // DO NOT CHANGE
    pckIdFlg: 'p', // DO NOT CHANGE
    DestIdFlg: 'd', // DO NOT CHANGE
    senderAddrFlag: 'SA',
    pickupAddrFlag: 'PA',
    receiverAddrFlag: 'RA',
    destinationAddrFlag: 'DA',
    invoice: 'invoice',
    manifest: 'manifest',
    connote: 'connote',
    routing: 'routing',
    HTML_URL: 'text/html',
    PDF_URL: 'application/pdf',
    INBOUND: 'INBOUND',
    RETURN: 'RETURN',
    BOOKING_UPLOAD_FILESIZE: 2,
    BOOKING_UPLOAD_FILENAME: 50,
    MAXIMUM_FILE_NAME_CHAR: 50,
    MINIMUM_INVOICE_VALUE: 0.1,
    CREATE_TEMPLATE_FILE_NOS: 3,
    TEMPLATE_FILE_NOS: 6,
    TEMPLATE_FILE_SIZE_BYTE: 1024,
    DEFAULT_DATE: '31-12-9999',
    PROCESSING_BKNG_UPLOAD_STS: 'PROCESSING',
    COMPLETED_BKNG_UPLOAD_STS: 'COMPLETED',
    ERROR_BKNG_UPLOAD_STS: 'INVALID FILE',
    EDI_DOWNLOAD_UPLOADED_FILE_TYPE: 1,
    EDI_DOWNLOAD_RESULT_FILE_TYPE: 0,
    EDI_DOWNLOAD_DEFAULT_FILE_TYPE: 99999,
    ERR_EXCP_ONTOP: 'ERR_EXCP_ONTOP',
    MOZILLA_FIREFOX: (navigator.userAgent.toLowerCase().indexOf('firefox') > -1) ? true : false,
    MAXIMUM_PACKAGE: 20,
    MLTPL_BKNGS_PAGE_SCRLL_HGHT: 175,
    DSHBRD_DATA_PAGE_SCRLL_HGHT: 175,
    BKNG_PAGE_SCRLL_HGHT_1000: 1000,
    BKNG_PAGE_SCRLL_HGHT_300: 300,
    API_MAX_TRY: 3,
    MINUTES_1: 60 * 1000,
    MINUTES_60: 60 * 60 * 1000,
    ONE_HOUR_IN_MINUTES: 60,
    HOUR_PER_DAY: 24,
    MINUTES_30: 30,
    MINUTES_5: 5,
    ACCOUNT_TRIM_POS: 2,
    MILISEC_50: 50,
    MILISEC_100: 100,
    MILISEC_200: 200,
    MILISEC_300: 300,
    MILISEC_500: 500,
    MILISEC_800: 800,
    MILISEC_900: 900,
    MILISEC_1000: 1000,
    MILISEC_2000: 2000,
    MILISEC_2500: 2500,
    MILISEC_3000: 3000,
    MILISEC_4000: 4000,
    MILISEC_5000: 5000,
    MILISEC_7000: 7000,
    MILISEC_60000: 60000,
    API_STATUS_CODE_500: 500,
    API_STATUS_CODE_204: 204,
    API_STATUS_CODE_400: 400,
    API_STATUS_CODE_401: 401,
    API_STATUS_CODE_403: 403,
    API_STATUS_CODE_404: 404,
    API_STATUS_CODE_406: 406,
    API_STATUS_CODE_409: 409,
    BOOKING_SEARCH_VAL_REQ_LENGTH: 4,
    DATE_POS_0: 0,
    DATE_POS_1: 1,
    DATE_POS_2: 2,
    DATE_POS_3: 3,
    DIGIT_10: 10,
    PAGE_2: 2,
    SIZE_CONVERSION_1024: 1024,
    TERMS_OF_PAYMENT: 'R',
    CLOSE_EDI_DWNLD: 'CLOSE_EDI_DWNLD',
    COUNT_PCKG_CALL: 2,
    VIEW_BKNG_INPUT_FIELD: 4,
    UNIT_CONVERT_CM2M: 100,
    DIGIT_3_ROUNDUP: 1000,
    MILISEC_TO_SEC: 1000,
    DEVICE_SIZE: 'DEVICE_SIZE',
    DEVICE_MAX_WIDTH_339: 339,
    DEVICE_MAX_WIDTH_767: 767,
    DEVICE_MAX_WIDTH_1023: 1023,
    ACC_KEY: 'acc',
    DEF_ACC_KEY: 'defAcc',
    ACCESS_TOKEN: 'acstkn',
    FEDEX_TOKEN: 'fdxtkn',
    ACCESS_TOKEN_API: 'getAccessToken',
    FEDEX_TOKEN_API: 'getFdxToken',
    COLN_TIME_SLOT_DIFF: 30,
    COLN_TIME_POS_0: 0,
    COLN_TIME_POS_1: 1,
    TEMPLATE_STATUS_ACTIVE: 'active',
    LAST_ACTIVE_ACCOUNT: 'lastAccountActive',
    COLN_TIME_DATEPOS_2: 2,
    CONTENT_REF_MAX: 10,
    USER_DETAILS: 'uDtl',
    FEDEX_ADDR_LIST: 5,
    LOADING_TEXT: 'loading',
    EMPTY_STRING: ''
};

export const PckgWghtCONST = {
    MAX_PCKG_WGHT: 1000,
    MIN_PCKG_WGHT: 0.1,
    MAX_PCKG_LWH: 999,
    MIN_PCKG_LWH: 1,
    PCKG_TYPE_ID_PALLET: 1,
    PCKG_TYPE_ID_BOX: 2,
    PCKG_TYPE_ID_ENVELOPE: 3,
    QUANT_ARRAY_MAX: 99
}

export const bookingOptions = {
    EMAIL_DAYS: 30,
    DEFAULT_DAYS: 7
}

export const bookingExpiration = {
    MINIMUM_DAYS: 1,
    MAX_DAYS: 999,
    DEFAULT_DAYS: 10
}

export const KEYCODE = {
    _48: 48,
    _57: 57,
    _96: 96,
    _105: 105,
    _37: 37,
    _40: 40,
    _8: 8,
    _9: 9,
    _17: 17,
    _187: 187,
    _61: 61,
    _107: 107,
    _13: 13,
    _86: 86,
    _46: 46,
    _67: 67
}

export const InsrncInvcCONST = {
    INSURANCE_PRCNTG_LIMIT: 110,
    PRCNTG_DIVIDENT: 100,
    INSRNC_VAL_MAX_PRCNT: 110 / 100,
    INVC_MIN_VAL: 0.1,
    INVC_MAX_VAL: 9999999,
    INSRNC_MIN_VAL: 0.1,
    INSRNC_MAX_VAL: 25000
}

export const FedexLoginConstants = {
    FEDEX_PRIVILEGE_ENCD: 'prvlgEncd',
    FEDEX_PRIVILEGE_CACHE_NAME: 'prvlgNm',
    FEDEX_PRIVILEGE_CACHE_REF: 'prvlgRef',
    FEDEX_SHIP_ADMIN_INFO: 'fdxShpAdmn',
    FEDEX_LOGIN_COOKIE: 'fdx_login',
    FEDEX_ADMIN_DETAILS: 'adminDetails'
}

export const DateConstants = {
    DAYS: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
    MONTHS: ['January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December']
}

export const ColnTimeConstants = {
    COLN_TIME_MRNG: ['01:00', '02:00', '03:00', '04:00', '05:00', '06:00', '07:00', '08:00', '09:00', '10:00', '11:00', '12:00'],
    COLN_TIME_AFTRN: ['12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00'],
    TIME_SLAB_IN_MINUTES: 60 / ConstantsVAR.ONE_HOUR_IN_MINUTES,
    COLN_TIME_MRNG_FROM_INIT: '09:00',
    COLN_TIME_MRNG_TO_INIT: '12:00',
    COLN_TIME_AFTRN_FROM_INIT: '12:00',
    COLN_TIME_AFTRN_TO_INIT: '16:00',
    DEPOT_OPEN: 'DEPOT_OPEN',
    DEPOT_CLOSE: 'DEPOT_CLOSE',
    DEPOT_CUTOFF: 'DEPOT_CUTOFF',
    hh: 'hh',
    mm: 'mm',
    TIME_00: '00:00',
    MIN_TIME_COLLECT_MINUTES_30: 30,
    MIN_TIME_COLLECT_MINUTES_90: 90,
    API_MIN_TIME_SLOT_IN_MINUTES: 60
};

export const SearchParams = {
    GRANT_TYPE: 'grant_type',
    CLIENT_ID: 'client_id',
    CLIENT_CREDENTIALS: 'client_credentials',
    CLIENT_SECRET: 'client_secret',
    SCOPE: 'scope',
    OOB: 'oob'
};

export const KeyboardKey = {
    KEY_ARROW_DOWN: 40,
    KEY_ARROW_UP: 38,
    KEY_SPACEBAR: 32,
    KEY_ENTER: 13,
    KEY_TAB: 9,
    KEY_ESC: 27,
    KEY_ARROW_RIGHT: 39,
    KEY_ARROW_LEFT: 37
};

export const RequestHeaders = {
    ContentType: 'application/json',
    Accept: 'application/json',
    XLocale: 'en_US', // will be changed to variable at gloabl localization
    XLoggedin: 'true',
    XClientid: 'SPIRIT',
    XClientversion: '1',
    Authorization: 'Bearer '
}

export const TokenProperty = {
    OAUTH: {
        GET_TOKEN_EXPIRE_NAME: 'getTime',
        SET_TOKEN_EXPIRE_TIME: 60, // in minutes
        GET_TOKEN_CREATED_NAME: 'getTime_created',
        TOKEN_NAME: ConstantsVAR.ACCESS_TOKEN
    },
    FEDEX: {
        GET_TOKEN_EXPIRE_NAME: 'getTime_fdx',
        SET_TOKEN_EXPIRE_TIME: 30,
        GET_TOKEN_CREATED_NAME: 'getTime_fdx_created',
        TOKEN_NAME: ConstantsVAR.FEDEX_TOKEN
    }
};

export const CSSPROP = {
    HIDESHOW: {
        show: 'block',
        hide: 'none'
    },
    searchText: 'Searching...',
    loaderDiv: '-ldr'
    // add more values later
};

export const AddressBookConst = {
    bookType: {
        PERSONAL: 'PERSONAL',
        CENTRAL: 'CENTRAL',
        SHARED: 'SHARED'
    },
    partyType: {
        RECIPIENT: 'RECIPIENT'
    },
    addressAntcillary: {
        einCd: 'E',
        validFlg: 'Y',
        verifiedFlg: 'Y',
        sharedFlg: 'N'
    },
    CONTACT_ID_EXIST: 0,
    Authorization: {
        Y: 'ALLOWED',
        N: 'NOT_ALLOWED'
    },
    CONTACT: {
        MOBILE: 'MOBILE'
    },
    SearchType: [
        { name: 'Company Name', value: 'Company_Name' },
        { name: 'Nickname', value: 'Nick_Name' }
    ],
    SearchTypeValue: {
        COMPANY_NAME: 'Company_Name',
        NICK_NAME: 'Nick_Name',
        CONTACT_NAME: 'Contact_Name'
    },
    SAVE: 'save',
    UPDATE: 'update',
    COMPANY_ID: 'companyID',
    ADDR_LINE1_POS: 0,
    ADDR_LINE2_POS: 1,
    ADDRBK_GOOGLE_MAPPINGS_LINE2: 'addressbook_addrLine2',
    MINIMUN_CHARACTER_SEARCH: 'Minimum two characters are required',
    RESIDENTIAL_COUNTRY: 'US',
    APIERROR: {
        MESSAGE: 'something went wrong, please try again later'
    },
    SEARCHING_TYPE_INIT: 'INIT'
}

export const AddressBookConst_Others = {
    FdxAddressType: [AddressBookConst.partyType.RECIPIENT]
}

export const ConstantsJson = {
    srtFltrChck: {
        tabFlag: 'CB',
        previousTab: '',
        'CB': {
            sort: { 'property': 'dDt', 'column': 'dudtN', 'dirctn': true },
            filter: []
        },
        'AC': {
            sort: { 'property': 'cDt', 'column': 'indtN', 'dirctn': true },
            filter: []
        },
        'DB': {
            sort: { 'property': 'delvDt', 'column': 'dedtN', 'dirctn': false },
            filter: []
        },
        'SEARCH': {
            searchVal: '',
            sort: { 'property': 'dDt', 'column': 'dudtN', 'dirctn': true },
            filter: []
        },
        customSort: {
            'CB': null,
            'AC': null,
            'DB': null,
            'SEARCH': null
        }
    },
    dshbrdDataINIT: {
        'err': [],
        'othrs': [],
        'excp': []
    },
    initTabs: {
        'CB': [],
        'AC': [],
        'DB': [],
        'SEARCH': []
    },
    pageSelect: {
        'CB': 1,
        'AC': 1,
        'DB': 1,
        'SEARCH': 1
    },
    duePickUpDate_INIT: {
        'dDt': '',
        'wDys': ''
    },
    hideColumnFlag: {
        'awbN': false,
        'accN': true,
        'bkngN': false,
        'custN': false,
        'srvcN': false,
        'colnN': false,
        'delN': false,
        'dudtN': false,
        'bkdtN': true,
        'dedtN': true,
        'redtN': true,
        'coldtN': true,
        'cntN': true,
        'indtN': true,
        'bkN': false,
        'stsN': false
    },
    activeFilter: {
        'awbN': false,
        'accN': false,
        'bkngN': false,
        'custN': false,
        'srvcN': false,
        'colnN': false,
        'delN': false,
        'dudtN': false,
        'bkdtN': false,
        'dedtN': false,
        'redtN': false,
        'coldtN': false,
        'cntN': false,
        'indtN': false,
        'stsN': false
    },
    hideColumnFlagAC: {
        'awbN': true,
        'accN': false,
        'bkngN': false,
        'custN': false,
        'srvcN': true,
        'colnN': false,
        'delN': false,
        'dudtN': true,
        'bkdtN': true,
        'dedtN': true,
        'redtN': true,
        'coldtN': true,
        'cntN': false,
        'indtN': false,
        'bkN': true,
        'stsN': false
    },
    hideColumnFlagDB: {
        'awbN': false,
        'accN': true,
        'bkngN': false,
        'custN': false,
        'srvcN': false,
        'colnN': false,
        'delN': false,
        'dudtN': true,
        'bkdtN': true,
        'dedtN': false,
        'redtN': true,
        'coldtN': true,
        'cntN': true,
        'indtN': true,
        'bkN': false,
        'stsN': false
    },
    hideColumnFlagCB: {
        'awbN': false,
        'accN': true,
        'bkngN': false,
        'custN': false,
        'srvcN': false,
        'colnN': false,
        'delN': false,
        'dudtN': false,
        'bkdtN': true,
        'dedtN': true,
        'redtN': true,
        'coldtN': true,
        'cntN': true,
        'indtN': true,
        'bkN': false,
        'stsN': false
    },
    hideColumnFlagSEARCH: {
        'awbN': false,
        'accN': true,
        'bkngN': false,
        'custN': false,
        'cntN': true,
        'colnN': false,
        'delN': false,
        'dudtN': false,
        'dedtN': false,
        'srvcN': true,
        'bkdtN': true,
        'redtN': true,
        'coldtN': true,
        'indtN': true,
        'bkN': false,
        'stsN': false
    },
    activeFilterClear: {
        'awbN': false,
        'accN': false,
        'bkngN': false,
        'custN': false,
        'srvcN': false,
        'colnN': false,
        'delN': false,
        'dudtN': false,
        'bkdtN': false,
        'dedtN': false,
        'redtN': false,
        'coldtN': false,
        'cntN': false,
        'indtN': false,
        'stsN': false
    },
    addressInitBoolean: {
        'p': null,
        's': null,
        'd': null,
        'r': null
    },
    addressInitBooleanTrue: {
        'p': true,
        's': true,
        'd': true,
        'r': true
    },
    addressInitString: {
        'p': '',
        's': '',
        'd': '',
        'r': ''
    },
    addressInitNumber: {
        'p': 0,
        's': 0,
        'd': 0,
        'r': 0
    },
    addressInitObject: {
        'p': [],
        's': [],
        'd': [],
        'r': []
    },
    postalAware: {
        'PA': false,
        'SA': false,
        'DA': false,
        'RA': false,
    },
    addressFlagData: {
        'PA': [],
        'SA': [],
        'DA': [],
        'RA': [],
    },
    addrBkDataInit: {
        noCityFlg: [],
        countryShrtName: [],
        citySuggestns: [],
        checkPstlAwr: [],
        postalDisable: [],
        fedexAddrID: [],
        selectedAddrBkType: [],
        fromFedexAddressBook: [],
        hideSaveAddrButtonForSameData: [],
        fedexAddressFormData: []
    }

};
