/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */

export interface LoginRequestV1 {
    LogInRequest: {
        processingParameters:
        {
            anonymousTransaction: boolean,
            debug: boolean,
            returnDetailedErrors: boolean,
            returnLocalizedDateTime: boolean
        },
        userName: string,
        password: string
    }
};

export interface LoginGetResponseV1 {
    IsLoggedInResponse: {
        successful: boolean,
        userProfile: {
            customer: {
                cashOnly: boolean,
                creditCardUpdateBlocked: boolean,
                UKDomesticAllowed: boolean
            },
            defaultAccount: {
                key: string,
                value: string | null
            },
            expandedAccountList: [
                {
                    expandedAccount: {
                        account: {
                            accountDisplayName: string,
                            accountNickname: string,
                            accountNumber: {
                                key: string,
                                value: string | null
                            }
                        }
                    }
                },
                {
                    expandedAccount: {
                        account: {
                            accountDisplayName: string,
                            accountNickname: string,
                            accountNumber: {
                                key: string,
                                value: string | null
                            }
                        }
                    }
                }
            ],
            isManaged: boolean,
            registeredContactAndAddress: {
                address: {
                    streetLineList: Array<Object>,
                    city: string,
                    stateOrProvinceCode: string,
                    postalCode: string,
                    countryCode: string,
                    residential: boolean
                },
                contact: {
                    companyName: string | null,
                    emailAddress: string,
                    personName: {
                        firstName: string,
                        lastName: string | null,
                        middleName: string | null 
                    },
                    phoneNumber: string
                }
            },
            siteWideProfile: {
                companyAdmin: boolean,
                departmentAdmin: boolean
            }
        },
        userLoggedIn: boolean
    }
};

export interface LoginRequestV2 {
    userName: string,
    password: string
    /*hostName?: string
    customerInfoControlParameters: {
        showPreferences: boolean,
        showBillingDetail: boolean,
        showReferences: boolean,
        showPrivileges: boolean,
        showServices: boolean,
        showAlias: boolean,
        showAccountList: boolean,
        showProfile: boolean,
        showSitewideProfile: boolean,
        showUserDefaults: boolean,
        showCustomer: boolean,
        showInactiveAccounts: boolean
    }*/
    }

export interface LoginResponseV2 {
    output: {
    userProfile: UserProfile,
    loginCookieOutputVO: {
        fclCookie: string,
        nameCookie: string,
        contactNameCookie: string,
        uuidCookie: string
    }
    }

};

export interface UserProfile {
        registeredContactAndAddress: {
            contact: {
                personName: {
                    firstName: string | null,
                    middleName: string | null,
                    lastName: string | null
                },
                companyName: string | null,
                phoneNumber: number | null,
                emailAddress: string | null
            },
            address: {
                streetLines: Array<string>
                city: string | null,
                stateOrProvinceCode: string | null,
                postalCode: string | null,
                countryCode: string | null,
                residential: boolean
            }
        },
        isManaged: boolean,
        defaultAccount: {
            value: string | null,
            key: string
        },
        customer: {
            cashOnly: boolean,
            creditCardUpdateBlocked: boolean,
            ukdomesticAllowed: boolean
        },
        expandedAccounts: [
            {
                account: {
                    accountNumber: {
                        value: string | null,
                        key: string
                    },
                    accountNickname: string,
                    accountDisplayName: string
                }
            },
            {
                account: {
                    accountNumber: {
                        value: string | null,
                        key: string
                    },
                    accountNickname: string,
                    accountDisplayName: string
                }
            }
        ],
        siteWideProfile: {
            companyAdmin: boolean,
            departmentAdmin: boolean
        }
    };

export interface AssociatedAccRequest {
  accountNumber: {
    key: string,
    value: string | null
  }
};

export interface AssociatedAccounts {
    accountNumber: string,
    companyIdentifier: string,
    displayName: string
}

export interface AssociatedAccResponse {
    output: {
    associatedAccounts: Array<AssociatedAccounts>
  }
};

export interface UserAccounts {
    accounts: {
        defaultAccount: AssociatedAccRequest,
        expandedAccounts: Array<AssociatedAccRequest>
    }
};
