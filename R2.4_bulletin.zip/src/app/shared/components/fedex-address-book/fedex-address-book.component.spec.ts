/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* Fedex 2018
 *
 * Typescript code in this page
 */

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FedexAddressBookComponent } from './fedex-address-book.component';

describe('FedexAddressBookComponent', () => {
  let component: FedexAddressBookComponent;
  let fixture: ComponentFixture<FedexAddressBookComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FedexAddressBookComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FedexAddressBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
