/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { async, ComponentFixture, TestBed, fakeAsync } from '@angular/core/testing';
import { ToasterComponent } from './toaster.component';
import { SimpleChange } from '@angular/core';

describe('ToasterComponent', () => {
  let component: ToasterComponent;
  let fixture: ComponentFixture<ToasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ToasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ToasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call toaster on changes', () => {
    spyOn(component, 'toasterCall');
    const changes = {};
    component.toaster_msg = 'SC';
    component.ngOnChanges(changes);
    expect(component.toasterCall).toHaveBeenCalled();
  });


  it('should call toaster : success messages block,', () => {
    component.toaster_msg = 'SC';
    component.toasterCall();
    fixture.detectChanges();
  });

  it('should call toaster : error messages block,', () => {
    component.toaster_msg = 'ER';
    component.toasterCall();
    fixture.detectChanges();
  });

  it('should call toaster : error detailed block,', () => {
    component.toaster_msg = 'ER_D';
    component.toasterCall();
    fixture.detectChanges();
  });

  it('should call toaster : success detailed block,', () => {
    component.toaster_msg = 'SC_D';
    component.toasterCall();
    fixture.detectChanges();
  });

  it('should call toaster : success detailed block(white),', () => {
    component.toaster_msg = 'SC_D2';
    component.toasterCall();
    fixture.detectChanges();
  });


  it('should close toaster : success messages block,', () => {
    component.toaster_msg = 'SC';
    component.close();
    fixture.detectChanges();
  });

  it('should close toaster : error messages block,', () => {
    component.toaster_msg = 'ER';
    component.close();
    fixture.detectChanges();
  });

  it('should close toaster : error detailed block,', () => {
    component.toaster_msg = 'ER_D';
    component.close();
    fixture.detectChanges();
  });

  it('should close toaster : success detailed block,', () => {
    component.toaster_msg = 'SC_D';
    component.close();
    fixture.detectChanges();
  });

  it('should close toaster : success detailed block(white),', () => {
    component.toaster_msg = 'SC_D2';
    component.close();
    fixture.detectChanges();
  });


});
