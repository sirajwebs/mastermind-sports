/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { Component, OnInit, Input, EventEmitter, Output, OnChanges, SimpleChanges } from '@angular/core';
import { isNullOrUndefined } from 'util';
import { ConstantsVAR } from './../../constants/constants-var';
@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent implements OnInit, OnChanges {
  @Input() templtFileSize;
  @Input() templateFileLength;
  @Input() setFilesDetails;
  @Output() filesArray = new EventEmitter<any>();
  @Output() docDetails = new EventEmitter<any>();
  @Input() public readonlyField;

  unsupportedFileError = false;
  errorFileName = '';
  fileExceedError = false;
  fileNumberLimitError = false;
  fileDetails = [];
  uploadedfiles = [];
  uploadedfilesName = [];
  fileExistsError = false;
  totalSize = 0;
  fileSizeUnit = 'MB';
  maximumFileNameSize = ConstantsVAR.MAXIMUM_FILE_NAME_CHAR;
  fileDoc= [];
  dupFileError = false;
  dupFileName = '';
  maximumFileNameError = false;
  constructor() { }

  ngOnInit() {
    this.templtFileSize = this.templtFileSize / 1024;
  }

  ngOnChanges(changes: SimpleChanges) {
    /**
     * update the files and validation on change of files upload
     */
    if (changes.setFilesDetails) {
      if (changes.setFilesDetails.previousValue !== changes.setFilesDetails.currentValue) {
        if (this.setFilesDetails) {
          this.setFiles(this.setFilesDetails);
        }
      }
    }
  }

  resetAllData() {
    /**
     * reset to the default initial setting for validationa and error msg
     */
    this.unsupportedFileError = false;
    this.errorFileName = '';
    this.fileExceedError = false;
    this.fileNumberLimitError = false;
    this.fileDetails = [];
    this.uploadedfiles = [];
    this.uploadedfilesName = [];
    this.fileExistsError = false;
    this.totalSize = 0;
    this.fileDoc = [];
    this.dupFileError = false;
    this.dupFileName = '';
  }

  setFiles(data) {
    /**
     * create thwe upload file body to emit the uploaded files details
     */
    this.fileDetails = [];
    if (data) {
      for (let i = 0; i < data.length; i++) {
        this.fileDetails.push({
          'id': data[i].id,
          'filename': data[i].fn,
          'filesize': (data[i].size / 1024) / 1024
        });
        if (data) {
          if (i === (data.length - 1)) {
            if (this.fileDetails) {
              for (let k = 0; k < this.fileDetails.length; k++) {
                this.totalSize += this.fileDetails[k].filesize;
              }
            }
            this.uploadedfiles = JSON.parse(JSON.stringify(this.fileDetails));
          }
        }
        this.fileDoc.push({ 'fn': this.fileDetails[i].filename });
        if (i === this.fileDetails.length - 1) {
          this.docDetails.emit(this.fileDoc);
        }
      }
    }
  }

  fileEvent(ev) {
    /**
     * upload file implemenations, validations and file handling to create the file request body
     */
    this.fileExceedError = false;
    this.fileNumberLimitError = false;
    this.maximumFileNameError = false;
    this.dupFileError = false;

    if (this.uploadedfiles.length === 0) {
      if (ev.target.files.length <= this.templateFileLength) {
        for (let i = 0; i < ev.target.files.length; i++) {
          if (ev.target.files[i].name.split('.').pop().toLowerCase() === 'pdf') {
            if (ev.target.files[i].name.split('.')[0].length <= this.maximumFileNameSize) {
            this.fileExistsError = false;
            this.unsupportedFileError = false;
            this.totalSize = this.totalSize + ((ev.target.files[i].size) / 1048576);
            if (this.totalSize > this.templtFileSize) {
              this.fileExceedError = true;
              this.totalSize = this.totalSize - ((ev.target.files[i].size) / 1048576);
              break;
            } else {
              this.uploadedfiles.push(ev.target.files[i]);
              this.uploadedfilesName.push(ev.target.files[i].name);
              this.fileDetails.push({
                'id': null,
                'filename': ev.target.files[i].name,
                'filesize': (ev.target.files[i].size / 1024)
              });
            }
            this.filesArray.emit(this.uploadedfiles);
            } else {
              this.maximumFileNameError = true;
            }
          } else {
            this.errorFileName = ev.target.files[i].name;
            this.unsupportedFileError = true;
          }
        }
      } else {
        this.fileNumberLimitError = true;
      }
    } else {
      /**
       * when uploadedfiles has some files already in it
      */
      for (let i = 0; i < this.uploadedfiles.length; i++) {
        for (let j = 0; j < ev.target.files.length; j++) {
          if (this.uploadedfiles[i].name === ev.target.files[j].name) {
            this.dupFileError = true;
            this.dupFileName = ev.target.files[j].name;
            break;
          }
        }
      }
      /**
       * to handle the duplicate file name upload handling
       */
      if (this.dupFileError === false) {
        if ((this.uploadedfiles.length + ev.target.files.length) <= this.templateFileLength) {
          for (let i = 0; i < ev.target.files.length; i++) {
            if (ev.target.files[i].name.split('.').pop().toLowerCase() === 'pdf') {
              if (ev.target.files[i].name.split('.')[0].length <= this.maximumFileNameSize) {
              this.unsupportedFileError = false;
              this.fileExistsError = false;
              this.totalSize = this.totalSize + ((ev.target.files[i].size) / (1024 * 1024));
              if (this.totalSize > this.templtFileSize) {
                this.fileExceedError = true;
                this.totalSize = this.totalSize - ((ev.target.files[i].size) / (1024 * 1024));
              } else {
                this.uploadedfiles.push(ev.target.files[i]);
                this.uploadedfilesName.push(ev.target.files[i].name);
                this.fileDetails.push({
                  'id': null,
                  'filename': ev.target.files[i].name,
                  'filesize': (ev.target.files[i].size / 1024)
                });
              }
              this.filesArray.emit(this.uploadedfiles);
            } else {
                this.maximumFileNameError = true;
              }
            } else {
              this.errorFileName = ev.target.files[i].name;
              this.unsupportedFileError = true;
            }
          }

        } else {
          this.fileNumberLimitError = true;
        }
      }
    }
    ev.target.value = null;
  }

  public clearFiles(ev, index) {
    /**
     * clear/delete files from the uploaded file list
     */
    this.dupFileError = false;
    this.unsupportedFileError = false;
    if (this.uploadedfiles.length <= this.templateFileLength) {
      this.fileNumberLimitError = false;
      this.maximumFileNameError = false;
    }
    this.fileDetails.splice(index, 1);
    this.uploadedfiles.splice(index, 1);
    this.totalSize = this.totalSize - ((ev.filesize) / 1024);
    if (this.uploadedfiles.length === 0 || this.totalSize < this.templtFileSize) {
      this.fileExceedError = false;
    }
    if (this.fileDetails) {
      if (!this.fileDetails.length) {
        this.totalSize = 0;
      }
    }
    /**
     * splice is done one file at a time and create and emit the updated data
     */
    if (this.fileDetails) {
      if (this.fileDetails.length > 0) {
        this.fileDoc = [];
        for (let i = 0; i < this.fileDetails.length; i++) {
          if (!isNullOrUndefined(this.fileDetails[i].id)) {
            this.fileDoc.push({ 'fn': this.fileDetails[i].filename });
          }
          if (i === this.fileDetails.length - 1) {
            this.docDetails.emit(this.fileDoc);
          }
          if (this.fileDetails.length <= this.templateFileLength) {
            this.fileDoc.push({ 'fn': this.fileDetails[i].filename });
            this.docDetails.emit(this.fileDoc);
          }
        }
      } else if (this.fileDetails.length === 0) {
        this.docDetails.emit([]);
      }
    }
  }
}
