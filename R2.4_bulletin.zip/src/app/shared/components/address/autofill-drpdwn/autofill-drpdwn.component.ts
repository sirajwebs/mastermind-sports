/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';

@Component({
  selector: 'app-autofill-drpdwn',
  templateUrl: './autofill-drpdwn.component.html',
  styleUrls: ['./autofill-drpdwn.component.css']
})
export class AutofillDrpdwnComponent implements OnInit {
  @Input() cntryDrpdwnData;
  @Input() pstlDrpdwnData;
  @Input() listLength;
  @Input() ctyDrpdwnData;
  @Input() drpdwn;
  @Output() cntryVal = new EventEmitter<any>();
  @Output() cityVal = new EventEmitter<any>();
  @Output() pstalVal = new EventEmitter<any>();

  ngOnInit() { }

  getPostalCode(val: string, event) {
    this.pstalVal.emit(val);
    event.stopPropagation();
  }
  getCountryCode(cntry: string, event) {
    this.cntryVal.emit(cntry);
    event.stopPropagation();
  }
  getCityCode(cty: string, event) {
    this.cityVal.emit(cty);
    event.stopPropagation();
  }

}
