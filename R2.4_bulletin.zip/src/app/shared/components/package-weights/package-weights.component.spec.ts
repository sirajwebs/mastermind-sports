/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { PackageWeightsComponent } from './package-weights.component';
import { CalltokenComponent } from './../../calltoken/calltoken.component';
import { TemplateService } from 'app/services/template.service';
import { Subscription } from 'rxjs/Subscription';
import { Component, OnInit, Output, EventEmitter, ViewChild, ElementRef, Input, OnChanges, OnDestroy, SimpleChanges } from '@angular/core';
import { FormControl, FormArray, FormBuilder, FormGroup, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MinMaxValue } from 'app/services/validators.service';
import { ConstantsVAR, PckgWghtCONST } from '../../constants/constants-var';
import { HttpModule } from '@angular/http';
import { RouterTestingModule } from '@angular/router/testing';

describe('PackageWeightsComponent', () => {
  let component: PackageWeightsComponent;
  let fixture: ComponentFixture<PackageWeightsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        PackageWeightsComponent,
        CalltokenComponent
      ],
      imports: [
        HttpModule,
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule
      ],
      providers: [TemplateService]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PackageWeightsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should set package details on init', () => {
    spyOn(component, 'fetchPackageList');
    spyOn(component, 'OnBookingTemplateChange');
    spyOn(component, 'formOnChanges');
    spyOn(component, 'getValues');

    component.setPckgDetails = [
      {
        enc: null,
        h: 30,
        id: 2,
        l: 10,
        q: 1,
        wd: 20,
        wg: 10,
      }
    ]

    component.ngOnInit();
    fixture.detectChanges();
    expect(component.fetchPackageList).toHaveBeenCalled();
    expect(component.OnBookingTemplateChange).toHaveBeenCalled();
    expect(component.formOnChanges).toHaveBeenCalled();
    expect(component.getValues).toHaveBeenCalled();
  });

  it('should clear all subcriptions on destroy', () => {
    component.ngOnDestroy();
    fixture.detectChanges();
  });

  it('should create the form array for the package component along with the validators', () => {
    spyOn(component, 'deleteAllPack');
    component.setPckgDataFlag = true;

    component.OnBookingTemplateChange();
    fixture.detectChanges();
    expect(component.deleteAllPack).toHaveBeenCalled();
  });
});
