/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved (c) Fedex 2018
 *
 * Typescript code in this page
 */

import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { PrintComponent } from './print.component';
import { HttpModule } from '@angular/http';
import { SafePipe } from './../../pipes/safe.pipe';
import { LabelsAndEmailsService } from './../../../services/labels-and-emails.service';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';

describe('PrintComponent', () => {
  let component: PrintComponent;
  let fixture: ComponentFixture<PrintComponent>;
  const fakeActivatedRoute = {
    snapshot: { data: {} }
  } as ActivatedRoute;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        PrintComponent,
        SafePipe
      ],
      imports: [
        RouterTestingModule
      ],
      providers: [
        LabelsAndEmailsService,
        { provide: ActivatedRoute, useValue: fakeActivatedRoute }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrintComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
