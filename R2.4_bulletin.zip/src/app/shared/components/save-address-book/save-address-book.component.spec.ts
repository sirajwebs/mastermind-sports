import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SaveAddressBookComponent } from './save-address-book.component';

describe('SaveAddressBookComponent', () => {
  let component: SaveAddressBookComponent;
  let fixture: ComponentFixture<SaveAddressBookComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SaveAddressBookComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SaveAddressBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
