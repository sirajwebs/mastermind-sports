/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CountryApiDirective } from '../shared/utils/country-api.directive';
import { PostalApiDirective } from '../shared/utils/postal-api.directive';
import { GoogleplaceDirective } from '../shared/utils/googleplace.directive';
import { AllowDecimalsDirective } from '../shared/utils/allowDecimal.directive';
import { AllowNumberDirective } from '../shared/utils/allowNumber.directive';
import { CityApiDirective } from '../shared/utils/city-api.directive';
import { ClickOutsideDirective } from '../shared/utils/click-outside.directive';

import { HighlightPipe } from './pipes/highlight.pipe';
import { OverFlowPipe } from './pipes/overFlow.pipe';
import { ReplaceUnderscore } from './pipes/replace.pipe';
import { TextMaskPipe } from './pipes/text-mask.pipe';

import { UploadComponent } from './components/upload-files/upload.component';
import { ContentRefComponent } from './components/content-ref/content-ref.component';
import { BookingAddressComponent } from './components/booking-address/booking-address.component';
import { ToasterComponent } from './components/toaster/toaster.component';
import { AddressComponent } from './components/address/address.component';
import { InsuranceInvoiceComponent } from './components/insurance-invoice/insurance-invoice.component';
import { PackageWeightsComponent } from './components/package-weights/package-weights.component';
import { FilterComponent } from './commons/filter.component';
import { AutofillDrpdwnComponent } from './components/address/autofill-drpdwn/autofill-drpdwn.component';
import { CalltokenComponent } from './calltoken/calltoken.component';
import { PrintComponent } from './components/print/print.component';
import { SafePipe } from './pipes/safe.pipe';
import { FedexAddressBookComponent } from './components/fedex-address-book/fedex-address-book.component';
import { SaveAddressBookComponent } from './components/save-address-book/save-address-book.component';
import { InfoBulletinComponent } from './components/info-bulletin/info-bulletin.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule
  ],
  declarations: [
    AllowNumberDirective,
    CityApiDirective,
    PostalApiDirective,
    CountryApiDirective,
    GoogleplaceDirective,
    AllowDecimalsDirective,
    ClickOutsideDirective,
    HighlightPipe,
    OverFlowPipe,
    TextMaskPipe,
    ReplaceUnderscore,
    UploadComponent,
    ContentRefComponent,
    BookingAddressComponent,
    AddressComponent,
    ToasterComponent,
    InsuranceInvoiceComponent,
    PackageWeightsComponent,
    FilterComponent,
    AutofillDrpdwnComponent,
    CalltokenComponent,
    PrintComponent,
    SafePipe,
    FedexAddressBookComponent,
    SaveAddressBookComponent,
    InfoBulletinComponent
  ],
  exports: [
    AllowNumberDirective,
    CityApiDirective,
    PostalApiDirective,
    CountryApiDirective,
    GoogleplaceDirective,
    AllowDecimalsDirective,
    ClickOutsideDirective,
    HighlightPipe,
    OverFlowPipe,
    TextMaskPipe,
    ReplaceUnderscore,
    UploadComponent,
    ContentRefComponent,
    BookingAddressComponent,
    AddressComponent,
    ToasterComponent,
    InsuranceInvoiceComponent,
    PackageWeightsComponent,
    FilterComponent,
    AutofillDrpdwnComponent,
    CalltokenComponent,
    InfoBulletinComponent
  ]
})
export class CommonSharedModule { }
