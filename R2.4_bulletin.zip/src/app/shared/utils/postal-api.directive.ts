/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { Directive, ElementRef, EventEmitter, Output, HostListener, Input, OnChanges, SimpleChanges } from '@angular/core';
import { NgModel, NgControl } from '@angular/forms';
import { } from '@types/googlemaps';

@Directive({
    selector: '[appGetPostal]',
    providers: [NgModel],

})
export class PostalApiDirective implements OnChanges {
    @Output() setPostal: EventEmitter<any> = new EventEmitter();
    @Input() setPostalId;
    @Output() setpostalDetails: EventEmitter<any> = new EventEmitter();
    @Input() cntryShrtNm;

    postObj = [];
    private _el: HTMLElement;
    countryShrtNm = '';

    constructor(private _elRef: ElementRef, private model: NgModel, private control: NgControl) {
    }

    @HostListener('input', ['$event'])
    onEvent($event) {
        if (this.control.control.value) {
            const request = {
                input: this.control.control.value,
                componentRestrictions: { country: this.countryShrtNm },
                types: ['(regions)']
            };
            const autocompleteserv = new google.maps.places.AutocompleteService();
         autocompleteserv.getPlacePredictions(request, (result, status) => {
                if (result) {
                    this.postObj = [];
                    for (let i = 0; i < result.length; i++) {
                        if (result[i].types.indexOf('postal_code') >= 0) {
                            this.postObj.push({
                                'post_Cd': result[i].structured_formatting.main_text + ', ' +
                                result[i].structured_formatting.secondary_text,
                                'id': result[i].place_id
                            });
                        }
                        if (i === result.length - 1) {
                            this.setPostal.emit(this.postObj);
                        }
                    }
                } else {
                    this.postObj = [];
                    this.setPostal.emit(this.postObj);
                }
            });
        } else {
            this.setPostalId = null;
        }

    }

    ngOnChanges(changes: SimpleChanges) {
        this._el = this._elRef.nativeElement;
        const input = <HTMLDivElement>this._el;
        if (changes) {
            if (changes.setPostalId) {
                if (this.setPostalId) {
                    const request = {
                        placeId: this.setPostalId.id
                    };
                    const autocompleteserv = new google.maps.places.PlacesService(input);
                    const self = this;
                    autocompleteserv.getDetails(request, function (result, status) {
                        if (result) {
                            self.onInputChange(result.address_components);
                        }
                    });
                }
            }
            if (changes.cntryShrtNm) {
                if (this.cntryShrtNm) {
                    this.countryShrtNm = this.cntryShrtNm;
                } else {
                    this.countryShrtNm = '';
                }
            }
        }
    }
    onInputChange(res) {
        this.setpostalDetails.emit(res);
    }
}
