/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { Directive, ElementRef, EventEmitter, Output, Input, OnChanges, SimpleChanges } from '@angular/core';
import { NgModel } from '@angular/forms';
import { } from '@types/googlemaps';
import { AfterViewInit } from '@angular/core/src/metadata/lifecycle_hooks';
import { ConstantsVAR, CSSPROP, KeyboardKey } from './../constants/constants-var';

@Directive({
    selector: '[appGoogleplace]',
    providers: [NgModel]
})
export class GoogleplaceDirective implements AfterViewInit, OnChanges {
    @Output() setAddress: EventEmitter<any> = new EventEmitter();
    private _el: HTMLElement;
    @Input() cntryShrtNm;
    @Input() addressBlock;
    @Input() showGoogleAddress;
    countryShrtNm = '';
    count = 0;
    maxTries = 2;

    constructor(private _elRef: ElementRef) { }

    ngOnChanges(changes: SimpleChanges) {
        if (changes) {
            if (changes.cntryShrtNm) {
                if (this.cntryShrtNm) {
                    this.countryShrtNm = this.cntryShrtNm;
                } else {
                    this.countryShrtNm = '';
                }
            }
        }
    }

    ngAfterViewInit() {
        try {
            this._el = this._elRef.nativeElement;
            const input = <HTMLInputElement>this._el;
            let options;
            if (this.countryShrtNm) {
                options = {
                    componentRestrictions: { country: this.countryShrtNm },
                };
            } else {
                options = {};
            }
            const autocomplete = new google.maps.places.Autocomplete(input, options);
            let pckContainer;
            const self = this;
            setTimeout(() => {
                try {
                    pckContainer = document.getElementsByClassName('pac-container')[this.addressBlock]
                    google.maps.event.addDomListener(pckContainer, 'mousedown', function (e) {
                        if (e.target['className'] === 'pac-item FxAB') {
                            // set ID from hidden input field
                            self.invokeId({ ID: parseInt(e.target['firstChild'].value, ConstantsVAR.DIGIT_10) });
                        } else if (e.target['className'] === 'pac-item-query' || e.target['parentNode']['className'] === 'pac-item FxAB') {
                            self.invokeId({ ID: parseInt(e.target['parentNode']['firstChild'].value, ConstantsVAR.DIGIT_10) });
                        } else if (e.target['parentNode']['className'] === 'pac-item-query') {
                            self.invokeId({ ID: parseInt(e.target['parentNode']['parentNode']['firstChild'].value, ConstantsVAR.DIGIT_10) });
                        } else if (e.target['className'] === 'pac-matched') {
                            self.invokeId({
                                ID: parseInt(e.target['parentNode']['parentNode']['parentNode']['firstChild'].value, ConstantsVAR.DIGIT_10)
                            });
                        }
                    }, true);
                } catch (err) { }
            }, ConstantsVAR.MILISEC_2000);

            google.maps.event.addListener(autocomplete, 'place_changed', () => {
                const place = autocomplete.getPlace();
                this.invokeEvent(place);
            });
        } catch (err) {
            setTimeout(() => {
                if (++this.count <= this.maxTries) { this.ngAfterViewInit(); };
            }, ConstantsVAR.MILISEC_3000);
        }

        setTimeout(() => {
            this.count = 999;
        }, ConstantsVAR.MILISEC_1000 * ConstantsVAR.MINUTES_30);

        this._el.addEventListener('keyup', (event) => { this.onInputChange(event) }, false);

        this._el.addEventListener('focus', () => { this.onInputChange() }, false);

        if (this.showGoogleAddress) {
            this.createLoaderDiv()
        }
    }

    invokeEvent(place: Object) {
        this.setAddress.emit(place);
    }

    invokeId(id) {
        this.setAddress.emit(id);
    }

    onInputChange(event?: KeyboardEvent) {
        /**
         * On Input data change, hide google results until the API responds
         * show google results after API success or failure
         */

        if (this.showGoogleAddress) {
            const showLoader = setInterval(() => {
                this.showHideLoader(CSSPROP.HIDESHOW.show);
                document.getElementsByClassName('pac-container')[this.addressBlock]['style']['visibility'] = 'hidden';
                if (this.showGoogleAddress.show) {
                    clearInterval(showLoader);
                    this.showHideLoader(CSSPROP.HIDESHOW.hide);
                    document.getElementsByClassName('pac-container')[this.addressBlock]['style']['visibility'] = 'visible';
                    if (this.getElement('FxAB').length && !this.getElement('pac-icon-marker').length) {
                        document.getElementsByClassName('pac-container')[this.addressBlock]['style']['display'] = CSSPROP.HIDESHOW.show;
                        document.getElementsByClassName('pac-logo')[this.addressBlock].classList.add('gmaps-logo');
                    } else if ((!this.getElement('FxAB').length && this.getElement('pac-icon-marker').length)
                        || (this.getElement('FxAB').length && this.getElement('pac-icon-marker').length)
                    ) {
                        document.getElementsByClassName('pac-logo')[this.addressBlock].classList.remove('gmaps-logo');
                    }
                }
            }, ConstantsVAR.MILISEC_50);
        }
    }

    createLoaderDiv() {
        /**
         * create a div with respect to current input element
         * append style class to the created div and set ID for it
         * append the created div to parent element (i,e) parent of input element
         */
        try {
            const eID = document.getElementById(this._el.id);
            const loaderDiv = document.createElement('div');
            loaderDiv.id = this._el.id + CSSPROP.loaderDiv;
            loaderDiv.setAttribute('class', 'showloader');
            loaderDiv.textContent = CSSPROP.searchText;
            eID.parentElement.appendChild(loaderDiv);
        } catch (error) { }
    }

    showHideLoader(event) {
        /**
         * show or hide loader based on passed parameter
         * parameter => 'block' -> to show loader , 'none' -> to hide loader
         */
        document.getElementById(this._el.id + CSSPROP.loaderDiv).style.display = event;
    }

    getElement(className: string) {
        return document.getElementsByClassName(className);
    }
}
