/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { Directive, ElementRef, EventEmitter, Output, HostListener, Input, OnChanges, SimpleChanges } from '@angular/core';
import { NgModel, NgControl } from '@angular/forms';
import { } from '@types/googlemaps';

@Directive({
    selector: '[appGetCity]',
    providers: [NgModel],

})
export class CityApiDirective implements OnChanges {
    @Output() setCity: EventEmitter<any> = new EventEmitter();
    @Input() set_city_id;
    @Output() setCityDetails: EventEmitter<any> = new EventEmitter();
    @Input() cntryShrtNm;

    cityObj = [];
    private _el: HTMLElement;
    countryShrtNm = '';

    constructor(private _elRef: ElementRef, private model: NgModel, private control: NgControl) { }

    @HostListener('input', ['$event'])
    onEvent($event) {
        if (this.control.control.value) {
            const request = {
                input: this.control.control.value,
                componentRestrictions: { country: this.countryShrtNm },
                types: ['(cities)']
            };
            const autocompleteserv = new google.maps.places.AutocompleteService();
            autocompleteserv.getPlacePredictions(request, (result, status) => {
                const map = new Map();
                if (result) {
                    this.cityObj = [];
                    for (let i = 0; i < result.length; i++) {
                        if (result[i].types.indexOf('geocode') >= 0 ||
                            result[i].types.indexOf('locality') >= 0 ||
                            result[i].types.indexOf('political') >= 0) {
                            this.cityObj.push({
                                'city_Cd': result[i].structured_formatting.main_text + ', ' +
                                    result[i].structured_formatting.secondary_text,
                                'id': result[i].place_id
                            });
                            map.set(result[i].structured_formatting.main_text, result[i].place_id);
                        }
                        if (i === result.length - 1) {
                            this.setCity.emit(this.cityObj);
                        }
                    }
                }
            });
        } else {
            this.set_city_id = null;
        }

    }

    ngOnChanges(changes: SimpleChanges) {
        this._el = this._elRef.nativeElement;
        const input = <HTMLDivElement>this._el;
        if (changes) {
            if (changes.set_city_id) {
                if (this.set_city_id) {
                    const request = {
                        placeId: this.set_city_id.id
                    };
                    const autocompleteserv = new google.maps.places.PlacesService(input);
                    const self = this;
                    autocompleteserv.getDetails(request, function (result, status) {
                        if (result) {
                            self.onInputChange(result.address_components);
                        }
                    });
                }
            }
            if (changes.cntryShrtNm) {
                if (this.cntryShrtNm) {
                    this.countryShrtNm = this.cntryShrtNm;
                } else {
                    this.countryShrtNm = '';
                }
            }
        }
    }

    onInputChange(res) {
        this.setCityDetails.emit(res);
    }
}
