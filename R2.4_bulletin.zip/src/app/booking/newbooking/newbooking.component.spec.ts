/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NewbookingComponent } from './newbooking.component';

// component imports
import { ConstantsURL } from './../../shared/constants/constants-urls';
import { CalltokenComponent } from './../../shared/calltoken/calltoken.component';
import { GoogleapisService } from './../../services/googleapis.service';
import { AddressComponent } from './../../shared/components/address/address.component';
import { InsuranceInvoiceComponent } from './../../shared/components/insurance-invoice/insurance-invoice.component';
import { PackageWeightsComponent } from './../../shared/components/package-weights/package-weights.component';
import { SharedataService } from './../../services/sharedata.service';
import { Subscription } from 'rxjs/Subscription';
import { FormGroup, FormControl, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Component, OnInit, OnDestroy, ViewChild, ChangeDetectorRef, HostListener } from '@angular/core';
import { BookingService } from '../../services/booking.service';
import { TemplateService } from '../../services/template.service';
import { Router } from '@angular/router';
import { isNullOrUndefined } from 'util';
import { ConstantsJson, ConstantsVAR, KeyboardKey, PckgWghtCONST, InsrncInvcCONST } from './../../shared/constants/constants-var';
import { AccountListDTO } from './../../shared/models/user.models';
import { JsEncoderService } from './../../services/js-encoder.service';
import { ProductsOfferedComponent } from './products-offered/products-offered.component';
import {
  PickupDTO, BookingAddressDTO, DueDateDTO,
  ColnTimeInitDTO, BookingPreferenceDTO, DateTime
} from './../../shared/models/bookings.models';
import { SharedFunctionsService } from './../../services/shared-functions.service';
import { TemplateListDTO } from 'app/shared/models/template.models';
import { ColnTimeConstants } from './../../shared/constants/constants-var';
import { HttpModule } from '@angular/http';
import { RouterTestingModule } from '@angular/router/testing';
import { ToasterComponent } from 'app/shared/components/toaster/toaster.component';
import { AutofillDrpdwnComponent } from './../../shared/components/address/autofill-drpdwn/autofill-drpdwn.component';
import { ContentRefComponent } from './../../shared/components/content-ref/content-ref.component';
import { BookingExpirationComponent } from './booking-expiration/booking-expiration.component';
import { BookingAddressComponent } from './../../shared/components/booking-address/booking-address.component';
import { TextMaskPipe } from './../../shared/pipes/text-mask.pipe';
import { PostalApiDirective } from 'app/shared/utils/postal-api.directive';
import { UploadComponent } from './../../shared/components/upload-files/upload.component';
import { CountryApiDirective } from './../../shared/utils/country-api.directive';
import { CollectionTimeComponent } from './products-offered/collection-time/collection-time.component';
import { AngularMaterialModule } from './../../angular-material.module';
import { OverFlowPipe } from './../../shared/pipes/overFlow.pipe';

describe('NewbookingComponent', () => {
  let component: NewbookingComponent;
  let fixture: ComponentFixture<NewbookingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        NewbookingComponent,
        TextMaskPipe,
        BookingAddressComponent,
        AddressComponent,
        PackageWeightsComponent,
        InsuranceInvoiceComponent,
        ProductsOfferedComponent,
        BookingExpirationComponent,
        ToasterComponent,
        ContentRefComponent,
        CalltokenComponent,
        AutofillDrpdwnComponent,
        CountryApiDirective,
        PostalApiDirective,
        UploadComponent,
        CollectionTimeComponent,
        OverFlowPipe
      ],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        AngularMaterialModule
      ],
      providers: [
        BookingService,
        TemplateService,
        AddressComponent,
        GoogleapisService,
        SharedFunctionsService,
        JsEncoderService,
        SharedataService
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewbookingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
