/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-message-to-sender',
  templateUrl: './message-to-sender.component.html',
  styleUrls: ['./message-to-sender.component.css']
})
export class MessageToSenderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
