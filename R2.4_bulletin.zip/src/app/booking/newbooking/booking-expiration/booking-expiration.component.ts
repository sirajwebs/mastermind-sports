/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */

import { Component, OnInit, Input, OnChanges, SimpleChanges } from '@angular/core';
import { bookingExpiration } from './../../../shared/constants/constants-var';

@Component({
  selector: 'app-booking-expiration',
  templateUrl: './booking-expiration.component.html',
  styleUrls: ['./booking-expiration.component.css', '../newbooking.component.css']
})
export class BookingExpirationComponent implements OnInit, OnChanges {

  @Input() collectionCountryDt: Date;
  @Input() noOfDaysForExpr: number;
  @Input() bookingType: string;

  startDate: Date = this.incrementDate(this.collectionCountryDt, bookingExpiration.MINIMUM_DAYS);
  endDate: Date = this.incrementDate(this.collectionCountryDt, bookingExpiration.MAX_DAYS);
  expirationDate = this.incrementDate(new Date(), bookingExpiration.DEFAULT_DAYS);
  showDate: boolean = null;

  constructor() { }

  ngOnInit() {
    this.collectionCountryDt = !this.collectionCountryDt ? new Date() : this.collectionCountryDt;
    this.noOfDaysForExpr = !this.noOfDaysForExpr && this.bookingType !== 'VIEW' ? bookingExpiration.DEFAULT_DAYS : this.noOfDaysForExpr;
    this.setExprtnDetails(this.collectionCountryDt);
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.collectionCountryDt) {
      if (changes.collectionCountryDt.currentValue) {
        const exp = this.setExprtnDetails(this.collectionCountryDt);
        if (this.expirationDate < new Date(this.collectionCountryDt) && this.bookingType !== 'VIEW') {
          // default is 10 days
          this.expirationDate = this.incrementDate(exp, bookingExpiration.DEFAULT_DAYS);
        }
      }
    }
  }

  setExprtnDetails(collectionCountryDt) {
    this.startDate = this.incrementDate(collectionCountryDt, bookingExpiration.MINIMUM_DAYS);
    this.endDate = this.incrementDate(collectionCountryDt, bookingExpiration.MAX_DAYS);
    // setting date as per collection timezone
    const exp = JSON.parse(JSON.stringify(collectionCountryDt));
    this.expirationDate = this.incrementDate(exp, this.noOfDaysForExpr);
    return exp;
  }

  incrementDate(date, noOfDay) {
    if (!noOfDay && this.bookingType !== 'VIEW') { noOfDay = bookingExpiration.DEFAULT_DAYS; }
    return new Date(new Date(date).setDate(new Date(date).getDate() + noOfDay));
  }
}
