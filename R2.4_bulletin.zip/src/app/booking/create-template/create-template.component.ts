/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { AddressComponent } from './../../shared/components/address/address.component';
import { CalltokenComponent } from './../../shared/calltoken/calltoken.component';
import { PackageWeightsComponent } from './../../shared/components/package-weights/package-weights.component';
import { InsuranceInvoiceComponent } from './../../shared/components/insurance-invoice/insurance-invoice.component';
import { SenderOptionsComponent } from './sender-options/sender-option.component';
import { SharedataService } from 'app/services/sharedata.service';
import { Router } from '@angular/router';
import { EnableServiceComponent } from './enable-service/enable-service.component';
import { Component, OnInit, OnDestroy, ViewChild, ChangeDetectorRef, HostListener } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { TemplateService } from 'app/services/template.service';
import { Subscription } from 'rxjs/Subscription';
import { isNullOrUndefined } from 'util';
import { ConstantsJson, ConstantsVAR, KeyboardKey } from './../../shared/constants/constants-var';
import { JsEncoderService } from './../../services/js-encoder.service';
import { BookingOptionsComponent } from './booking-options/booking-options.component'
import { SenderOptionsDTO} from './../../shared/models/template.models';


@Component({
  selector: 'app-create-template',
  templateUrl: './create-template.component.html',
  styleUrls: ['./create-template.component.css'],
})
export class CreateTemplateComponent implements OnInit, OnDestroy {

  subscriptions: Array<Subscription> = [];
  generalInfo = new FormGroup({
    customerAcc: new FormControl('', Validators.required),
    templateName: new FormControl('', [Validators.required]),
    paysBy: new FormControl('R'),
    showBookingRef: new FormControl(true),
    showCustomerRef: new FormControl(true),
    showPrcngEstd: new FormControl(true),
    generateBookingRef: new FormControl(true),
    copyBookingToCustomer: new FormControl(true),
    shipDateConfirmBy: new FormControl('S'),
    useSenderAddressCheck: new FormControl(),
    useReceiverAddressCheck: new FormControl()
  });

  dupTempForm = new FormGroup({
    duplicateTemplateName: new FormControl('', Validators.required)
  });

  collapse_expand: boolean[] = [false];
  sections = ConstantsVAR.DIGIT_10;
  apiCallCount = [];

  isLoaderEnabled = false;
  getTempDetailsSuccess: boolean;
  getTempDetailsError: boolean;
  templateFileSize = ConstantsVAR.TEMPLATE_FILE_SIZE_BYTE;
  templateFileLength = ConstantsVAR.CREATE_TEMPLATE_FILE_NOS;
  customerAcc = '';
  templateNm: string;
  templateId = '';
  paysBy = '';
  showBookingRef = null;
  showCustomerRef = null;
  showContentRef = null;
  generateBookingRef = null;
  copyBookingToCustomer = null;
  shipDateConfirmBy = '';
  addressArray = [];
  errorSaving: boolean;
  fedexContactAddress = [];
  useSenderAddress = false;
  useReceiverAddress = false;
  deleteErrFlg = false;
  FormError = false;
  senderAddrFlag: string = ConstantsVAR.senderAddrFlag;
  pickupAddrFlag: string = ConstantsVAR.pickupAddrFlag;
  receiverAddrFlag: string = ConstantsVAR.receiverAddrFlag;
  destinationAddrFlag: string = ConstantsVAR.destinationAddrFlag;

  rcvrIdFlg = ConstantsVAR.rcvrIdFlg;
  sndrIdFlg = ConstantsVAR.sndrIdFlg
  pckIdFlg = ConstantsVAR.pckIdFlg
  DestIdFlg = ConstantsVAR.DestIdFlg
  addressFlagData = JSON.parse(JSON.stringify(ConstantsJson.addressFlagData));

  duplicateTemplateBtnClicked: boolean;
  goodsDesc: string;
  invoiceVal: Number;
  invoiceValCurrency: string;
  insuranceVal: Number;
  insuranceValCurrency: string;

  saveBtn = false;
  templateBody = null; // check***
  enableServicesFormData = null; // check***
  packageFormData = null; // check***
  templateDetailsFetch = null; // check***
  tmpltId = '';
  modifySendRcvDetails = ''; // check***
  showSenderServices = ''; // check***
  enableBookingForward = ''; // check***
  modifyPkgDetails = ''; // check***
  serviceStatus = '';
  apiSubscription = [];

  gnrlInfoFrmVldtn = null;
  insrInvcFrmVldtn = null;
  enblSrvcFrmVldtn = null;
  packWeighFrmVldtn = null;
  sndrAddrssFrmVldtn = null;
  pckpAddrssFrmVldtn = null;
  dstntnAddrssFrmVldtn = null;
  rcvrAddrssFrmVldtn = null;
  sndrOptnFrmVldtn = null;

  editTempDisableField = false;
  saveBtnClicked = false;
  sndrOptionsData: SenderOptionsDTO  // check datatype ***
  templateNameConflict: boolean;
  errorSavingTemplate: boolean;
  showSender = true;
  fileVal = null; // check datatype ***
  fileNm = '';
  insuranceDataEdit = null; // check datatype ***
  pickFlag = false;
  destiFlag = false;

  pickAdresData = {}; // check datatype ***
  sndrAdrData = {}; // check datatype ***
  destiAdresData = {}; // check datatype ***
  rcvrAdrData = {}; // check datatype ***
  defaultTemp = false;
  templateValueChanges = false;
  accountList = [];
  editFlag = false;
  checkVisiblityError = false;
  showEstimatedPrice: boolean;
  fileDetailsData = null; // check***
  fileDoc = null; // check***
  tmpNmChkError: boolean;
  tNm = '';
  fromWizard = false;
  closeCancel = 0;
  showModal = [];
  onyes = 0;
  noback = 0;
  templateChanged = 0;

  @ViewChild(CalltokenComponent) public _calltoken: CalltokenComponent;
  @ViewChild(SenderOptionsComponent) public _sndrOptn: SenderOptionsComponent;
  @ViewChild(EnableServiceComponent) public _enblSrvc: EnableServiceComponent;
  @ViewChild(PackageWeightsComponent) public _pckgWght: PackageWeightsComponent;
  @ViewChild(InsuranceInvoiceComponent) public _insrInvc: InsuranceInvoiceComponent;
  @ViewChild('senderAddressBooking') public _sndrAddrssBkng: AddressComponent;
  @ViewChild('pickupAddressBooking') public _pckpAddrssBkng: AddressComponent;
  @ViewChild('receiverAddressBooking') public _rcvrAddrssBkng: AddressComponent;
  @ViewChild('destinationAddressBooking') public _dstntnAddrssBkng: AddressComponent;
  @ViewChild(BookingOptionsComponent) public _bkngOptns: BookingOptionsComponent; // booking option
  @HostListener('focusin', ['$event'])
  onFocus(event) {
    this.FormError = false;
  }

  @HostListener('keydown', ['$event'])
  onEscKey(event) {
    if (event.keyCode === KeyboardKey.KEY_ESC && this.closeCancel === 1) {
      this.closeModal();
      if (this.showModal['closeDelete'] === 1) {
        this.timeoutFocus('yes-deleteTemplate', ConstantsVAR.MILISEC_200);
      } else {
        this.changeFocus('cancel');
      }
    }
    if (event.keyCode === KeyboardKey.KEY_ESC && this.onyes === 1) {
      this.closeModal();
      if (this.showModal['closeDelete'] === 1) {
        this.timeoutFocus('yes-deleteTemplate', ConstantsVAR.MILISEC_200);
      } else {
        this.changeFocus('cancel');
      }
      this.onyes = 0;
    }
    if (event.keyCode === KeyboardKey.KEY_ESC && this.showModal['closeDeleteErr'] === 1) {
      this.changeFocus('delete');
      this.showModal['closeDeleteErr'] = 0;
    }
    if (event.keyCode === KeyboardKey.KEY_ESC && this.showModal['closeDelete'] === 1) {
      this.timeoutFocus('delete', ConstantsVAR.MILISEC_200);
      this.showModal['closeDelete'] = 0;
    }
    if (event.keyCode === KeyboardKey.KEY_ESC && this.showModal['closeSaveAsNew'] === 1) {
      this.timeoutFocus('duplicate', ConstantsVAR.MILISEC_200);
      this.showModal['closeSaveAsNew'] = 0;
      this.noback = 0;
    }
    if ((event.shiftKey && event.keyCode === KeyboardKey.KEY_TAB) && this.closeCancel === 1 && this.noback === 1) {
      return false;
    }
    if ((event.shiftKey && event.keyCode === KeyboardKey.KEY_TAB || event.keyCode === KeyboardKey.KEY_TAB)
      && this.showModal['closeDeleteErr'] === 1) {
      return false;
    }
    if ((event.shiftKey && event.keyCode === KeyboardKey.KEY_TAB) &&
      (this.showModal['closeSaveAsNew'] === 1 || this.showModal['closeDelete'] === 1) && this.noback) {
      return false;
    }

  }
  @HostListener('click', ['$event'])
  OutsideClick(event) {

  }
  constructor(
    private _template: TemplateService,
    private _router: Router,
    private _jsEcd: JsEncoderService,
    private _shrdt: SharedataService,
    private _cd: ChangeDetectorRef
  ) { }

  ngOnInit() {
    /**
     * setting default value for template page validations and options
     */
    window.scrollTo(0, 0);
    this.generalInfo.get('paysBy').disable();   // disabled by default

    const accKeyVal = this._jsEcd.decode(localStorage.getItem(ConstantsVAR.ACC_KEY));
    if (accKeyVal) {
      this.accountList = JSON.parse(accKeyVal)['cAccNoLi'];
      this.accountList = this.accountList.sort();
    }
    if (this.accountList) {
      if (this.accountList.length === 1) {
        this.generalInfo.get('customerAcc').setValue(this.accountList[0]);
        this.generalInfo.get('customerAcc').disable();
      } else {
        this.generalInfo.get('customerAcc').enable();
      }
    }

    this.generalInfo.get('customerAcc').setValue(this._jsEcd.decode(localStorage.getItem(ConstantsVAR.DEF_ACC_KEY)));
    this.timeoutFocus('tempName', ConstantsVAR.MILISEC_500);

    this.subscriptions.push(this._shrdt.gettempId.subscribe((tID) => {
      this.tmpltId = tID;
      if (tID && !this.getTempDetailsSuccess && !this.getTempDetailsError) {
        this.editTemplateFetch(tID);
      }
    }));

    this.subscriptions.push(this._shrdt.wizardTempMsg.subscribe((data) => {
      if (data) {
        this.fromWizard = true;
      }
    }));

    this.subscriptions.push(this.generalInfo.valueChanges.subscribe((formVal) => {
      Object.keys(this.generalInfo.controls).forEach(key => {
        if (this.generalInfo.get(key).dirty) {
          this.templateValueChanges = true;
        }
      });

      if (formVal.showBookingRef === false) {
        this.generalInfo.patchValue({
          generateBookingRef: 'false'
        }, { emitEvent: false });
      }
      this.templateNm = this.generalInfo.get('templateName').value;
      if (formVal.shipDateConfirmBy === 'R') {
        this.showSender = false;
      } else {
        this.showSender = true;
      }
      if (this.generalInfo.value.showBookingRef === false &&
        this.generalInfo.value.generateBookingRef === false) {
        this.checkVisiblityError = true;
      } else {
        this.checkVisiblityError = false;
      }

      if (this.generalInfo.get('useSenderAddressCheck').value) {
        this.sndrAdrData = this.pickAdresData;
      }

      if (this.generalInfo.get('useReceiverAddressCheck').value) {
        this.rcvrAdrData = this.destiAdresData;
      }
    }));
    if (!this.tmpltId) {
      this.generalInfo.get('useSenderAddressCheck').setValue(true);
      this.generalInfo.get('useReceiverAddressCheck').setValue(true);
    }
  }


  editTemplateFetch(tmpInfo) {
    /**
     * fetch template details from DB , API calls
     */
    this.isLoaderEnabled = true;
    const apiName = 'editTemplateFetch';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._template.getTemplateDetails(tmpInfo).subscribe(tempdata => {
      this.getTempDetailsSuccess = true;
      this.getTempDetailsError = false;
      this.templateDetailsFetch = tempdata;
      this.templateNm = this.templateDetailsFetch.tNm;
      this.tNm = this.templateDetailsFetch.tNm;
      this.setEditTemplateValues(tempdata);
      this.editFlag = true;
      this.setSndrOptionsData();
      this.isLoaderEnabled = false;
      this.apiCallCount[apiName] = 0;
      this.templateChanged++;
    }, error => {
      this.isLoaderEnabled = false;
      this.getTempDetailsSuccess = false;
      this.getTempDetailsError = true;
      this.retryMechanism(error, apiName, tmpInfo);
      this._shrdt.templateFetchError(this.getTempDetailsError);
      this._router.navigate(['/booking/templatelist']);
    }));
  }

  setSndrOptionsData() {
    /**
     * set sender options data
     */
    this.sndrOptionsData = {
      'aSCDt': this.templateDetailsFetch.aSCDt,
      'aPkDm': this.templateDetailsFetch.aPkDm,
      'sSrvs': this.templateDetailsFetch.sSrvs,
      'aShTm': this.templateDetailsFetch.aShTm
    };

  }
  ngOnDestroy() {
    /**
     * reset datas
     */
    this._shrdt.setTempalteId('');
    this._cd.detach();
    this.subscriptions.forEach((subscription: Subscription) => { subscription.unsubscribe(); });
    Object.keys(this.apiSubscription).forEach(apiName => { this.apiUnsubscribe(apiName); });
    this._shrdt.setWizardTemp(false);
  }


  setEditTemplateValues(data) {
    /**
     * patch the template value on loading a edit template page
     */
    this.generalInfo.patchValue({
      customerAcc: data.cAccNo,
      templateName: data.tNm,
      paysBy: data.pyr,
      showBookingRef: data.sSidRef,
      showCustomerRef: data.cRFg,
      generateBookingRef: data.gSidReFn,
      copyBookingToCustomer: data.ctRfSmeBkRf,
      shipDateConfirmBy: data.sCnf
    });

    this.setBkngOptionsForEdit(data);
    this.defaultTemp = data.defTmp;
    this.insuranceDataPassEdit(data);
    this.editAddrData(data.adr);
    this.packageFormData = this.templateDetailsFetch.pkgs;
    delete this.packageFormData['tId'];
    this.templateValueChanges = false;
  }

  setBkngOptionsForEdit(data) {
    if (data.expVal) {
      this._bkngOptns.bookingOptionForm.patchValue({
        showBkngExpr: true,
        bkngExprNoOfDays: data.expVal
      });
    }
    this._bkngOptns.bookingOptionForm.patchValue({ showContentRef: data.cnRFg });
  }

  editAddrData(val) {
    /**
     * address component data populations and validations check ,
     * handling 'copy address' functionality
     */
    this.templateValueChanges = false;
    if (val) {
      for (let i = 0; i < val.length; i++) {
        if (val[i].typ === 'S') {
          this.sndrAdrData = val[i];
          if (!this._cd['destroyed']) {
            this._cd.detectChanges();
          }
          delete this.sndrAdrData['typ'];
        } else if (val[i].typ === 'P') {
          this.pickAdresData = val[i];
          if (!this._cd['destroyed']) {
            this._cd.detectChanges();
          }
          delete this.pickAdresData['typ'];
        } else if (val[i].typ === 'R') {
          this.rcvrAdrData = val[i];
          if (!this._cd['destroyed']) {
            this._cd.detectChanges();
          }
          delete this.rcvrAdrData['typ'];
        } else if (val[i].typ === 'D') {
          this.destiAdresData = val[i];
          if (!this._cd['destroyed']) {
            this._cd.detectChanges();
          }
          delete this.destiAdresData['typ'];
        }
      }

      const sndrProps = Object.getOwnPropertyNames(this.sndrAdrData);
      const pickProps = Object.getOwnPropertyNames(this.pickAdresData);
      const recevProps = Object.getOwnPropertyNames(this.rcvrAdrData);
      const destiProps = Object.getOwnPropertyNames(this.destiAdresData);

      if (sndrProps.length !== pickProps.length) {
        this.generalInfo.get('useSenderAddressCheck').setValue(false, { emitEvent: false });
      }
      if (recevProps.length !== destiProps.length) {
        this.generalInfo.get('useReceiverAddressCheck').setValue(false, { emitEvent: false });
      }

      if (!sndrProps || sndrProps.length === 0) {
        this.generalInfo.get('useSenderAddressCheck').setValue(true, { emitEvent: false });
      }

      if (!recevProps || recevProps.length === 0) {
        this.generalInfo.get('useReceiverAddressCheck').setValue(true, { emitEvent: false });
      }

      for (let j = 0; j < sndrProps.length; j++) {
        const propName = sndrProps[j];
        if (this.sndrAdrData[propName] !== this.pickAdresData[propName]) {
          this.generalInfo.get('useSenderAddressCheck').setValue(false, { emitEvent: false });
          break;
        } else {
          this.generalInfo.get('useSenderAddressCheck').setValue(true, { emitEvent: false });
        }
      }

      for (let k = 0; k < recevProps.length; k++) {
        const recevPropName = recevProps[k];
        if (this.rcvrAdrData[recevPropName] !== this.destiAdresData[recevPropName]) {
          this.generalInfo.get('useReceiverAddressCheck').setValue(false, { emitEvent: false });
          break;
        } else {
          this.generalInfo.get('useReceiverAddressCheck').setValue(true, { emitEvent: false });
        }
      }

      this.sndrAdrData['typ'] = 'S';
      this.destiAdresData['typ'] = 'D';
      this.rcvrAdrData['typ'] = 'R';
      this.pickAdresData['typ'] = 'P';
    }
  }

  boxClose() {
    this.FormError = false;
  }

  getDocDetails(ev) {
    this.fileDoc = ev;
  }

  createTemplate(flag) {
    /**
     * all form dependent component validation on save template
     */
    this.saveBtnClicked = true;

    this.gnrlInfoFrmVldtn = this.formValidation();
    this.enblSrvcFrmVldtn = this._enblSrvc.formValidation();
    const bkngOptnsFrmVldtn = this._bkngOptns.formValidations();

    this.insrInvcFrmVldtn = this._insrInvc.formValidation();
    this.packWeighFrmVldtn = this._pckgWght.formValidation();
    this.sndrAddrssFrmVldtn = true;
    this.pckpAddrssFrmVldtn = true;
    this.dstntnAddrssFrmVldtn = true;
    this.rcvrAddrssFrmVldtn = true;

    if (this._sndrAddrssBkng) {
      this.sndrAddrssFrmVldtn = this._sndrAddrssBkng.formValidationPattern();
    }
    if (this._pckpAddrssBkng) {
      this.pckpAddrssFrmVldtn = this._pckpAddrssBkng.formValidationPattern();
    }
    if (this._dstntnAddrssBkng) {
      this.dstntnAddrssFrmVldtn = this._dstntnAddrssBkng.formValidationPattern();
    }
    if (this._rcvrAddrssBkng) {
      this.rcvrAddrssFrmVldtn = this._rcvrAddrssBkng.formValidationPattern();
    }
    this.sndrOptnFrmVldtn = true;
    this.addressArrayCreation();

    if (this.gnrlInfoFrmVldtn && this.packWeighFrmVldtn && this.insrInvcFrmVldtn && this.enblSrvcFrmVldtn &&
      this.sndrAddrssFrmVldtn && this.pckpAddrssFrmVldtn && this.dstntnAddrssFrmVldtn
      && this.rcvrAddrssFrmVldtn && this.sndrOptnFrmVldtn && bkngOptnsFrmVldtn && this.allFiledsValidation()) {
      this.FormError = false;
      this.createTemplateBody(flag);
    } else {
      this.FormError = true;
    }
  }

  allFiledsValidation() {
    /**
     * duplicate template handling
     */
    if (!this.templateNameConflict) {
      return true;
    } else {
      return false;
    }
  }

  formValidation() {
    /**
     * template page general info form validations
     */
    if (this.generalInfo.invalid) {
      Object.keys(this.generalInfo.controls).forEach(key => {
        if (this.generalInfo.get(key).invalid) {
          this.generalInfo.get(key).markAsTouched();
        }
      });
      return false;
    } else {
      return true;
    }
  }

  insuranceDataPassEdit(data) {
    /**
     * pass data to insut=rance component while loading a template (EDIT)
     */
    this.templateValueChanges = false;
    if (data.insV != null) {
      data.insV = data['insV'].toString();
    }
    this.insuranceDataEdit = {
      'gDsc': data.gDsc,
      'insC': data.insC,
      'insV': data.insV,
      'invcV': data.invcV,
      'invcC': data.invcC
    };
    this.fileDetailsData = data.docs;
  }


  isFieldRequired(field) {
    return (this.generalInfo.get(field).touched && this.generalInfo.get(field).invalid && this.generalInfo.get(field).hasError('required'));
  }

  fileData(evt) {
    this.fileVal = evt;
  }

  returnBoolean(value){
    return (value) ? false : true;
  }

  createTemplateBody(flag) {
    /**
    * create template request body generation
    */
    this.customerAcc = this.generalInfo.get('customerAcc').value;

    this.templateNm = this.generalInfo.get('templateName').value;
    this.paysBy = this.generalInfo.value.paysBy;

    if (!this.generalInfo.value.showBookingRef) {
      this.showBookingRef = false;
    } else {
      this.showBookingRef = true;
    }

    if (!this.generalInfo.value.showCustomerRef) {
      this.showCustomerRef = false;
    } else {
      this.showCustomerRef = true;
    }

    if (!this.generalInfo.value.showPrcngEstd) {
      this.showEstimatedPrice = false;
    } else {
      this.showEstimatedPrice = true;
    }

     if (!this._bkngOptns.bookingOptionForm.value.showContentRef) {
      this.showContentRef = false;
    } else {
      this.showContentRef = true;
    }

    if (!this.generalInfo.value.generateBookingRef) {
      this.generateBookingRef = false;
    } else {
      this.generateBookingRef = true;
    }

    if (!this.generalInfo.value.copyBookingToCustomer) {
      this.copyBookingToCustomer = false;
    } else {
      this.copyBookingToCustomer = true;
    }

    /* Below code to be used instead of above ifelse condition
    this.showBookingRef = this.returnBoolean(!this.generalInfo.value.showBookingRef) // to be used later
    this.showCustomerRef = this.returnBoolean(!this.generalInfo.value.showCustomerRef) // to be used later
    this.showEstimatedPrice = this.returnBoolean(!this.generalInfo.value.showPrcngEstd) // to be used later
    this.showContentRef = this.returnBoolean(!this._bkngOptns.bookingOptionForm.value.showContentRef) // to be used later
    this.generateBookingRef = this.returnBoolean(!this.generalInfo.value.generateBookingRef) // to be used later
    this.copyBookingToCustomer = this.returnBoolean(!this.generalInfo.value.copyBookingToCustomer) // to be used later 
    */

    this.shipDateConfirmBy = this.generalInfo.value.shipDateConfirmBy;

    if (!this.enableServicesFormData) {
      this.enableServicesFormData = null;
    }

    if (!this.goodsDesc) {
      this.goodsDesc = '';
    }

    if (!this.insuranceValCurrency) {
      this.insuranceValCurrency = '';
    }

    if (isNullOrUndefined(this.insuranceVal)) {
      this.insuranceVal = null;
    }

    if (!this.invoiceVal) {
      this.invoiceVal = null;
    }

    if (!this.invoiceValCurrency) {
      this.invoiceValCurrency = '';
    }

    if (this.tmpltId) {
      this.templateId = this.tmpltId;
    } else {
      this.templateId = null;
    }

    const ptId = this.templateId;
    let updatedDocs = [];
    if (flag === 'DUP') {
      this.templateNm = this.dupTempForm.get('duplicateTemplateName').value;
      this.templateId = null;
      if (this.fileDoc) {
        updatedDocs = this.fileDoc;
      }
    }

    this.templateBody = {
      'tNm': this.templateNm,
      'tId': this.templateId,
      'cAccNo': this.customerAcc,
      'pyr': 'R',  // this.paysBy //  default is 'R'
      'gSidReFn': this.generateBookingRef,
      'ctRfSmeBkRf': this.copyBookingToCustomer,
      'sSidRef': this.showBookingRef,
      'cRFg': this.showCustomerRef,
      'sPrEs': this.showEstimatedPrice,
      'cnRFg': this.showContentRef,
      'sCnf': this.shipDateConfirmBy,
      'gDsc': this.goodsDesc,
      'insC': this.insuranceValCurrency,
      'insV': this.insuranceVal,
      'invcV': this.invoiceVal,
      'invcC': this.invoiceValCurrency,
      'svcs': this.enableServicesFormData,
      'pkgs': this.packageFormData,
      'adr': this.addressArray,
      'aSCDt': this.modifySendRcvDetails,
      'sSrvs': this.showSenderServices,
      'aShTm': this.enableBookingForward,
      'aPkDm': this.modifyPkgDetails,
      'defTmp': this.defaultTemp,
      'ptId': ptId,
      'docs': updatedDocs,
      'expVal': this.expirationDays()
    };

    if (this.editFlag === true && flag !== 'DUP') {
      this.editSaveTemplate();
    } else {
      if (this.serviceStatus !== 'start' && this.serviceStatus !== 'success') {
        this.createNewTemplate(flag);
      }
    }
  }

  expirationDays() {
    return this._bkngOptns.bookingOptionForm.get('showBkngExpr').value ?
      this._bkngOptns.bookingOptionForm.get('bkngExprNoOfDays').value : null;
  }

  createNewTemplate(flag) {
    /**
     * create new template API call and error handling
     */
    this.isLoaderEnabled = true;
    this.errorSaving = false;
    this.serviceStatus = 'start';
    document.getElementById('REMOVE_MODAL_BACKDROP').click();
    const apiName = 'createNewTemplate';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._template.saveTemplate(this.templateBody, this.fileVal).subscribe(
      savedata => {
        this.isLoaderEnabled = false;
        this.serviceStatus = 'success';
        let tName = this.generalInfo.value.templateName;
        if (flag === 'DUP') {
          tName = this.dupTempForm.get('duplicateTemplateName').value;
          document.getElementById('cancelModal').click();
        }
        let saveSuccessData;
        saveSuccessData = { saveSuccessFlag: true, templateName: tName };
        this._shrdt.changeMessage(saveSuccessData);
        this._router.navigate(['/booking/templatelist']);
        this.apiCallCount[apiName] = 0;
      }, error => {
        this.isLoaderEnabled = false;
        this.serviceStatus = 'error';
        this.errorSaving = true;
        if (error === ConstantsVAR.API_STATUS_CODE_409) {
          this.templateNameConflict = true;
          this.errorSavingTemplate = false;
        } else {
          this.templateNameConflict = false;
          this.errorSavingTemplate = true;
        }
        this.retryMechanism(error, apiName, flag);
      }
    ));
  }

  editSaveTemplate() {
    /**
     * edit and save template API call (update template call)
     */
    if (this.fileDoc) {
      this.templateBody['docs'] = this.fileDoc;
    }
    this.templateBody['tmpSts'] = this.templateDetailsFetch.tmpSts;

    this.isLoaderEnabled = true;
    this.errorSaving = false;
    const apiName = 'editSaveTemplate';
    this.apiUnsubscribe(apiName);


    this.subscriptions.push(this.apiSubscription[apiName] = this._template.updateTemplate(this.templateBody, this.fileVal).subscribe(
      savedata => {
        this.isLoaderEnabled = false;
        let saveSuccessData;
        const tName = this.generalInfo.value.templateName;
        saveSuccessData = { saveEditSuccessFlag: true, templateName: tName };
        this._shrdt.changeMessage(saveSuccessData);
        this.apiCallCount[apiName] = 0;
        this._router.navigate(['/booking/templatelist']);
      }, error => {
        this.isLoaderEnabled = false;
        this.errorSaving = true;
        if (error === ConstantsVAR.API_STATUS_CODE_409) {
          this.templateNameConflict = true;
          this.errorSavingTemplate = false;
        } else {
          this.templateNameConflict = false;
          this.errorSavingTemplate = true;
        }
        this.retryMechanism(error, apiName, '');
      }
    ));
  }

  packageData(pkgData) {
    /**
    * event call to receive data from package component
    */
    if (pkgData) {
      if (pkgData.length) {
        this.packageFormData = pkgData;
      }
    }
  }

  formValueChanges(ev) {
    this.templateValueChanges = true;
  }

  enableServiceData(enblSrvcData) {
    /**
    * event call to receive data from service component
    */
    this.enableServicesFormData = enblSrvcData;
  }

  insuranceData(insrData) {
    /**
    * event call to receive data from insurance component
    */
    this.goodsDesc = insrData.goodsDesc;
    this.invoiceVal = insrData.invoiceVal;
    this.invoiceValCurrency = insrData.invoiceValCurrency;
    this.insuranceVal = insrData.insuranceVal;
    this.insuranceValCurrency = insrData.insuranceValCurrency;
  }

  senderOptionData(sndrData) {
    /**
    * event call to receive data from sender option component
    */
    this.modifySendRcvDetails = sndrData.modifySendRcvDetails;
    this.showSenderServices = sndrData.showSenderServices;
    this.enableBookingForward = sndrData.enableBookingForward;
    this.modifyPkgDetails = sndrData.modifyPkgDetails;
  }

  senderAddressData(addrData) {
    /**
    * event call to receive data from sender address
    */
    this.sndrAdrData = addrData;
  }

  pickupAddressData(addrData) {
    /**
    * event call to receive data from pickup address
    */
    this.pickAdresData = addrData;
    if (this.generalInfo.get('useSenderAddressCheck').value) {
      this.sndrAdrData = addrData;
    }
  }

  receiverAddressData(addrData) {
    /**
    * event call to receive data from receiver address
    */
    this.rcvrAdrData = addrData;
  }

  destinationAddressData(addrData) {
    /**
     * event call to receive data from destination address
     */
    this.destiAdresData = addrData;
    if (this.generalInfo.get('useReceiverAddressCheck').value) {
      this.rcvrAdrData = addrData;
    }
  }

  checkAdrNull(data) {
    /**
     * check if any field on address is null or not
     */
    if ((isNullOrUndefined(data.cNme) || (data.cNme === '')) &&
      (isNullOrUndefined(data.cPsn) || (data.cPsn === '')) &&
      (isNullOrUndefined(data.cd) || (data.cd === '')) &&
      (isNullOrUndefined(data.cntry) || (data.cntry === '')) &&
      (isNullOrUndefined(data.cty) || (data.cty === '')) &&
      (isNullOrUndefined(data.e) || (data.e === '')) &&
      (isNullOrUndefined(data.l1) || (data.l1 === '')) &&
      (isNullOrUndefined(data.l2) || (data.l2 === '')) &&
      (isNullOrUndefined(data.pCd) || (data.pCd === '')) &&
      (isNullOrUndefined(data.pIn) || (data.pIn === '')) &&
      (isNullOrUndefined(data.tel) || (data.tel === ''))) {
      return true;
    } else {
      return false;
    }
  }


  createAddrBody(addrData, flag) {
    /**
     * create address request body
     */
    let typ = '';
    let addressBody = null;

    if (flag === this.senderAddrFlag) {
      typ = 'S';
    } else if (flag === this.pickupAddrFlag) {
      typ = 'P';
    } else if (flag === this.receiverAddrFlag) {
      typ = 'R';
    } else if (flag === this.destinationAddrFlag) {
      typ = 'D';
    }

    if (isNullOrUndefined(addrData)) {
      addressBody = {
        'cd': '',
        'l1': '',
        'l2': '',
        'cNme': '',
        'cty': '',
        'pCd': '',
        'cntry': '',
        'tel': '',
        'e': '',
        'cPsn': '',
        'pIn': '',
        'typ': typ
      };
    } else {
      addressBody = {
        'cd': addrData.cd,
        'l1': addrData.l1,
        'l2': addrData.l2,
        'cNme': addrData.cNme,
        'cty': addrData.cty,
        'pCd': addrData.pCd,
        'cntry': addrData.cntry,
        'tel': addrData.tel,
        'e': addrData.e,
        'cPsn': addrData.cPsn,
        'pIn': addrData.pIn,
        'typ': typ
      };
    }
    return addressBody;
  }

  addressArrayCreation() {
    /**
     * address data request body creation
     */
    this.saveBtn = true;
    this.addressArray = [];
    this.addressArray.push(
      this.createAddrBody(this.sndrAdrData, this.senderAddrFlag),
      this.createAddrBody(this.pickAdresData, this.pickupAddrFlag),
      this.createAddrBody(this.rcvrAdrData, this.receiverAddrFlag),
      this.createAddrBody(this.destiAdresData, this.destinationAddrFlag)
    );

  }


  accordian(sec: number) {
    this.collapse_expand[sec] = !this.collapse_expand[sec];
  }

  checkTempNm(templateNm, flag, event?) {
    /**
     * check for duplicate template name into dashboard before deleting/duplicating
     */
    if (((this.tNm !== templateNm) && flag === 'NEW') || flag === 'DUP') {
      const basicAccNo = this.generalInfo.get('customerAcc').value;
      const apiName = 'checkTempNm';
      this.apiUnsubscribe(apiName);

      this.subscriptions.push(this.apiSubscription[apiName] = this._template.checkTemplateName(basicAccNo, templateNm).subscribe((data) => {
        this.tmpNmChkError = false;
        if (data === 'true') {
          this.templateNameConflict = true;
        } else {
          this.templateNameConflict = false;
        }
        if (flag === 'DUP') {
          if (!this.templateNameConflict) {
            this.createTemplate('DUP');
          }
        }
        if (flag === 'NEW') {
          if (!this.templateNameConflict) {
            try {
              if (event.relatedTarget.className === 'btn-type1') { this.createTemplate('NEW') };
            } catch (err) { }
          }
        }
        this.apiCallCount[apiName] = 0;
      }, error => {
        this.tmpNmChkError = true;
        const dta = { 'templateNm': templateNm, 'flag': flag, 'event': event };
        this.retryMechanism(error, apiName, dta);
      }));
    }
  }


  isPatternValid(field) {
    return this.generalInfo.get(field).hasError('pattern') && !this.generalInfo.get(field).hasError('required');
  }

  cancelSaving() {
    /**
     * cancel saving functionality
     */
    document.getElementById('REMOVE_MODAL_BACKDROP').click();
    if (this.templateValueChanges) {
      const cs = document.getElementById('cancelSaving');
      document.getElementById('templateCancelLink').click();
      this.activeModal();
      const chkCs = setInterval(() => {
        if (cs.style.display === 'block') {
          this.changeFocus('no-CancelSaving');
          clearInterval(chkCs);
        }
      }, ConstantsVAR.MILISEC_100)
    } else {
      this.cancelSavingConfirm();
    }
  }

  changeFocus(elementId) {
    try {
      document.getElementById(elementId).focus();
    } catch (e) { }
  }

  closeModal() {
    this.closeCancel = 0;
  }

  activeModal() {
    this.closeCancel = 1;
  }

  isfcs() {
    this.onyes = 1;
    this.noback = 0;
  }

  noBack() {
    this.noback = 1;
  }

  timeoutFocus(ele, time) {
    setTimeout(() => {
      try {
        document.getElementById(ele).focus();
      } catch (e) { }
    }, time);
  }

  closeDeleteErrorModal() {
    this.showModal['closeDeleteErr'] = 0;
    this.timeoutFocus('delete', ConstantsVAR.MILISEC_200);
  }

  closeDeleteModal() {
    this.showModal['closeDelete'] = 0;
    this.timeoutFocus('delete', ConstantsVAR.MILISEC_200);
  }

  dupTmpltBtnFocus() {
    this.noback = this.noback ? 0 : 1;
  }

  cancelSavingConfirm() {
    /**
     * redirection on cancel saving
     */
    if (this.fromWizard) {
      this._router.navigate(['/booking/wizard']);
    } else {
      this._router.navigate(['/booking/templatelist']);
    }
  }

  SaveAsNew() {
    document.getElementById('duplicateTemplateLink').click();
    this.timeoutFocus('duptempName', ConstantsVAR.MILISEC_500);
    this.showModal['closeSaveAsNew'] = 1;
  }

  deleteTemplate() {
    /**
    * delete template  API call to check if template can be deleted or not
    */
    const val = { tId: this.templateDetailsFetch.tId, accno: this.generalInfo.get('customerAcc').value }
    this.isLoaderEnabled = true;
    document.getElementById('REMOVE_MODAL_BACKDROP').click();
    const apiName = 'deleteTemplate';
    this.apiUnsubscribe(apiName);


    this.subscriptions.push(this.apiSubscription[apiName] = this._template.getDeleteTemplate(val).subscribe((isSuccess) => {
      if (isSuccess) {
        document.getElementById('deleteTemplateLink').click();
        this.showModal['closeDelete'] = 1;
        this.timeoutFocus('no-deleteTemplate', ConstantsVAR.MILISEC_200);
        this.isLoaderEnabled = false;
      }
      this.apiCallCount[apiName] = 0;
    }, error => {
      if (error === ConstantsVAR.API_STATUS_CODE_409) {
        this.isLoaderEnabled = false;
        document.getElementById('deleteTemplateErrLink').click();
        this.showModal['closeDeleteErr'] = 1;
        this.timeoutFocus('close-deleteTemplateErr', ConstantsVAR.MILISEC_200);
      } else {
        this.isLoaderEnabled = false;
        // FAILURE MSG TOASTER
      }
      this.retryMechanism(error, apiName, '');
    }));
  }

  deleteTemplateConfirm() {
    /**
     * delete template confirmation API call and reload the template dashboard data
     */
    this.isLoaderEnabled = true;
    const apiName = 'deleteTemplateConfirm';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._template.DeleteTemplateNew(this.templateDetailsFetch.tId,
      this.generalInfo.get('customerAcc').value).subscribe((isSuccess) => {
        if (isSuccess) {
          this.isLoaderEnabled = false;
          this._router.navigate(['/booking/templatelist']);
          this._shrdt.editDeleteMsg(true);
          this._shrdt.setTempDel(this.templateNm);
        } else {
          this.isLoaderEnabled = false;
        }
        this.apiCallCount[apiName] = 0;
      }, error => {
        this.deleteErrFlg = true;
        this.isLoaderEnabled = false;
        this._shrdt.editDeleteMsg(false);
        this.retryMechanism(error, apiName, '');
      }));
  }

  cancelTmpltCopy() {
    /**
     * template copy popup cancel
     */
    this.dupTempForm.get('duplicateTemplateName').markAsTouched();
    this.dupTempForm.get('duplicateTemplateName').reset();
    this.timeoutFocus('duplicate', ConstantsVAR.MILISEC_200);
  }

  duplicateTemplateConfirm() {
    /**
     * duplicate template api call if inputs are valid
     */
    this.duplicateTemplateBtnClicked = true;
    this.dupTempForm.get('duplicateTemplateName').markAsTouched();
    this.templateNm = this.templateDetailsFetch.tNm;
    if (this.dupTempForm.valid) {
      const templateNm = this.dupTempForm.get('duplicateTemplateName').value;
      this.checkTempNm(templateNm, 'DUP');
    }
  }

  addressEmittedData(data, flag) {
    /**
     * copy address data when 'copy address' checkbox is checked
     */
    this.addressFlagData[flag] = data;
    if (this.generalInfo.get('useSenderAddressCheck').value) {
      this.addressFlagData['s'] = this.addressFlagData['p'];
    }
    if (this.generalInfo.get('useReceiverAddressCheck').value) {
      this.addressFlagData['r'] = this.addressFlagData['d'];
    }
  }

  apiUnsubscribe(apiName) {
    if (this.apiSubscription[apiName]) { this.apiSubscription[apiName].unsubscribe(); }
  }

  retryMechanism(error, apiName, params, noBaseAPI?) {
    this.apiCallCount[apiName] = this.apiCallCount[apiName] || 1;
    this.apiCallCount[apiName]++;
    if (this._calltoken) {
      if (!noBaseAPI) { this._calltoken.callBaseService(error); }
      if (this.apiCallCount[apiName] <= ConstantsVAR.API_MAX_TRY) {
        this._calltoken.retryServiceCall(error, apiName, params);
      } else {
        this.apiCallCount[apiName] = 0;
      }
    }
  }

  retryCall(data) {
    /**
     * retry mechanism whenever there is API failure due to token related issue
     */
    if (data.apiName === 'editTemplateFetch') {
      this.editTemplateFetch(data.data);
    }
    if (data.apiName === 'createNewTemplate') {
      this.createNewTemplate(data.data);
    }
    if (data.apiName === 'editSaveTemplate') {
      this.editSaveTemplate();
    }
    if (data.apiName === 'checkTempNm') {
      this.checkTempNm(data.data.templateNm, data.data.flag, data.data.event);
    }
    if (data.apiName === 'deleteTemplate') {
      this.deleteTemplate();
    }
    if (data.apiName === 'deleteTemplateConfirm') {
      this.deleteTemplateConfirm();
    }
  }

}
