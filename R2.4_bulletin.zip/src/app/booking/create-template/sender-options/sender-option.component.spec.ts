/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { SenderOptionsComponent } from './sender-option.component';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, OnInit, EventEmitter, Output, Input, OnChanges, SimpleChanges, OnDestroy } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Subscription } from 'rxjs/Subscription';
import { DebugElement } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

describe('EnableServiceComponent', () => {
  let component: SenderOptionsComponent;
  let fixture: ComponentFixture<SenderOptionsComponent>;
  let debugElement: DebugElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SenderOptionsComponent],
      imports: [FormsModule, ReactiveFormsModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SenderOptionsComponent);
    component = fixture.componentInstance;
    debugElement = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize the options with default data', () => {
    spyOn(component, 'senderOptionCreator');
    spyOn(component, 'onValueChanges');

    component.senderOptionForm.setValue({
      modifySendRcvDetails: ['true', Validators.required],
      modifyPkgDetails: ['true', Validators.required],
      showSenderServices: ['false', Validators.required],
      enableBookingForward: ['5', Validators.required]
    });

    component.ngOnInit();
    fixture.detectChanges();
    expect(component.senderOptionCreator).toHaveBeenCalled();
    expect(component.onValueChanges).toHaveBeenCalled();
  });

  it('should emit data on sender options value change', () => {
    spyOn(component, 'senderOptionCreator');

    component.senderOptionForm.setValue({
      modifySendRcvDetails: ['true', Validators.required],
      modifyPkgDetails: ['true', Validators.required],
      showSenderServices: ['false', Validators.required],
      enableBookingForward: ['5', Validators.required]
    });
    component.senderOptionForm.get('modifySendRcvDetails').markAsDirty();
    component.senderOptionForm.get('modifySendRcvDetails').markAsTouched();

    component.onValueChanges();
    fixture.detectChanges();
    expect(component.senderOptionCreator).toHaveBeenCalled();
  });

  it('should call to set senderOptions data onChange', () => {
    spyOn(component, 'setSndrOptionsData');
    const changes: SimpleChanges = {};

    component.ngOnChanges(changes);
    fixture.detectChanges();
    expect(component.setSndrOptionsData).toHaveBeenCalled();
  });

  it('should set set sender options coming from saved template', () => {
    spyOn(component, 'setFormValue');
    component.sndrOptionsData = {
      'aSCDt': true,
      'aPkDm': true,
      'sSrvs': true,
      'aShTm': 5,
    };

    component.setSndrOptionsData();
    fixture.detectChanges();
    expect(component.setFormValue).toHaveBeenCalled();
    expect(component.senderOptionForm.value.enableBookingForward).toBe(component.sndrOptionsData.aShTm);
  });

  it('should validate the form for true', () => {
    component.senderOptionForm.setValue({
      modifySendRcvDetails: ['true', Validators.required],
      modifyPkgDetails: ['true', Validators.required],
      showSenderServices: ['false', Validators.required],
      enableBookingForward: ['5', Validators.required]
    });

    component.formValidation();
    fixture.detectChanges();
  });

  it('should validate the form for false', () => {
    component.senderOptionForm.get('modifySendRcvDetails').setErrors({});
    component.formValidation();
    fixture.detectChanges();
  });

  it('should set the TRUE values in form from saved data', () => {
    component.setFormValue('modifySendRcvDetails', true);
    fixture.detectChanges();
  });

  it('should set the FALSE values in form from saved data', () => {
    component.setFormValue('modifySendRcvDetails', false);
    fixture.detectChanges();
  });


});
