/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { ConstantsURL } from './../../../shared/constants/constants-urls';
import { CalltokenComponent } from './../../../shared/calltoken/calltoken.component';
import { ConstantsJson, ConstantsVAR } from './../../../shared/constants/constants-var';
import { FilterComponent } from './../../../shared/commons/filter.component';
import { TemplateService } from './../../../services/template.service';
import { SharedataService } from './../../../services/sharedata.service';
import { BookingService } from 'app/services/booking.service';
import {
  Component, OnInit, Input, OnChanges, SimpleChanges, ViewChild,
  OnDestroy, Output, EventEmitter, HostListener, ChangeDetectorRef
} from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { AccountListDTO } from './../../../shared/models/user.models';
import { JsEncoderService } from './../../../services/js-encoder.service';

@Component({
  selector: 'app-dashborad-data',
  templateUrl: './dashboard-data.component.html',
  styleUrls: ['./dashboard-data.component.css'],
})
export class DashboardDataComponent extends FilterComponent implements OnInit, OnChanges, OnDestroy {

  @ViewChild(CalltokenComponent) public _calltoken: CalltokenComponent;
  @Input() public dshbrdDataRaw;
  @Input() public tabFlag;
  @Input() public templateListSuccess;
  @Input() public templateList;
  @Input() public bookingListError;
  @Input() public bookingListSuccess;
  @Input() public bkngSortFlag;
  @Input() public bkngSveScs;

  @Output() public deleteBookingData = new EventEmitter<object>();
  @Output() public callNewBookingBtn = new EventEmitter<string>();
  @Output() public resetSF = new EventEmitter<string>();
  @Output() public columnConfigEmit = new EventEmitter<string>();
  @Output() public emitSearch = new EventEmitter<boolean>();
  @Output() public emitRefresh = new EventEmitter<boolean>();
  @Output() public emitEmail = new EventEmitter<boolean>();
  @Output() public emitPaperwork = new EventEmitter<boolean>();
  @Output() public resendSndrEmail = new EventEmitter<boolean>();
  @Output() public searchTxtValue = new EventEmitter<string>();
  subscriptions: Array<Subscription> = [];

  idx = 0;
  clicked = false;
  @Input() public deleteBookingDataRef;
  @Input() public searchInputValue: string;
  @Input() public pausePDF;
  apiSubscription = [];

  page = 1;
  totalpage = 1;
  pageLimit = 50; // PAGE SIZE
  rowCount = 0;
  dshbrdDataChange = JSON.parse(JSON.stringify(ConstantsJson.dshbrdDataINIT));
  currPage = 0;
  ERR_EXCP_ONTOP = ConstantsVAR.ERR_EXCP_ONTOP;

  searchInputModel = '';
  searchInput = '';
  enableClear = false;
  hideColumnFlagTemp = null; // data type to be check
  isFilterSearch = false;
  isSearch = false;
  isFilter = false;
  filterCount = 0;
  sortAsc = true;

  draftId = ConstantsVAR.draftId;
  errorId = ConstantsVAR.errorId;
  awaitingId = ConstantsVAR.awaitingId;
  bookedId = ConstantsVAR.bookedId;
  collectedId = ConstantsVAR.collectedId;
  exceptionId = ConstantsVAR.exceptionId;
  intransitId = ConstantsVAR.intransitId;
  outfordelivery = ConstantsVAR.outfordelivery;
  deliveredId = ConstantsVAR.deliveredId;
  closedId = ConstantsVAR.closedId;
  expiredId = ConstantsVAR.expiredId;
  defaultDate = ConstantsVAR.DEFAULT_DATE;
  @Input() public dataCount;
  @Input() public logCountry;

  accNuniqueNames = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
  srvcNuniqueNames = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
  stsNuniqueNames = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
  colnNuniqueNames = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
  colnNuniqueNamesCntry = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
  colnNuniqueNamesCity = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
  delNuniqueNames = JSON.parse(JSON.stringify(ConstantsJson.initTabs));

  disableColnFilterButton = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
  disableDelnFilterButton = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
  disableAccntFilterButton = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
  disableStsFilterButton = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
  disableSrvsFilterButton = JSON.parse(JSON.stringify(ConstantsJson.initTabs));

  delNuniqueNamesCntry = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
  delNuniqueNamesCity = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
  // Filters of filters variable
  filtersOfFilter = JSON.parse(JSON.stringify(ConstantsJson.initTabs));

  accNCheckbox = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
  srvcNCheckbox = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
  stsNCheckbox = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
  colnNCheckboxCntry = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
  colnNCheckboxCity = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
  delNCheckboxCntry = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
  delNCheckboxCity = JSON.parse(JSON.stringify(ConstantsJson.initTabs));

  getSelectedCities = [];
  srvcNmesAll = [];
  srvcNvalue = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
  newActiveFilter = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
  accNmesAll = [];
  accNvalue = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
  colnNmesAll = [];
  colnNvalue = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
  colnCntryNvalue = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
  colnNmesAllCntry = [];
  delNmesAll = [];
  delNmesAllCntry = [];
  delNvalue = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
  delNCntryNvalue = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
  stsNmesAll = [];
  stsNvalue = JSON.parse(JSON.stringify(ConstantsJson.initTabs));

  dshbrdDataErrExcp = [];
  dtOpened = '';
  filterOpened = [];
  chkOnly = false;
  noSearchResult = false;

  startdateDudtN = new Date();
  enddateDudtN = new Date();
  startdateBkdtN = new Date();
  enddateBkdtN = new Date();
  startdateDedtN = new Date();
  enddateDedtN = new Date();
  startdateRedtN = new Date();
  enddateRedtN = new Date();
  startdateColdtN = new Date();
  enddateColdtN = new Date();
  startdateIndtN = new Date();
  enddateIndtN = new Date();

  today = new Date();
  prevCol = '';
  hideColumnFlag = ConstantsJson.hideColumnFlag;
  activeFilter = ConstantsJson.activeFilter;
  activeSort = '';
  isDesc = true;
  column = '';
  dshbrdData = JSON.parse(JSON.stringify(ConstantsJson.dshbrdDataINIT));

  @Input() sortFilterCheckDshbrd;
  @Input() setDashbrdSortFilter;
  @Input() previousTab;
  sortFilterCheck = JSON.parse(JSON.stringify(ConstantsJson.srtFltrChck));
  dataHdrIsFixed = false;
  goToTop = false;
  isBkngAvlble = true;
  istempAvlble = true;
  minCharErr = false;
  accountList = [];
  tabFlgChnged = false;
  locationObject = [];
  res = [];
  allcity = [];
  apiCallCount = [];
  constructor(
    private _router: Router,
    private _booking: BookingService,
    private _jsEcd: JsEncoderService,
    private _shrdt: SharedataService,
    private _cd: ChangeDetectorRef,
    private _templateService: TemplateService
  ) {
    super();
  }

  @HostListener('window:scroll', [])
  onWindowScroll() {
    /**
     * fixed dashboard table header when user scrolls after few records
     */
    const number = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
    if (number > ConstantsVAR.DSHBRD_DATA_PAGE_SCRLL_HGHT) {
      this.dataHdrIsFixed = true;
      this.goToTop = true;
    } else if (this.dataHdrIsFixed && number < ConstantsVAR.DSHBRD_DATA_PAGE_SCRLL_HGHT) {
      this.dataHdrIsFixed = false;
      this.goToTop = false;
    }
  }


  ngOnInit() {
    window.scrollTo(0, 0);

    if (!JSON.parse(sessionStorage.getItem('srtFltrChk'))) {
      sessionStorage.setItem('srtFltrChk', JSON.stringify(this.sortFilterCheck));
    }

    const accKeyVal = this._jsEcd.decode(localStorage.getItem(ConstantsVAR.ACC_KEY));
    if (accKeyVal) {
      this.accountList = JSON.parse(accKeyVal)['cAccNoLi'];
    }

    this.checkBkng();
    this.checkTmplt();
  }

  ngOnChanges(changes: SimpleChanges) {
    this.showHideColTab();
    this.pagination();

    if (changes) {
      if (changes.sortFilterCheckDshbrd || changes.dshbrdDataRaw) {
        if (this.dshbrdDataRaw) {
          this.dshbrdDataChange = JSON.parse(JSON.stringify(this.dshbrdDataRaw));
        }
        this.sortFilterDataUpdate();
      }
      if (changes.pausePDF) {
        this.pausePDF = changes.pausePDF.currentValue;
      }
    }

    if (this.tabFlag !== 'SEARCH') {
      this.enableClear = false;
      this.isFilterSearch = false;
      this.isSearch = false;
      this.minCharErr = false;
    } if (this.tabFlag === 'SEARCH') {
      this.isFilterSearch = true;
      this.isFilter = false;
    }
    this.setFilterFlag();
  }

  checkBkng() {
    /**
     * check booking available for logged user
     */
    const requestBody: AccountListDTO = {
      'cAccNoLi': this.accountList
    };
    const apiName = 'checkBkng';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._booking.checkBkngAvailbility(requestBody).subscribe((val) => {
      if (val === 'true') {
        this.isBkngAvlble = true;
      } else if (val === 'false') {
        this.isBkngAvlble = false;
      }
      this.apiCallCount[apiName] = 0;
    }, (error) => {
      this.retryMechanism(error, apiName, '');
    }));
  }

  checkTmplt() {
    /**
     * check if any templates are available for logged user
     */
    const requestBody: AccountListDTO = {
      'cAccNoLi': this.accountList
    };
    const apiName = 'checkTmplt';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._templateService.checkTemplateAvailblty(requestBody).subscribe((val) => {
      if (val === 'true') {
        this.istempAvlble = true;
      } else if (val === 'false') {
        this.istempAvlble = false;
      }
      this.apiCallCount[apiName] = 0;
    }, (error) => {
      this.retryMechanism(error, apiName, '');
    }));
  }

  tntTrackTrace(data) {
    /**
     * method for navigating to track and trace using AWB/CON
    */
    if (this.checkAWB(data)) {
      const url = ConstantsURL.CONST_TNT_TRACKER + ConstantsURL.CONST_TNT_TRACKER_RES_CNTRY
        + this.logCountry + ConstantsURL.CONT_TNT_TRACKER_CON_NO + data.cNo;
      window.open(url, '_blank');
    }
  }

  checkAWB(data) {
    return (data.sId === this.collectedId || data.sId === this.exceptionId || data.sId === this.intransitId
      || data.sId === this.outfordelivery || data.sId === this.deliveredId);
  }

  pagination() {

    this.totalpage = Math.ceil(this.dataCount / this.pageLimit);
    this.pageSelect(1, 'F');

    if (sessionStorage.getItem('srtFltrChk')) {
      this.sortFilterCheck = JSON.parse(sessionStorage.getItem('srtFltrChk'));
    }
    if (this.previousTab) {
      this.sortFilterCheck['previousTab'] = this.previousTab;
    }

    this.sortFilterCheck['tabFlag'] = this.tabFlag;
    sessionStorage.setItem('srtFltrChk', JSON.stringify(this.sortFilterCheck));
    this.setFilterFlag();
  }

  setFilterFlag() {
    const sortFilterCheckDshbrd = JSON.parse(sessionStorage.getItem('srtFltrChk'));
    if (sortFilterCheckDshbrd) {
      if (sortFilterCheckDshbrd[this.tabFlag]) {
        if (sortFilterCheckDshbrd[this.tabFlag].filter.length > 0) {
          this.isFilterSearch = true;
          this.isFilter = true;
          if (!this._cd['destroyed']) {
            this._cd.detectChanges();
          }
        } else {
          if (this.tabFlag !== 'SEARCH') {
            this.isFilterSearch = false;
          }
          this.isFilter = false;
        }
      }
    }
  }

  pageSelect(i, flg) {
    /**
     * @param flg >> F = first, P = previous, I = inputValue, N = next, L = last
     * display booking data based on page select for confirmed booking, awaiting and completed booking.
     */
    if ((i < 1 || i > this.totalpage) && flg === 'I') {
      this.page = this.currPage;
    } else {
      if (((flg === 'F' || flg === 'P') && i >= 1) || ((flg === 'L' || flg === 'N') && i <= this.totalpage)
        || (flg === 'I' && i >= 1 && i <= this.totalpage)) {
        this.dshbrdData.err = [];
        this.dshbrdData.othrs = [];
        this.page = i;
        this.currPage = i;

        if (this.dshbrdDataChange) {
          this.rowCount = 0;
          if (this.dshbrdDataChange.err) {
            if (this.dshbrdDataChange.err.length < this.pageLimit) {
              if (i < ConstantsVAR.PAGE_2) {
                this.dshbrdData.err = this.dshbrdDataChange.err;
                if (this.dshbrdDataChange.othrs) {
                  this.dshbrdData.othrs = this.dshbrdDataChange.othrs.slice(0, (this.pageLimit - this.dshbrdDataChange.err.length));
                }
              } else {
                if (this.dshbrdDataChange.othrs) {
                  this.dshbrdData.othrs = this.dshbrdDataChange.othrs.slice((((i - 1) *
                    this.pageLimit) - this.dshbrdDataChange.err.length), (((i - 1) *
                      this.pageLimit) - this.dshbrdDataChange.err.length) + this.pageLimit);
                }
              }
            } else if (this.dshbrdDataChange.err.length === this.pageLimit) {
              if (i < ConstantsVAR.PAGE_2) {
                this.dshbrdData.err = this.dshbrdDataChange.err;
              } else {
                if (this.dshbrdDataChange.othrs) {
                  this.dshbrdData.othrs = this.dshbrdDataChange.othrs.slice((i - ConstantsVAR.PAGE_2)
                    * this.pageLimit, (i - 1) * (this.pageLimit));
                }
              }
            } else {
              const errPageJoin = Math.ceil(this.dshbrdDataChange.err.length / this.pageLimit);
              let othrsRestData;
              if (this.dshbrdDataChange.err.length % this.pageLimit) {
                othrsRestData = this.dshbrdDataChange.err.length % this.pageLimit;
              } else {
                othrsRestData = this.pageLimit;
              }
              const othrsStart = this.pageLimit - othrsRestData;
              if (i < errPageJoin) {
                this.dshbrdData.err = this.dshbrdDataChange.err.slice((i - 1) * this.pageLimit, i * (this.pageLimit));
              } else if (i === errPageJoin) {
                this.dshbrdData.err = this.dshbrdDataChange.err.slice((i - 1) * this.pageLimit, this.dshbrdDataChange.err.length);
                if (this.dshbrdDataChange.othrs) {
                  this.dshbrdData.othrs = this.dshbrdDataChange.othrs.slice(0, this.pageLimit - this.dshbrdData.err.length);
                }
              } else {
                if (this.dshbrdDataChange.othrs) {
                  this.dshbrdData.othrs = this.dshbrdDataChange.othrs.slice((((i - errPageJoin - 1) * this.pageLimit) + othrsStart),
                    ((i - errPageJoin - 1) * this.pageLimit) + othrsStart + this.pageLimit);
                }
              }
            }
          } else if (this.dshbrdDataChange.othrs) {
            this.dshbrdData.othrs = this.dshbrdDataChange.othrs.slice((i - 1) * this.pageLimit, i * (this.pageLimit));
          }
          this.rowCount = this.dshbrdData.err.length + this.dshbrdData.othrs.length;
        }
      }
    }
  }

  sortFilterDataUpdate() {
    this.sortFilterCheckDshbrd = JSON.parse(sessionStorage.getItem('srtFltrChk'));
    const tf = this.tabFlag;
    if (tf) {
      if (this.sortFilterCheckDshbrd) {
        if (this.sortFilterCheckDshbrd[tf]) {
          this.activeFilter = ConstantsJson.activeFilter;
          this.newActiveFilter = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
          if (this.sortFilterCheckDshbrd[tf].filter.length > 0) {
            this.dshBrdObjCheck();
            const isFilterAvailable = this.sortFilterCheckDshbrd[tf].filter.filter((el) => {
              try {
                this.newActiveFilter[tf][el.colm] = true;
              } catch (er) { }
            });
          } else if (this.sortFilterCheckDshbrd[tf].filter.length === 0) {
            if (this.dshbrdDataRaw) {
              this.dshbrdDataChange = this.filtersOfFilter[tf] = JSON.parse(JSON.stringify(this.dshbrdDataRaw));
              this.countBkng(this.dshbrdDataChange);
            }
          }

          if (this.sortFilterCheckDshbrd[tf].sort) {
            const prop = this.sortFilterCheckDshbrd[tf].sort['property'];
            const coln = this.activeSort = this.sortFilterCheckDshbrd[tf].sort['column'];
            const direction = this.sortFilterCheck[this.tabFlag].sort['dirctn'];
            this.sort(prop, coln, direction, this.ERR_EXCP_ONTOP);
          }
        }
      }
    }
  }

  gotoWizard() {
    /**
     * navigate to wizard page
     */
    this._router.navigate(['/booking/wizard']);
  }

  showHideColTab() {
    /**
     * toggle tabs and their booking data based on changes
     */
    if (!this.hideColumnFlagTemp) {
      if (this.tabFlag === 'CB' || this.tabFlag === 'DB' || this.tabFlag === 'SEARCH') {
        this.hideColumnFlagTemp = this.hideColumnFlag;
      }
    } else {
      this.hideColumnFlag = this.hideColumnFlagTemp;
    }

    const sortFilterCheckTEMP = JSON.parse(sessionStorage.getItem('srtFltrChk'));
    this.prevCol = sortFilterCheckTEMP ? sortFilterCheckTEMP[this.tabFlag].sort['property'] : '';

    if (this.tabFlag === 'AC') {
      this.hideColumnFlag = ConstantsJson.hideColumnFlagAC;
      if (this.bkngSortFlag) {
        this.alterUpdateSortDirection(false);
      }
    } else if (this.tabFlag === 'DB') {
      this.hideColumnFlag = ConstantsJson.hideColumnFlagDB;
    } else if (this.tabFlag === 'CB') {
      this.hideColumnFlag = ConstantsJson.hideColumnFlagCB;
    } else if (this.tabFlag === 'SEARCH') {
      this.hideColumnFlag = ConstantsJson.hideColumnFlagSEARCH;
    }

    if (this.searchInputValue) {
      this.searchInputModel = this.searchInputValue;
      this.searchInput = this.searchInputValue;
      if (!this._cd['destroyed']) {
        this._cd.detectChanges();
      }
      this.enableClear = true;
    } else if (this.searchInputValue === '') {
      this.searchInputModel = '';
      this.searchInput = '';
      if (!this._cd['destroyed']) {
        this._cd.detectChanges();
      }
      this.enableClear = false;
    }
  }

  ngOnDestroy() {
    this.sortFilterCheck = JSON.parse(JSON.stringify(ConstantsJson.srtFltrChck));
    this._cd.detach();
    this.subscriptions.forEach((subscription: Subscription) => { subscription.unsubscribe(); });
    Object.keys(this.apiSubscription).forEach(apiName => { this.apiUnsubscribe(apiName); });
  }

  alterUpdateSortDirection(flag) {
    this.sortFilterCheck = JSON.parse(sessionStorage.getItem('srtFltrChk'));
    this.isDesc = this.sortFilterCheck[this.tabFlag].sort['dirctn'] = flag;
    sessionStorage.setItem('srtFltrChk', JSON.stringify(this.sortFilterCheck));
  }

  search(data) {
    /**
     * get searched data from entire booking data
     */
    data = data.trim();

    if (data.length >= ConstantsVAR.BOOKING_SEARCH_VAL_REQ_LENGTH) {
      this.filtersOfFilter['SEARCH'] = [];
      this.minCharErr = false;
      this.searchInput = data;
      this.searchTxtValue.emit(this.searchInput);
      if (!this.searchInput) {
        this.clearSearch();
      } else {
        this.isFilterSearch = true;
        this.isSearch = true;
        this.enableClear = true;
        this.filtersOfFilter['SEARCH'] = [];
        this._shrdt.setFiltersOfFilter(0);
        this.emitSearch.emit(true);
      }
    } else if (data.length > 0 && data.length < ConstantsVAR.BOOKING_SEARCH_VAL_REQ_LENGTH) {
      this.minCharErr = true;
    } else if (data.length === 0) {
      this.minCharErr = false;
    }
    document.getElementById('search').click();
  }

  clearSearch() {
    /**
     * clear searched data from dashboard and retain default data on clicking close button
     */
    const clearSrch = JSON.parse(sessionStorage.getItem('srtFltrChk'));
    this.filtersOfFilter['SEARCH'] = [];
    clearSrch['SEARCH'] = JSON.parse(JSON.stringify(ConstantsJson.srtFltrChck))['SEARCH'];
    sessionStorage.setItem('srtFltrChk', JSON.stringify(clearSrch));

    this.stsNCheckbox['SEARCH'] = [];
    this.minCharErr = false;
    this.searchInput = '';
    this.emitSearch.emit(false);
    this.enableClear = false;
    this.isFilterSearch = false;
    this.isSearch = false;
    this.searchTxtValue.emit('');
    this._shrdt.setSearchInput('');
  }

  deleteBooking(data) {
    if (!this.deleteDisable(data)) {
      this.clicked = false;
      this.deleteBookingData.emit(data);
    }
    this.clicked = false;
  }

  sendConfrmReq(data) {
    this.clicked = false;
    if (!this.sendConfrmReqDisable(data)) {
      this.resendSndrEmail.emit(data);
    }
  }

  columnConfig() {
    this.clicked = false;
    /* REQUIRED */
    // this.columnConfigEmit.emit('');
  }

  sendPaperwork(data) {
    this.clicked = false;
    if (!this.sendPaperworkDisable(data)) {
      this.emitEmail.emit(data);
    }
  }

  downloadPaperwork(data) {
    this.clicked = false;
    if (!this.downloadPaperworkDisable(data)) {
      this.emitPaperwork.emit(data);
    }
  }

  editDisable(data) {
    if ((data.sId !== this.draftId) && (data.sId !== this.awaitingId)) {
      return true;
    } else {
      return false;
    }
  }

  deleteDisable(data) {
    const status = [this.draftId, this.awaitingId, this.expiredId];
    if (!status.includes(data.sId)) {
      return true;
    } else {
      return false;
    }
  }

  sendConfrmReqDisable(data) {
    if (data.sId !== this.awaitingId) {
      return true;
    } else {
      return false;
    }
  }

  sendPaperworkDisable(data) {
    if (data.sId !== this.bookedId) {
      return true;
    } else {
      return false;
    }
  }

  downloadPaperworkDisable(data) {
    const status = [this.draftId, this.awaitingId, this.expiredId];
    if (status.includes(data.sId)) {
      return true;
    } else {
      return false;
    }
  }

  newBookingBtn() {
    if (this.istempAvlble) {
      this.callNewBookingBtn.emit('');
      if (this.searchInputValue) {
        this._shrdt.setSearchInput(this.searchInputValue);
      }
    }
  }

  showActionMenuBtn(i) {
    this.chkOnly = true;
    if (this.clicked && this.idx === i) {
      this.clicked = false;
    }
    this.idx = i;
  }

  closeActionMenu() {
    this.clicked = false;
  }

  editBooking(data) {
    if (!this.editDisable(data)) {
      this._shrdt.setBkngID(data.bId);
      if (this.searchInputValue) {
        this._shrdt.setSearchInput(this.searchInputValue);
      }
      setTimeout(() => {
        this._router.navigate(['/booking/complete-booking']);
      }, ConstantsVAR.MILISEC_100);
    }
    this.clicked = false;
  }

  viewEditBooking(data) {
    if (this.searchInputValue) {
      this._shrdt.setSearchInput(this.searchInputValue);
    }
    if (!this.editDisable(data)) {
      this.editBooking(data);
    } else {
      this._shrdt.setBkngID(data.bId);
      setTimeout(() => {
        this._router.navigate(['/booking/complete-booking']);
      }, ConstantsVAR.MILISEC_100);
    }
  }

  filterCheck(header, filterValue, value) {
    /**
     * checking / unchecking checkbox based on filter dropdown for concerned header.
     * by default all filter data of respected (column/header) will be in checked state.
     * all filter data is extracted from dashboard data.
     */
    if (header === 'accN') {
      this.accNmesAll = this.accNuniqueNames[this.tabFlag];
      for (let i = 0; i < this.accNmesAll.length + 1; i++) {
        if (filterValue === (i)) {
          if (!this.accNCheckbox[this.tabFlag][value]) {
            this.accNCheckbox[this.tabFlag][value] = true;
            if (value === 'ALL') {
              this.disableAccntFilterButton[this.tabFlag] = false;
              this.accNvalue[this.tabFlag] = JSON.parse(JSON.stringify(this.accNmesAll));
              for (let x = 0; x < this.accNmesAll.length; x++) {
                this.accNCheckbox[this.tabFlag][this.accNmesAll[x]] = true;
              }
            } else {
              if (this.accNvalue[this.tabFlag].indexOf(value) === -1) {
                this.accNvalue[this.tabFlag].push(value);
              }
              if (this.accNmesAll.length === 1) { this.accNCheckbox[this.tabFlag]['ALL'] = true; }
              this.disableAccntFilterButton[this.tabFlag] = false;
            }
          } else {
            this.accNCheckbox[this.tabFlag][value] = false;
            if (value === 'ALL') {
              this.accNvalue[this.tabFlag] = [];
              for (let x = 0; x < this.accNmesAll.length; x++) {
                this.accNCheckbox[this.tabFlag][this.accNmesAll[x]] = false;
              }
              this.disableAccntFilterButton[this.tabFlag] = true;
            } else {
              const index = this.accNvalue[this.tabFlag].indexOf(value);
              if (index > -1) {
                this.accNvalue[this.tabFlag].splice(index, 1);
              }
              if (!this.accNvalue[this.tabFlag].length) { this.disableAccntFilterButton[this.tabFlag] = true; }

              this.accNCheckbox[this.tabFlag]['ALL'] = false;
            }
          }
        }
      }
    } else if (header === 'srvcN') {
      this.srvcNmesAll = this.srvcNuniqueNames[this.tabFlag];
      for (let i = 0; i < this.srvcNmesAll.length + 1; i++) {
        if (filterValue === (i)) {
          if (!this.srvcNCheckbox[this.tabFlag][value]) {
            this.srvcNCheckbox[this.tabFlag][value] = true;
            if (value === 'ALL') {
              this.disableSrvsFilterButton[this.tabFlag] = false;
              this.srvcNvalue[this.tabFlag] = JSON.parse(JSON.stringify(this.srvcNmesAll));
              for (let x = 0; x < this.srvcNmesAll.length; x++) {
                this.srvcNCheckbox[this.tabFlag][this.srvcNmesAll[x]] = true;
              }
            } else {
              this.disableSrvsFilterButton[this.tabFlag] = false;
              if (this.srvcNvalue[this.tabFlag].indexOf(value) === -1) {
                this.srvcNvalue[this.tabFlag].push(value);
              }
              this.srvcNCheckbox[this.tabFlag]['ALL'] = (this.srvcNmesAll.length === this.srvcNvalue[this.tabFlag].length) ? true : false;
            }
          } else {
            this.srvcNCheckbox[this.tabFlag][value] = false;
            if (value === 'ALL') {
              this.disableSrvsFilterButton[this.tabFlag] = true;
              this.srvcNvalue[this.tabFlag] = [];
              for (let x = 0; x < this.srvcNmesAll.length; x++) {
                this.srvcNCheckbox[this.tabFlag][this.srvcNmesAll[x]] = false;
              }
            } else {
              const index = this.srvcNvalue[this.tabFlag].indexOf(value);
              if (index > -1) {
                this.srvcNvalue[this.tabFlag].splice(index, 1);
              }
              if (!this.srvcNvalue[this.tabFlag].length) { this.disableSrvsFilterButton[this.tabFlag] = true; }
              this.srvcNCheckbox[this.tabFlag]['ALL'] = false;
            }
          }
        }
      }
    } else if (header === 'colnN-cntry') {
      this.colnNmesAllCntry = this.colnNuniqueNamesCntry[this.tabFlag];

      for (let i = 0; i < this.colnNmesAllCntry.length + 1; i++) {
        if (filterValue === (i)) {
          if (!this.colnNCheckboxCntry[this.tabFlag][value]) {
            this.colnNCheckboxCntry[this.tabFlag][value] = true;

            if (value === 'ALL') {
              this.disableColnFilterButton[this.tabFlag] = false;
              this.colnCntryNvalue[this.tabFlag] = (!this.filtersOfFilter[this.tabFlag].length) ?
                this.getCollectionCountry() : this.otherFilterData('cCnty');
              this.colnNvalue[this.tabFlag] = (!this.filtersOfFilter[this.tabFlag].length) ?
                this.getCollectionCity() : this.otherFilterData('cCty');
              this.colnNuniqueNamesCity[this.tabFlag] = (!this.filtersOfFilter[this.tabFlag].length) ?
                this.getCollectionCity() : this.otherFilterData('cCty');
              this.colnNmesAllCntry.filter((el) => {
                this.colnNCheckboxCntry[this.tabFlag][el] = true;
              });
              this.colnNuniqueNamesCity[this.tabFlag].filter((el) => {
                this.colnNCheckboxCity[this.tabFlag][el] = true;
              });
              this.colnNCheckboxCity[this.tabFlag]['ALL'] = true;
            } else {
              const city = this.getCity(value);
              this.colnNuniqueNamesCity[this.tabFlag] = this.colnNuniqueNamesCity[this.tabFlag].concat(this.getCity(value)).sort();
              city.filter((el) => {
                this.colnNCheckboxCity[this.tabFlag][el] = true;
              });
              this.colnCntryNvalue[this.tabFlag].push(value);
              this.colnNvalue[this.tabFlag] = this.colnNvalue[this.tabFlag].concat(this.getCity(value));
              this.disableColnFilterButton[this.tabFlag] = false;
              if (this.colnNvalue[this.tabFlag].length === this.colnNuniqueNamesCity[this.tabFlag].length) {
                this.colnNCheckboxCity[this.tabFlag]['ALL'] = true;
              }
              if (this.colnCntryNvalue[this.tabFlag].length === this.colnNmesAllCntry.length) {
                this.colnNCheckboxCntry[this.tabFlag]['ALL'] = true
              }
            }
          } else {
            this.colnNCheckboxCntry[this.tabFlag][value] = false;
            if (value === 'ALL') {
              this.disableColnFilterButton[this.tabFlag] = true;
              if (this.colnNuniqueNamesCity[this.tabFlag]) {
                this.colnNuniqueNamesCity[this.tabFlag] = [];
              }
              this.colnNvalue[this.tabFlag] = [];
              this.colnCntryNvalue[this.tabFlag] = [];
              for (let x = 0; x < this.colnNmesAllCntry.length; x++) {
                this.colnNCheckboxCntry[this.tabFlag][this.colnNmesAllCntry[x]] = false;
              }
              this.colnNCheckboxCity[this.tabFlag]['ALL'] = false;
            } else {

              this.removeCollectionCity(value);
              this.removeCityFromList(value);
              const index = this.colnCntryNvalue[this.tabFlag].indexOf(value);
              if (index > -1) {
                this.colnCntryNvalue[this.tabFlag].splice(index, 1);
              }
              if (!this.colnNuniqueNamesCity[this.tabFlag].length) {
                this.disableColnFilterButton[this.tabFlag] = true;
              }
              this.colnNCheckboxCntry[this.tabFlag]['ALL'] = false;
            }
          }
        }
      }
    } else if (header === 'colnN') {
      this.colnNmesAll = this.colnNuniqueNamesCity[this.tabFlag];
      for (let i = 0; i < this.colnNmesAll.length + 1; i++) {
        if (filterValue === (i)) {
          if (!this.colnNCheckboxCity[this.tabFlag][value]) {
            this.colnNCheckboxCity[this.tabFlag][value] = true;
            if (value === 'ALL') {
              this.colnNvalue[this.tabFlag] = JSON.parse(JSON.stringify(this.colnNmesAll));
              this.colnNmesAll.filter((el) => {
                this.colnNCheckboxCity[this.tabFlag][el] = true;
              });
            } else {
              if (this.colnNvalue[this.tabFlag].indexOf(value) === -1) {
                this.colnNvalue[this.tabFlag].push(value);
              }
              this.colnNCheckboxCity[this.tabFlag]['ALL'] =
                (this.colnNmesAll.length === this.colnNvalue[this.tabFlag].length) ? true : false;
            }
          } else {
            this.colnNCheckboxCity[this.tabFlag][value] = false;
            if (value === 'ALL') {
              this.colnNvalue[this.tabFlag] = [];
              this.colnNmesAll.filter((el) => {
                this.colnNCheckboxCity[this.tabFlag][el] = false;
              });
            } else {
              const index = this.colnNvalue[this.tabFlag].indexOf(value);
              if (index > -1) {
                this.colnNvalue[this.tabFlag].splice(index, 1);
              }
              this.colnNCheckboxCity[this.tabFlag]['ALL'] = false;
            }
          }
        }
      }
    } else if (header === 'delN-cntry') {
      this.delNmesAllCntry = this.delNuniqueNamesCntry[this.tabFlag];
      for (let i = 0; i < this.delNmesAllCntry.length + 1; i++) {
        if (filterValue === (i)) {
          if (!this.delNCheckboxCntry[this.tabFlag][value]) {
            this.delNCheckboxCntry[this.tabFlag][value] = true;
            if (value === 'ALL') {
              this.disableDelnFilterButton[this.tabFlag] = false;
              this.delNCntryNvalue[this.tabFlag] = (!this.filtersOfFilter[this.tabFlag].length) ?
                this.getDeliveryCountry() : this.otherFilterData('dCnty');
              this.delNvalue[this.tabFlag] = (!this.filtersOfFilter[this.tabFlag].length) ?
                this.getDeliveryCity() : this.otherFilterData('dCty');
              this.delNuniqueNamesCity[this.tabFlag] = (!this.filtersOfFilter[this.tabFlag].length) ?
                this.getDeliveryCity() : this.otherFilterData('dCnty');
              this.delNmesAllCntry.filter((el) => {
                this.delNCheckboxCntry[this.tabFlag][el] = true;
              });
              this.delNuniqueNamesCity[this.tabFlag].filter((el) => {
                this.delNCheckboxCity[this.tabFlag][el] = true;
              });
              this.delNCheckboxCity[this.tabFlag]['ALL'] = true;
            } else {

              const city = this.getDelCity(value);
              this.delNuniqueNamesCity[this.tabFlag] = this.delNuniqueNamesCity[this.tabFlag].concat(this.getDelCity(value)).sort();
              city.filter((el) => {
                this.delNCheckboxCity[this.tabFlag][el] = true;
              })
              this.delNvalue[this.tabFlag] = this.delNvalue[this.tabFlag].concat(this.getDelCity(value));
              this.disableDelnFilterButton[this.tabFlag] = false;
              if (this.delNvalue[this.tabFlag].length === this.delNuniqueNamesCity[this.tabFlag].length) {
                this.delNCheckboxCity[this.tabFlag]['ALL'] = true;
              }
              if (this.delNCntryNvalue[this.tabFlag].length === this.delNmesAllCntry.length) {
                this.delNCheckboxCntry[this.tabFlag]['ALL'] = true
              }
            }
          } else {
            this.delNCheckboxCntry[this.tabFlag][value] = false;
            if (value === 'ALL') {
              this.disableDelnFilterButton[this.tabFlag] = true;
              if (this.delNuniqueNamesCity[this.tabFlag]) {
                this.delNuniqueNamesCity[this.tabFlag] = [];
              }
              this.delNvalue[this.tabFlag] = [];
              this.delNCntryNvalue[this.tabFlag] = [];
              if (!this.delNvalue[this.tabFlag].length && !this.delNCntryNvalue[this.tabFlag].length) {
                this.disableColnFilterButton[this.tabFlag] = true;
              }
              for (let x = 0; x < this.delNmesAllCntry.length; x++) {
                this.delNCheckboxCntry[this.tabFlag][this.delNmesAllCntry[x]] = false;
              }
              this.delNCheckboxCity[this.tabFlag]['ALL'] = false;
            } else {
              this.removeDelCity(value);
              this.removeDeliveryCityFromList(value);
              const index = this.delNCntryNvalue[this.tabFlag].indexOf(value);
              if (index > -1) {
                this.delNCntryNvalue[this.tabFlag].splice(index, 1);
              }
              if (!this.delNuniqueNamesCity[this.tabFlag].length) {
                this.disableDelnFilterButton[this.tabFlag] = true;
              }
              this.delNCheckboxCntry[this.tabFlag]['ALL'] = false;
            }
          }
        }
      }
    } else if (header === 'delN') {
      this.delNmesAll = this.delNuniqueNamesCity[this.tabFlag];
      for (let i = 0; i < this.delNmesAll.length + 1; i++) {
        if (filterValue === (i)) {
          if (!this.delNCheckboxCity[this.tabFlag][value]) {
            this.delNCheckboxCity[this.tabFlag][value] = true;
            if (value === 'ALL') {
              this.delNvalue[this.tabFlag] = JSON.parse(JSON.stringify(this.delNmesAll));
              this.delNmesAll.filter((el) => {
                this.delNCheckboxCity[this.tabFlag][el] = true;
              })
            } else {
              if (this.delNvalue[this.tabFlag].indexOf(value) === -1) {
                this.delNvalue[this.tabFlag].push(value);
              }
              this.colnNCheckboxCity[this.tabFlag]['ALL'] =
                (this.colnNmesAll.length === this.colnNvalue[this.tabFlag].length) ? true : false;
            }
          } else {
            this.delNCheckboxCity[this.tabFlag][value] = false;
            if (value === 'ALL') {
              this.delNvalue[this.tabFlag] = [];
              this.delNmesAll.filter((el) => {
                this.delNCheckboxCity[this.tabFlag][el] = false;
              });
            } else {
              const index = this.delNvalue[this.tabFlag].indexOf(value);
              if (index > -1) {
                this.delNvalue[this.tabFlag].splice(index, 1);
              }
              this.delNCheckboxCity[this.tabFlag]['ALL'] = false;
            }
          }
        }
      }
    } else if (header === 'stsN') {
      this.stsNmesAll = this.stsNuniqueNames[this.tabFlag];
      for (let i = 0; i < this.stsNmesAll.length + 1; i++) {
        if (filterValue === (i)) {
          if (!this.stsNCheckbox[this.tabFlag][value]) {
            this.stsNCheckbox[this.tabFlag][value] = true;
            if (value === 'ALL') {
              this.disableStsFilterButton[this.tabFlag] = false;
              if (!this.stsNuniqueNames[this.tabFlag].length) {
                this.disableStsFilterButton[this.tabFlag] = true;
              }
              this.stsNvalue[this.tabFlag] = JSON.parse(JSON.stringify(this.stsNmesAll));
              for (let x = 0; x < this.stsNmesAll.length; x++) {
                this.stsNCheckbox[this.tabFlag][this.stsNmesAll[x]] = true;
              }
            } else {
              this.disableStsFilterButton[this.tabFlag] = false;
              if (this.stsNvalue[this.tabFlag].indexOf(value) === -1) {
                this.stsNvalue[this.tabFlag].push(value);
              }
              this.stsNCheckbox[this.tabFlag]['ALL'] = (this.stsNmesAll.length === this.stsNvalue[this.tabFlag].length) ? true : false;
            }
          } else {
            this.stsNCheckbox[this.tabFlag][value] = false;
            if (value === 'ALL') {
              this.disableStsFilterButton[this.tabFlag] = true;
              this.stsNvalue[this.tabFlag] = [];
              for (let x = 0; x < this.stsNmesAll.length; x++) {
                this.stsNCheckbox[this.tabFlag][this.stsNmesAll[x]] = false;
              }
            } else {
              const index = this.stsNvalue[this.tabFlag].indexOf(value);
              if (index > -1) {
                this.stsNvalue[this.tabFlag].splice(index, 1);
              }
              if (!this.stsNvalue[this.tabFlag].length) { this.disableStsFilterButton[this.tabFlag] = true; }
              this.stsNCheckbox[this.tabFlag]['ALL'] = false;
            }
          }
        }
      }
    }
  }

  filterOK(colmHdr) {
    /**
     * get data to filter based on column from booking dashboard data
     */
    if (colmHdr === 'accN') {
      if (this.accNvalue[this.tabFlag]) {
        if (this.accNvalue[this.tabFlag].length !== this.accNuniqueNames[this.tabFlag].length) {
          this.removeColmFilter('cAccNo');
          this.addColmFilter('cAccNo', this.accNvalue[this.tabFlag], colmHdr);
          this.newActiveFilter[this.tabFlag][colmHdr] = true;
        }
      }

    } else if (colmHdr === 'srvcN') {
      try {
        if (this.srvcNvalue[this.tabFlag].length !== this.srvcNuniqueNames[this.tabFlag].length) {
          this.removeColmFilter('svcNm');
          this.addColmFilter('svcNm', this.srvcNvalue[this.tabFlag], colmHdr);
          this.newActiveFilter[this.tabFlag][colmHdr] = true;
        }
      } catch (err) {

      }
    } else if (colmHdr === 'colnN') {
      if (!this.colnNvalue[this.tabFlag].length) {
        let colnCount = 0;
        this.colnNuniqueNamesCntry[this.tabFlag].filter((el) => {
          if (this.colnNCheckboxCntry[this.tabFlag][el] === true) { colnCount++; }
        });
        if (colnCount === this.colnNuniqueNamesCntry[this.tabFlag].length) {
        } else {
          const selectedCountry = [];
          this.colnNuniqueNamesCntry[this.tabFlag].filter((el) => {
            if (this.colnNCheckboxCntry[this.tabFlag][el] === true) {
              selectedCountry.push(el);
            }
          });
          this.colnNvalue[this.tabFlag] = this.getCollectionCityFromCountry(selectedCountry);
          this.removeColmFilter('cCty');
          this.addColmFilter('cCty', this.colnNvalue[this.tabFlag], colmHdr);
          this.colnNvalue[this.tabFlag] = [];
          this.newActiveFilter[this.tabFlag][colmHdr] = true;
        }

      } else {
        if (this.colnNvalue[this.tabFlag].length !== this.colnNuniqueNamesCity[this.tabFlag].length) {
          this.removeColmFilter('cCty');
          this.addColmFilter('cCty', this.colnNvalue[this.tabFlag], colmHdr);
          this.newActiveFilter[this.tabFlag][colmHdr] = true;
        } else {
          if (this.colnNvalue[this.tabFlag].length !== this.getCollectionCity().length) {
            const getOtherFilter = this.otherFilterData('cCty');
            if (getOtherFilter) {
              if (this.colnNvalue[this.tabFlag].length !== getOtherFilter.length) {
                this.removeColmFilter('cCty');
                this.addColmFilter('cCty', this.colnNvalue[this.tabFlag], colmHdr);
                this.newActiveFilter[this.tabFlag][colmHdr] = true;
              }
            } else {
              this.removeColmFilter('cCty');
              this.addColmFilter('cCty', this.colnNvalue[this.tabFlag], colmHdr);
              this.newActiveFilter[this.tabFlag][colmHdr] = true;
            }
          }

        }
      }

    } else if (colmHdr === 'delN') {

      if (!this.delNvalue[this.tabFlag].length) {
        let colnCount = 0;
        this.delNuniqueNamesCntry[this.tabFlag].filter((el) => {
          if (this.delNCheckboxCntry[this.tabFlag][el] === true) { colnCount++; }
        });
        if (colnCount === this.delNuniqueNamesCntry[this.tabFlag].length) {
        } else {
          const selectedCountry = [];
          this.delNuniqueNamesCntry[this.tabFlag].filter((el) => {
            if (this.delNCheckboxCntry[this.tabFlag][el] === true) {
              selectedCountry.push(el);
            }
          });
          this.delNvalue[this.tabFlag] = this.getDeliveryCityFromCountry(selectedCountry);
          this.removeColmFilter('dCty');
          this.addColmFilter('dCty', this.delNvalue[this.tabFlag], colmHdr);
          this.delNvalue[this.tabFlag] = [];
          this.newActiveFilter[this.tabFlag][colmHdr] = true;
        }

      } else {
        if (this.delNvalue[this.tabFlag].length !== this.delNuniqueNamesCity[this.tabFlag].length) {
          this.removeColmFilter('dCty');
          this.addColmFilter('dCty', this.delNvalue[this.tabFlag], colmHdr);
          this.newActiveFilter[this.tabFlag][colmHdr] = true;
        } else {

          if (this.delNvalue[this.tabFlag].length !== this.getDeliveryCity().length) {
            const getOtherFilter = this.otherFilterData('dCty');
            if (getOtherFilter) {
              if (this.delNvalue[this.tabFlag].length !== getOtherFilter.length) {
                this.removeColmFilter('dCty');
                this.addColmFilter('dCty', this.delNvalue[this.tabFlag], colmHdr);
                this.newActiveFilter[this.tabFlag][colmHdr] = true;
              }
            } else {
              this.removeColmFilter('dCty');
              this.addColmFilter('dCty', this.delNvalue[this.tabFlag], colmHdr);
              this.newActiveFilter[this.tabFlag][colmHdr] = true;
            }
          }
        }
      }
    } else if (colmHdr === 'stsN') {
      try {
        if (this.stsNvalue[this.tabFlag].length !== this.stsNuniqueNames[this.tabFlag].length) {
          this.removeColmFilter('sNm');
          this.addColmFilter('sNm', this.stsNvalue[this.tabFlag], colmHdr);
          this.newActiveFilter[this.tabFlag][colmHdr] = true;
        }
      } catch (err) { }
    }

  }

  removeColmFilter(val) {
    /**
     * remove collection / delivery cit(y/ies) from local storage based on key form dashboard data
     */
    this.sortFilterCheck[this.tabFlag].filter = this.sortFilterCheck[this.tabFlag].filter.filter((el) => {
      return el.key !== val;
    });
    sessionStorage.setItem('srtFltrChk', JSON.stringify(this.sortFilterCheck));
    this.dshBrdObjCheck();
  }

  addColmFilter(val, arr, colmHdr) {
    /**
     * add filtered collection / delivery cit(y/ies) from dashboard to local storage based on key and column
     */
    if (!this.sortFilterCheck[this.tabFlag].filter.length) {
      this.sortFilterCheck[this.tabFlag].filter.push({ 'key': val, 'value': arr, 'colm': colmHdr });
    } else {
      this.sortFilterCheck[this.tabFlag].filter.filter((el) => {
        if (el.key !== val) {
          this.sortFilterCheck[this.tabFlag].filter.push({ 'key': val, 'value': arr, 'colm': colmHdr });
        }
      });
    }
    sessionStorage.setItem('srtFltrChk', JSON.stringify(this.sortFilterCheck));
    this._shrdt.setFiltersOfFilter(this.filtersOfFilter[this.tabFlag].length);
    this.dshBrdObjCheck();
  }

  getAccountsData() {
    /**
     * get list of account based on logged user
     */
    let accountErr, accountOthr, accountAll
    try {
      accountErr = (this.dshbrdDataRaw.err) ? Array.from(new Set(this.dshbrdDataRaw.err.map(({ cAccNo }) => cAccNo)).values()) : [];
      accountOthr = (this.dshbrdDataRaw.othrs) ? Array.from(new Set(this.dshbrdDataRaw.othrs.map(({ cAccNo }) => cAccNo)).values()) : [];
      accountAll = accountErr.concat(accountOthr);
      return accountAll.filter(function (item, pos, self) {
        return self.indexOf(item) === pos;
      }).sort();
    } catch (err) { }
  }

  accNgetUnique() {
    /**
     * display filter dropdown with list of logged user account
     * show checked on list of account(s) when filter has applied
    */
    this.accNuniqueNames[this.tabFlag] = (!this.filtersOfFilter[this.tabFlag].length) ?
      this.getAccountsData() : this.otherFilterData('cAccNo');
    this.disableAccntFilterButton[this.tabFlag] = false;
    const isFilterAvailable = this.getFilterAvailable('cAccNo');
    if (!isFilterAvailable.length) {
      if (this.accNvalue[this.tabFlag].length !== this.accNuniqueNames[this.tabFlag]) {
        this.accNvalue[this.tabFlag] = [];
        this.accNvalue[this.tabFlag] = this.accNvalue[this.tabFlag].concat(this.accNuniqueNames[this.tabFlag]);
      }
      this.disableAccntFilterButton[this.tabFlag] = false;
      this.setCheckboxSelection(this.accNuniqueNames, this.accNCheckbox);
    } else {
      this.disableAccntFilterButton[this.tabFlag] = false;
      this.accNvalue[this.tabFlag] = [];
      this.clearCheckboxSelection(this.accNuniqueNames, this.accNCheckbox);
      isFilterAvailable.filter((el) => {
        this.accNvalue[this.tabFlag] = this.accNvalue[this.tabFlag].concat(el.value);
        this.accNCheckbox[this.tabFlag]['ALL'] = (el.value.length === this.accNuniqueNames[this.tabFlag].length) ? true : false;
        el.value.filter((val) => {
          this.accNCheckbox[this.tabFlag][val] = true;
        });
      });
    }
  }

  getServiceData() {
    /**
     * return list of service data from booking data (eg, Express Economy, Premium)
     */
    let serviceErr, serviceOthr, serviceAll
    try {
      serviceErr = (this.dshbrdDataRaw.err) ? Array.from(new Set(this.dshbrdDataRaw.err.map(({ svcNm }) => svcNm)).values()) : [];
      serviceOthr = (this.dshbrdDataRaw.othrs) ? Array.from(new Set(this.dshbrdDataRaw.othrs.map(({ svcNm }) => svcNm)).values()) : [];
      serviceAll = serviceErr.concat(serviceOthr);
      return serviceAll.filter(function (item, pos, self) {
        return self.indexOf(item) === pos;
      }).sort();
    } catch (err) { }
  }

  otherFilterData(data) {
    /**
      * return booking filtered data if any of the previous filters are applied
      */
    let appliedFilter = [];
    try {
      if (this.filtersOfFilter[this.tabFlag]) {
        this.filtersOfFilter[this.tabFlag].filter((el) => {
          appliedFilter.push(el[data])
        });
      }
      return appliedFilter = appliedFilter.filter(function (item, pos, self) {
        return self.indexOf(item) === pos;
      }).sort();
    } catch (err) { }

  }

  srvcNgetUnique() {
    /**
     * display filter dropdown with list of services available for booking done.
     * show checked on list of service(s) when filter has applied.
    */
    const isFilterAvailable = this.getFilterAvailable('svcNm');
    this.srvcNuniqueNames[this.tabFlag] = (!this.filtersOfFilter[this.tabFlag].length) ?
      this.getServiceData() : this.otherFilterData('svcNm');
    if (!isFilterAvailable.length) {
      if (this.srvcNvalue[this.tabFlag].length !== this.srvcNuniqueNames[this.tabFlag]) {
        this.srvcNvalue[this.tabFlag] = [];
        this.srvcNvalue[this.tabFlag] = this.srvcNvalue[this.tabFlag].concat(this.srvcNuniqueNames[this.tabFlag]);
      }
      this.disableSrvsFilterButton[this.tabFlag] = false;
      this.setCheckboxSelection(this.srvcNuniqueNames, this.srvcNCheckbox);
    } else {
      this.disableSrvsFilterButton[this.tabFlag] = false;
      this.srvcNvalue[this.tabFlag] = [];
      this.clearCheckboxSelection(this.srvcNuniqueNames, this.srvcNCheckbox);
      this.srvcNvalue[this.tabFlag] = this.srvcNvalue[this.tabFlag].concat(this.srvcNuniqueNames[this.tabFlag]);
      this.srvcNuniqueNames[this.tabFlag] = this.srvcNuniqueNames[this.tabFlag];
      this.srvcNCheckbox[this.tabFlag]['ALL'] = (this.srvcNuniqueNames[this.tabFlag].length ===
        this.srvcNuniqueNames[this.tabFlag].length) ? true : false;
      this.srvcNuniqueNames[this.tabFlag].filter((val) => {
        this.srvcNCheckbox[this.tabFlag][val] = true;
      });

    }
  }

  getCity(val) {
    /**
     * return list of collection cit(y/ies) from booking data
     */
    try {
      this.res = [];
      if (!this.filtersOfFilter[this.tabFlag].length) {
        /**
        * check if no collection cit(y/ies) filters are applied.
        */
        if (this.dshbrdDataRaw.err) {
          this.dshbrdDataRaw.err.filter((el) => {
            return (el.cCnty === val) ? this.res.push(el.cCty) : null;
          });
        }

        this.dshbrdDataRaw.othrs.filter((el) => {
          return (el.cCnty === val) ? this.res.push(el.cCty) : null;
        });
      } else {
        const filtersOfFilters = this.filtersOfFilter[this.tabFlag];
        filtersOfFilters.filter((el) => {
          return (el.cCnty === val) ? this.res.push(el.cCty) : null;
        });
      }

      return this.res.filter((item, pos, self) => {
        return self.indexOf(item) === pos;
      });
    } catch (err) {

    }

  }

  getDelCity(val) {
    /**
     * return list of delivery cit(y/ies) from booking data
     */
    try {
      this.res = [];
      if (!this.filtersOfFilter[this.tabFlag].length) {
        /**
         * check if no delivery cit(y/ies) filters are applied.
         */
        if (this.dshbrdDataRaw.err) {
          this.dshbrdDataRaw.err.filter((el) => {
            return (el.dCnty === val) ? this.res.push(el.dCty) : null;
          });
        }

        this.dshbrdDataRaw.othrs.filter((el) => {
          return (el.dCnty === val) ? this.res.push(el.dCty) : null;
        });
      } else {
        const filtersOfFilters = this.filtersOfFilter[this.tabFlag];
        filtersOfFilters.filter((el) => {
          return (el.dCnty === val) ? this.res.push(el.dCty) : null;
        });
      }

      return this.res.filter((item, pos, self) => {
        return self.indexOf(item) === pos;
      });
    } catch (err) {

    }
  }

  removeDelCity(val) {
    /**
     * remove delivery cit(y/ies) belong to respected country on unchecking delivery country in delivery filter data
     */
    const city = this.getDelCity(val);
    this.delNvalue[this.tabFlag] = this.delNvalue[this.tabFlag].filter(
      function (e) {
        return this.indexOf(e) < 0;
      },
      city
    );
  }

  removeCollectionCity(val) {
    /**
     * remove collection cit(y/ies) belong to respected country on unchecking collection country in collection filter data
     */
    const city = this.getCity(val);
    this.colnNvalue[this.tabFlag] = this.colnNvalue[this.tabFlag].filter(
      function (e) {
        return this.indexOf(e) < 0;
      },
      city
    );
  }

  removeCityFromList(val) {
    /**
     * remove collection cit(y/ies) belong to respected country on unchecking collection country in collection filter dropdown
     */
    const city = this.getCity(val);
    this.colnNuniqueNamesCity[this.tabFlag] = this.colnNuniqueNamesCity[this.tabFlag].filter(
      function (e) { return this.indexOf(e) < 0; }, city);
  }

  removeDeliveryCityFromList(val) {
    /**
     * remove delivery cit(y/ies) belong to respected country on unchecking delivery country in delivery filter dropdown
     */
    const city = this.getDelCity(val);
    this.delNuniqueNamesCity[this.tabFlag] = this.delNuniqueNamesCity[this.tabFlag].filter(
      function (e) { return this.indexOf(e) < 0; }, city);
  }

  getCollectionCity() {
    /**
     * return list of collection cit(y/ies) from booking data
     */
    try {
      if (this.dshbrdDataRaw) {
        let filterCountryErr
        if (this.dshbrdDataRaw.err) {
          filterCountryErr = Array.from(new Set(this.dshbrdDataRaw.err.map(({ cCty }) => cCty)).values());
        } else {
          filterCountryErr = [];
        }
        const filterCountryOthr = Array.from(new Set(this.dshbrdDataRaw.othrs.map(({ cCty }) => cCty)).values()).concat(filterCountryErr);
        return filterCountryOthr.filter(function (item, pos, self) {
          return self.indexOf(item) === pos;
        }).sort();
      }
    } catch (err) { }
  }

  getCollectionCountry() {
    /**
     * return list of collection countr(y/ies) from booking data
     */
    try {
      let filterCountryErr
      if (this.dshbrdDataRaw.err) {
        filterCountryErr = Array.from(new Set(this.dshbrdDataRaw.err.map(({ cCnty }) => cCnty)).values());
      } else {
        filterCountryErr = [];
      }
      const filterCountryOthr = Array.from(new Set(this.dshbrdDataRaw.othrs.map(({ cCnty }) => cCnty)).values()).concat(filterCountryErr);
      return filterCountryOthr.filter(function (item, pos, self) {
        return self.indexOf(item) === pos;
      }).sort();
    } catch (err) { }
  }

  getDeliveryCity() {
    /**
     * return list of delivery cit(y/ies) from booking data
     */
    try {
      let filterCountryErr
      if (this.dshbrdDataRaw.err) {
        filterCountryErr = Array.from(new Set(this.dshbrdDataRaw.err.map(({ dCty }) => dCty)).values());
      } else {
        filterCountryErr = [];
      }
      const filterCountryOthr = Array.from(new Set(this.dshbrdDataRaw.othrs.map(({ dCty }) => dCty)).values()).concat(filterCountryErr);
      return filterCountryOthr.filter(function (item, pos, self) {
        return self.indexOf(item) === pos;
      }).sort();
    } catch (err) { }
  }

  getDeliveryCountry() {
    /**
     * return list of delivery countr(y/ies) from booking data
     */
    try {
      let filterCountryErr
      if (this.dshbrdDataRaw.err) {
        filterCountryErr = Array.from(new Set(this.dshbrdDataRaw.err.map(({ dCnty }) => dCnty)).values());
      } else {
        filterCountryErr = [];
      }
      const filterCountryOthr = Array.from(new Set(this.dshbrdDataRaw.othrs.map(({ dCnty }) => dCnty)).values()).concat(filterCountryErr);
      return filterCountryOthr.filter(function (item, pos, self) {
        return self.indexOf(item) === pos;
      }).sort();
    } catch (err) { }
  }

  setCheckboxSelection(arr, checkbox) {
    /**
     * set all checkbox to checked state on selecting 'ALL' in collection and delivery filter dropdown for cit(y/ies) and count(y/ies)
     */
    try {
      arr[this.tabFlag].filter((el) => {
        checkbox[this.tabFlag][el] = true;
        checkbox[this.tabFlag]['ALL'] = true;
      });
    } catch (err) { }
  }

  clearCheckboxSelection(arr, checkbox) {
    /**
     * set all checkbox to unchecked state on unselecting 'ALL' in collection and delivery filter dropdown for cit(y/ies) and count(y/ies)
     */
    try {
      arr[this.tabFlag].filter((el) => {
        checkbox[this.tabFlag][el] = false;
      });
    } catch (err) { }
  }

  getCollectionCountryFromCity(arr) {
    /**
     * return list of collection countr(y/ies) of collection cit(y/ies) from booking data
     */
    const country = [];
    try {
      if (this.dshbrdDataRaw.err) {
        this.dshbrdDataRaw.err.filter((el) => {
          arr.filter((val) => {
            return (el.cCty === val) ? country.push(el.cCnty) : null;
          });
        });
      }

      this.dshbrdDataRaw.othrs.filter((el) => {
        arr.filter((val) => {
          return (el.cCty === val) ? country.push(el.cCnty) : null;
        });
      });
      return country.filter((item, pos, self) => {
        return self.indexOf(item) === pos;
      }).sort();
    } catch (err) { }
  }

  getDeliveryCountryFromCity(arr) {
    /**
     * return list of delivery countr(y/ies) of delivery cit(y/ies) from booking data
     */
    const country = [];
    try {
      if (this.dshbrdDataRaw.err) {
        this.dshbrdDataRaw.err.filter((el) => {
          arr.filter((val) => {
            return (el.dCty === val) ? country.push(el.dCnty) : null;
          });
        });
      }

      this.dshbrdDataRaw.othrs.filter((el) => {
        arr.filter((val) => {
          return (el.dCty === val) ? country.push(el.dCnty) : null;
        });
      });
      return country.filter((item, pos, self) => {
        return self.indexOf(item) === pos;
      }).sort();
    } catch (err) { }
  }

  getCollectionCityFromCountry(arr) {
    /**
     * return list of collection cit(y/ies) of collection countr(y/ies) from booking data
     */
    const city = [];
    try {
      if (this.dshbrdDataRaw.err) {
        this.dshbrdDataRaw.err.filter((el) => {
          arr.filter((val) => {
            return (el.cCnty === val) ? city.push(el.cCty) : null;
          });
        });
      }

      this.dshbrdDataRaw.othrs.filter((el) => {
        arr.filter((val) => {
          return (el.cCnty === val) ? city.push(el.cCty) : null;
        });
      });
      return city.filter((item, pos, self) => {
        return self.indexOf(item) === pos;
      }).sort();
    } catch (err) { }
  }

  getDeliveryCityFromCountry(arr) {
    /**
     * return list of delivery cit(y/ies) of delivery countr(y/ies) from booking data
     */
    const city = [];
    try {
      if (this.dshbrdDataRaw.err) {
        this.dshbrdDataRaw.err.filter((el) => {
          arr.filter((val) => {
            return (el.dCnty === val) ? city.push(el.dCty) : null;
          });
        });
      }

      this.dshbrdDataRaw.othrs.filter((el) => {
        arr.filter((val) => {
          return (el.dCnty === val) ? city.push(el.dCty) : null;
        });
      });
      return city.filter((item, pos, self) => {
        return self.indexOf(item) === pos;
      }).sort();
    } catch (err) { }
  }

  colnNgetUnique() {
    /**
     * display collection filter dropdwon with list of countr(y/ies) and cit(y/ies) from dashboard data
     * Conditional -> display collection filter dropdwon with list of countr(y/ies)
     * and cit(y/ies) if any other filter are applied from dashboard data
     */
    const isFilterAvailable = this.getFilterAvailable('cCty');
    this.colnNuniqueNamesCity[this.tabFlag] = (!this.filtersOfFilter[this.tabFlag].length) ?
      this.getCollectionCity() : this.otherFilterData('cCty');
    this.colnNuniqueNamesCntry[this.tabFlag] = (!this.filtersOfFilter[this.tabFlag].length) ?
      this.getCollectionCountry() : this.otherFilterData('cCnty');
    if (!isFilterAvailable.length) {
      /**
       * when no other filters are applied
       */
      if (this.colnNvalue[this.tabFlag].length !== this.colnNuniqueNamesCity[this.tabFlag]) {
        this.colnNvalue[this.tabFlag] = [];
        this.colnNvalue[this.tabFlag] = this.colnNvalue[this.tabFlag].concat(this.colnNuniqueNamesCity[this.tabFlag]);
      }
      this.disableColnFilterButton[this.tabFlag] = false;
      this.setCheckboxSelection(this.colnNuniqueNamesCity, this.colnNCheckboxCity);
      this.setCheckboxSelection(this.colnNuniqueNamesCntry, this.colnNCheckboxCntry);
    } else {
      /**
       * when any other filters are applied
       */
      this.disableColnFilterButton[this.tabFlag] = false;
      this.colnNvalue[this.tabFlag] = [];
      this.clearCheckboxSelection(this.colnNuniqueNamesCntry, this.colnNCheckboxCntry);
      this.clearCheckboxSelection(this.colnNuniqueNamesCity, this.colnNCheckboxCity);
      this.colnNvalue[this.tabFlag] = this.colnNvalue[this.tabFlag].concat(this.colnNuniqueNamesCity[this.tabFlag]);
      const newcountry = this.getCollectionCountryFromCity(this.colnNvalue[this.tabFlag]);
      this.colnNCheckboxCntry[this.tabFlag]['ALL'] = true;
      this.colnNCheckboxCity[this.tabFlag]['ALL'] = (this.colnNuniqueNamesCity[this.tabFlag].length
        === this.colnNuniqueNamesCity[this.tabFlag].length) ? true : false;
      this.colnNuniqueNamesCity[this.tabFlag].filter((val) => {
        this.colnNCheckboxCity[this.tabFlag][val] = true;
      });
      newcountry.filter((cnt) => {
        this.colnNCheckboxCntry[this.tabFlag][cnt] = true;
      });
    }
  }

  getFilterAvailable(data) {
    /**
* get if any filter data is present based on booking data key
*/
    return this.sortFilterCheck[this.tabFlag].filter.filter((el) => {
      if (el.key === data) {
        return el.value;
      }
    });
  }

  delNgetUnique() {
    /**
     * display delivery filter dropdwon with list of countr(y/ies) and cit(y/ies) from dashboard data
     * Conditional -> display delivery filter dropdwon with list of countr(y/ies) and
     * cit(y/ies) if any other filter are applied from dashboard data
     */
    const isFilterAvailable = this.getFilterAvailable('dCty');
    this.delNuniqueNamesCity[this.tabFlag] = (!this.filtersOfFilter[this.tabFlag].length) ?
      this.getDeliveryCity() : this.otherFilterData('dCty');
    this.delNuniqueNamesCntry[this.tabFlag] = (!this.filtersOfFilter[this.tabFlag].length) ?
      this.getDeliveryCountry() : this.otherFilterData('dCnty');
    if (!isFilterAvailable.length) {
      this.delNvalue[this.tabFlag] = this.getDeliveryCity();
      if (this.delNvalue[this.tabFlag].length !== this.delNuniqueNamesCity[this.tabFlag]) {
        this.delNvalue[this.tabFlag] = [];
        this.delNvalue[this.tabFlag] = this.delNvalue[this.tabFlag].concat(this.delNuniqueNamesCity[this.tabFlag]);
      }
      this.disableDelnFilterButton[this.tabFlag] = false;
      this.setCheckboxSelection(this.delNuniqueNamesCity, this.delNCheckboxCity);
      this.setCheckboxSelection(this.delNuniqueNamesCntry, this.delNCheckboxCntry);
    } else {
      this.disableDelnFilterButton[this.tabFlag] = false;
      this.delNvalue[this.tabFlag] = [];
      this.clearCheckboxSelection(this.delNuniqueNamesCity, this.delNCheckboxCity);
      this.clearCheckboxSelection(this.delNuniqueNamesCntry, this.delNCheckboxCntry);
      this.delNvalue[this.tabFlag] = this.delNvalue[this.tabFlag].concat(this.delNuniqueNamesCity[this.tabFlag]);
      const newcountry = this.getDeliveryCountryFromCity(this.delNvalue[this.tabFlag]);
      this.delNCheckboxCntry[this.tabFlag]['ALL'] = true;
      this.delNCheckboxCity[this.tabFlag]['ALL'] = (this.delNuniqueNamesCity[this.tabFlag].length
        === this.delNuniqueNamesCity[this.tabFlag].length) ? true : false;
      this.delNuniqueNamesCity[this.tabFlag].filter((val) => {
        this.delNCheckboxCity[this.tabFlag][val] = true;
      });
      newcountry.filter((cnt) => {
        this.delNCheckboxCntry[this.tabFlag][cnt] = true;
      });
    }
  }
  getStatusData() {
    /**
     * return status from booking data (eg; BOOKED, DRAFT, IN TRANSIT..,)
     */
    let statusErr, statusOthr, statusAll
    try {
      statusErr = (this.dshbrdDataRaw.err) ? Array.from(new Set(this.dshbrdDataRaw.err.map(({ sNm }) => sNm)).values()) : [];
      statusOthr = (this.dshbrdDataRaw.othrs) ? Array.from(new Set(this.dshbrdDataRaw.othrs.map(({ sNm }) => sNm)).values()) : [];
      statusAll = statusErr.concat(statusOthr);
      return statusAll.filter(function (item, pos, self) {
        return self.indexOf(item) === pos;
      }).sort();
    } catch (err) { }
  }

  stsNgetUnique() {
    /**
     * display list of status from booking data
     * Conditional -> display list of status if any other filter are applied from booking data
     */
    this.stsNuniqueNames[this.tabFlag] = (!this.filtersOfFilter[this.tabFlag].length) ? this.getStatusData() : this.otherFilterData('sNm');
    const isFilterAvailable = this.getFilterAvailable('sNm');
    if (!isFilterAvailable.length && this.tabFlag !== 'AC') {
      if (this.stsNvalue[this.tabFlag].length !== this.stsNuniqueNames[this.tabFlag]) {
        this.stsNvalue[this.tabFlag] = [];
        this.stsNvalue[this.tabFlag] = this.stsNvalue[this.tabFlag].concat(this.stsNuniqueNames[this.tabFlag]);
      }
      this.disableStsFilterButton[this.tabFlag] = false;
      this.setCheckboxSelection(this.stsNuniqueNames, this.stsNCheckbox);
    } else {
      if (this.tabFlag !== 'AC') {
        this.disableStsFilterButton[this.tabFlag] = false;
        this.stsNvalue[this.tabFlag] = [];
        this.clearCheckboxSelection(this.stsNuniqueNames, this.stsNCheckbox);
        this.stsNvalue[this.tabFlag] = this.stsNvalue[this.tabFlag].concat(this.stsNuniqueNames[this.tabFlag]);
        this.stsNuniqueNames[this.tabFlag] = this.stsNuniqueNames[this.tabFlag];
        this.stsNCheckbox[this.tabFlag]['ALL'] = (this.stsNuniqueNames[this.tabFlag].length
          === this.stsNuniqueNames[this.tabFlag].length) ? true : false;
        this.stsNuniqueNames[this.tabFlag].filter((val) => {
          this.stsNCheckbox[this.tabFlag][val] = true;
        });
      }
    }
  }

  goToTopClicked() {
    /**
     * scroll page to top / default view on landing
     */
    window.scrollTo(0, 0);
  }

  sort(property, colm, dirctnBoolean, flag?) {
    /**
     * sort data based on column (AWB/CON, SID NO, CUTOMER REF.., ) from dashboard data
     */

    if (this.tabFlag === 'CB' || this.tabFlag === 'SEARCH') {
      // CUSTOM SORT  with error/exceptions together  :: ONLY FOR Confirm Bookings tab ('CB)
      if (this.tabFlag === 'SEARCH') { flag = ''; }
      const srtFltrChk_temp = JSON.parse(sessionStorage.getItem('srtFltrChk'));
      if (flag !== this.ERR_EXCP_ONTOP || (srtFltrChk_temp ? srtFltrChk_temp['customSort'][this.tabFlag] : false)) {
        if (this.dshbrdDataChange ? this.dshbrdDataChange.err : false) {
          this.dshbrdDataChange.err = this.addErrFlag(this.dshbrdDataChange.err, true);
          if (!this.dshbrdDataChange.othrs) { this.dshbrdDataChange.othrs = []; }
          this.dshbrdDataChange.othrs = this.dshbrdDataChange.othrs.concat(this.dshbrdDataChange.err);
          this.dshbrdDataChange.err = [];
          srtFltrChk_temp['customSort'][this.tabFlag] = true;
          sessionStorage.setItem('srtFltrChk', JSON.stringify(srtFltrChk_temp));
        }
      } else {
        this.dshbrdDataChange = JSON.parse(JSON.stringify(this.dshbrdDataRaw));
        srtFltrChk_temp['customSort'][this.tabFlag] = false;
        sessionStorage.setItem('srtFltrChk', JSON.stringify(srtFltrChk_temp));
      }
    }

    this.activeSort = colm;
    this.sortFilterCheck = JSON.parse(sessionStorage.getItem('srtFltrChk'));

    this.isDesc = dirctnBoolean;
    this.column = this.prevCol = property;
    const direction = this.isDesc ? 1 : -1;

    let sortRequest = this.sortFilterCheck[this.tabFlag].sort; // check usage
    sortRequest = { 'property': property, 'column': colm, 'dirctn': this.isDesc };
    this.sortFilterCheck[this.tabFlag].sort = sortRequest;
    sessionStorage.setItem('srtFltrChk', JSON.stringify(this.sortFilterCheck));

    if (this.dshbrdDataChange) {
      if (this.dshbrdDataChange.err) {
        if (property !== 'cnRNm') {  // DELETE THIS CHECK WHEN CONTENT REF SORT IN PLACE
          this.sorted(this.dshbrdDataChange.err, 'ERR', property, direction, colm, this);
        }
      }
      if (this.dshbrdDataChange.othrs) {
        if (property !== 'cnRNm') {  // DELETE THIS CHECK WHEN CONTENT REF SORT IN PLACE
          this.sorted(this.dshbrdDataChange.othrs, 'OTH', property, direction, colm, this);
        }
      }
      this.pagination();
    }
  }

  addErrFlag(data, flag) {
    // this functions can be removed, check usage
    const result = data.map(function (el) {
      const ob = Object.assign({}, el);
      ob.isErr = flag;
      return ob;
    });
    return result;
  }

  sorted(data, flag, property, direction, colm, self) {
    /**
     * sort data for date from dashboard data
     */
    const dateSort = ['dudtN', 'bkdtN', 'dedtN', 'redtN', 'coldtN', 'indtN'];
    if (dateSort.indexOf(colm) > -1) {
      data.sort(function (a, b) {
        if (!a[property]) {
          a[property] = ConstantsVAR.DEFAULT_DATE;
        }
        if (!b[property]) {
          b[property] = ConstantsVAR.DEFAULT_DATE;
        }

        const dt1 = self.splitDates(a[property]);
        const dt2 = self.splitDates(b[property]);

        if (dt1 < dt2) {
          return -1 * direction;
        } else if (dt1 > dt2) {
          return 1 * direction;
        } else {
          return 0;
        }
      });
    } else {
      const reA = /[^a-zA-Z0-9]/g;
      data.sort(function (a, b) {
        if (!((!a[property] || !a[property].length || a[property] === '' || (a[property] === null)) &&
          (!b[property] || !b[property].length || b[property] === '' || (b[property] === null)))) {
          if (!a[property] || !a[property].length || a[property] === '') {
            a[property] = '';
          }
          if (!b[property] || !b[property].length) {
            b[property] = '';
          }
          const AInt = +a[property];
          const BInt = +b[property];
          if (isNaN(AInt) && isNaN(BInt)) {
            const aA = a[property].replace(reA, '');
            const bA = b[property].replace(reA, '');
            return (aA === bA ? 0 : aA.toLowerCase() > bA.toLowerCase() ? 1 : -1) * direction;
          } else if (isNaN(AInt)) {
            return 1 * direction;
          } else if (isNaN(BInt)) {
            return -1 * direction;
          } else if (!(isNaN(AInt) && isNaN(BInt))) {
            return (AInt > BInt ? 1 : -1) * direction;
          }
        }
      });
    }

    data = this.customSortOnCnfrmBkngTabLoad(data, flag);

    if (flag === 'ERR') {
      this.dshbrdDataChange.err = JSON.parse(JSON.stringify(data));
    } else if (flag === 'OTH') {
      this.dshbrdDataChange.othrs = JSON.parse(JSON.stringify(data));
    }
  }

  customSortOnCnfrmBkngTabLoad(data, flag) {
    /**
     * Order of custom sorting (confirm booking tab)
     * Exception Red Icon >> Exception Blue Icon >> Others with Due Date >> No Dates
     */

    if (data.length) {
      let err = [], info = [];
      switch (flag) {
        case 'ERR':
          err = data.filter(el => {
            return !this.showExceptionInfoIcon(el);
          });
          info = data.filter(el => {
            return this.showExceptionInfoIcon(el);
          });
          data = [];
          data.push(...err);
          data.push(...info);
          break;
        case 'OTH':
          break;
        default:
          break;
      }
    }
    return data;
  }

  countBkng(dshbrdDataAll) {
    /**
     * count number of booking from booking data
     */
    this.dataCount = 0;
    let errLength = 0;
    let othrsLength = 0;
    if (dshbrdDataAll) {
      if (dshbrdDataAll.err) {
        errLength = dshbrdDataAll.err.length;
      }
      if (dshbrdDataAll.othrs) {
        othrsLength = dshbrdDataAll.othrs.length;
      }
    }
    this.dataCount = errLength + othrsLength;
    if (!this._cd['destroyed']) {
      this._cd.detectChanges();
    }
  }

  dshBrdObjCheck() {
    /**
     * check booking data activity change and load booking data based on
     *  changed activity such as update bookng count, pagination, sort and filters
     */
    this.filtersOfFilter[this.tabFlag] = [];
    this.sortFilterCheck = JSON.parse(sessionStorage.getItem('srtFltrChk'));
    const filterRequest = this.sortFilterCheck[this.tabFlag].filter;

    if (this.dshbrdDataRaw) {
      if (this.dshbrdDataRaw.othrs) {
        const dshBrdDt = this.callFilter(this.dshbrdDataRaw.othrs, filterRequest);

        if (dshBrdDt) {
          this.dshbrdDataChange.othrs = dshBrdDt;
          this.filtersOfFilter[this.tabFlag] = dshBrdDt;
        } else {
          this.dshbrdDataChange.othrs = [];
        }
      }
      if (this.dshbrdDataRaw.err) {
        const errdshBrdDt = this.callFilter(this.dshbrdDataRaw.err, filterRequest);
        if (errdshBrdDt) {
          this.dshbrdDataChange.err = errdshBrdDt;
          this.filtersOfFilter[this.tabFlag] = this.filtersOfFilter[this.tabFlag].concat(errdshBrdDt);
        } else {
          this.dshbrdDataChange.err = [];
        }
      }
    }

    this.countBkng(this.dshbrdDataChange);
    this.sortFilterCheck = JSON.parse(sessionStorage.getItem('srtFltrChk'));
    if (this.sortFilterCheck[this.tabFlag].sort) {
      const prop = this.sortFilterCheck[this.tabFlag].sort['property'];
      const coln = this.activeSort = this.sortFilterCheck[this.tabFlag].sort['column'];
      const direction = this.sortFilterCheck[this.tabFlag].sort['dirctn'];
      this.sort(prop, coln, direction);
    } else {
      this.pagination();
    }

  }

  addDateFilter(keyVal, valueVal, colm) {
    /**
     * add date filter data based on column from booking data to local storage when filter is applied
     */
    this.sortFilterCheck = JSON.parse(sessionStorage.getItem('srtFltrChk'));
    let filterRequest = this.sortFilterCheck[this.tabFlag].filter;

    if (filterRequest) {
      if (filterRequest.length > 0) {
        const KeyArr = [];
        for (let i = 0; i < filterRequest.length; i++) {
          KeyArr.push(filterRequest[i].key);
          if (filterRequest[i].key === keyVal) {
            filterRequest[i].value = valueVal;
            filterRequest[i].colm = colm;
            this.sortFilterCheck[this.tabFlag].filter = filterRequest;
            sessionStorage.setItem('srtFltrChk', JSON.stringify(this.sortFilterCheck));
            this.dshBrdObjCheck();
            break;
          }
          if (i === (filterRequest.length - 1)) {
            if (KeyArr.indexOf(keyVal) === -1) {
              filterRequest.push({ 'key': keyVal, 'value': valueVal, 'colm': colm });
              this.sortFilterCheck[this.tabFlag].filter = filterRequest;
              sessionStorage.setItem('srtFltrChk', JSON.stringify(this.sortFilterCheck));
              this.dshBrdObjCheck();
            }
          }
        }
      } else {
        filterRequest = [{ 'key': keyVal, 'value': valueVal, 'colm': colm }];
        this.sortFilterCheck[this.tabFlag].filter = filterRequest;
        sessionStorage.setItem('srtFltrChk', JSON.stringify(this.sortFilterCheck));
        this.dshBrdObjCheck();
      }
    }
  }

  dateFilter(flag) {
    /**
     * display date picker based on filter flag from booking data
     */
    this.remDtPick(flag);
    if (flag === 'dudtN') {
      this.addDateFilter('dDt', this.setDateRange(this.startdateDudtN, this.enddateDudtN), flag);
      this._shrdt.setFiltersOfFilter(this.filtersOfFilter[this.tabFlag].length);
      this.newActiveFilter[this.tabFlag]['dudtN'] = true;
    }
    if (flag === 'bkdtN') {
      this.addDateFilter('bDt', this.setDateRange(this.startdateBkdtN, this.enddateBkdtN), flag);
      this._shrdt.setFiltersOfFilter(this.filtersOfFilter[this.tabFlag].length);
      this.newActiveFilter[this.tabFlag]['bkdtN'] = true;
    }
    if (flag === 'dedtN') {
      this.addDateFilter('delvDt', this.setDateRange(this.startdateDedtN, this.enddateDedtN), flag);
      this._shrdt.setFiltersOfFilter(this.filtersOfFilter[this.tabFlag].length);
      this.newActiveFilter[this.tabFlag]['dedtN'] = true;
    }
    if (flag === 'indtN') {
      this.addDateFilter('cDt', this.setDateRange(this.startdateIndtN, this.enddateIndtN), flag);
      this._shrdt.setFiltersOfFilter(this.filtersOfFilter[this.tabFlag].length);
      this.newActiveFilter[this.tabFlag]['indtN'] = true;
    }
    if (flag === 'redtN') {
      this.addDateFilter('cDt', this.setDateRange(this.startdateRedtN, this.enddateRedtN), flag);
      this._shrdt.setFiltersOfFilter(this.filtersOfFilter[this.tabFlag].length);
      this.newActiveFilter[this.tabFlag]['redtN'] = true;
    }
    if (flag === 'coldtN') {
      this.addDateFilter('cDt', this.setDateRange(this.startdateColdtN, this.enddateColdtN), flag);
      this._shrdt.setFiltersOfFilter(this.filtersOfFilter[this.tabFlag].length);
      this.newActiveFilter[this.tabFlag]['coldtN'] = true;
    }

  }

  setDateRange(strtDt, endDt) {
    /**
     * set date range of datepicker based on flag from booking data
     */
    const dtArr = [];
    const dt = new Date(strtDt);
    const end = new Date(endDt);

    do {
      dtArr.push(((dt.getDate() < ConstantsVAR.DIGIT_10) ? ('0' + dt.getDate()) : dt.getDate()) + '-'
        + (((dt.getMonth() + 1) < ConstantsVAR.DIGIT_10) ? ('0' + (dt.getMonth() + 1)) : (dt.getMonth() + 1))
        + '-' + dt.getFullYear());
      dt.setDate(dt.getDate() + 1);
    } while (dt <= endDt);
    return dtArr;
  }

  datepick(flag) {
    this.dtOpened = flag;
    document.getElementById(flag).classList.add('openDt');
  }

  remDtPick(flag) {
    if (flag) {
      document.getElementById(flag).classList.remove('openDt');
    } else {
      document.getElementById(this.dtOpened).classList.remove('openDt');
    }
    this.dtOpened = '';
  }

  resetDate(flag) {
    /**
     * reset datepicker based on flag from dashboard data
     */
    if (flag === 'dudtN') {
      this.startdateDudtN = new Date();
      this.enddateDudtN = new Date();
      this.newActiveFilter[this.tabFlag]['dudtN'] = false;
    }
    if (flag === 'bkdtN') {
      this.startdateBkdtN = new Date();
      this.enddateBkdtN = new Date();
      this.newActiveFilter[this.tabFlag]['bkdtN'] = false;
    }
    if (flag === 'dedtN') {
      this.startdateDedtN = new Date();
      this.enddateDedtN = new Date();
      this.newActiveFilter[this.tabFlag]['dedtN'] = false;
    }
    if (flag === 'indtN') {
      this.startdateIndtN = new Date();
      this.enddateIndtN = new Date();
      this.newActiveFilter[this.tabFlag]['indtN'] = false;
    }
    if (flag === 'redtN') {
      this.startdateRedtN = new Date();
      this.enddateRedtN = new Date();
      this.newActiveFilter[this.tabFlag]['redtN'] = false;
    }
    if (flag === 'coldtN') {
      this.startdateColdtN = new Date();
      this.enddateColdtN = new Date();
      this.newActiveFilter[this.tabFlag]['coldtN'] = false;
    }
    const srtfltrChck = JSON.parse(sessionStorage.getItem('srtFltrChk'));

    for (let i = 0; i < srtfltrChck[this.tabFlag].filter.length; i++) {
      if (srtfltrChck[this.tabFlag].filter[i].colm === flag) {
        srtfltrChck[this.tabFlag].filter.splice(i, 1);
        sessionStorage.setItem('srtFltrChk', JSON.stringify(srtfltrChck));
        this.sortFilterDataUpdate();
      }
    }
  }

  removeFilter(keyVal, valueVal, colm) {
    /**
     * remove filter data of particular column from local storage
     */
    this.sortFilterCheck = JSON.parse(sessionStorage.getItem('srtFltrChk'));
    let filterRequest = this.sortFilterCheck[this.tabFlag].filter;

    if (filterRequest) {
      if (filterRequest.length > 0) {
        for (let i = 0; i < filterRequest.length; i++) {
          if (filterRequest[i].key === keyVal) {
            if (valueVal === 'ALL') {
              filterRequest.splice(i, 1);
              if (filterRequest.length === 0) {
                filterRequest = [];
                this.sortFilterCheck[this.tabFlag].filter = filterRequest;
                sessionStorage.setItem('srtFltrChk', JSON.stringify(this.sortFilterCheck));
                this.dshbrdDataChange = JSON.parse(JSON.stringify(this.dshbrdDataRaw));
                this.countBkng(this.dshbrdDataChange);
              } else {
                this.sortFilterCheck[this.tabFlag].filter = filterRequest;
                sessionStorage.setItem('srtFltrChk', JSON.stringify(this.sortFilterCheck));
                this.dshBrdObjCheck();
              }
              this.sortFilterCheck[this.tabFlag].filter = filterRequest;
              sessionStorage.setItem('srtFltrChk', JSON.stringify(this.sortFilterCheck));
            } else {
              const indexVal = filterRequest[i].value.indexOf(valueVal);
              if (indexVal > -1) {
                filterRequest[i].value.splice(indexVal, 1);
                this.sortFilterCheck[this.tabFlag].filter = filterRequest;
                sessionStorage.setItem('srtFltrChk', JSON.stringify(this.sortFilterCheck));
                if (filterRequest[i].value.length === 0) {
                  filterRequest.splice(i, 1);
                  this.sortFilterCheck[this.tabFlag].filter = filterRequest;
                  sessionStorage.setItem('srtFltrChk', JSON.stringify(this.sortFilterCheck));
                }
                if (filterRequest.length === 0) {
                  filterRequest = [];
                  this.sortFilterCheck[this.tabFlag].filter = filterRequest;
                  sessionStorage.setItem('srtFltrChk', JSON.stringify(this.sortFilterCheck));
                  this.dshbrdDataChange = JSON.parse(JSON.stringify(this.dshbrdDataRaw));
                  this.countBkng(this.dshbrdDataChange);
                  this.pagination();
                } else {
                  this.dshBrdObjCheck();
                }
                this.sortFilterCheck[this.tabFlag].filter = filterRequest;
                sessionStorage.setItem('srtFltrChk', JSON.stringify(this.sortFilterCheck));
                break;
              }
            }
          } else {
            if (filterRequest.length === 0) {
              filterRequest = [];
              this.sortFilterCheck[this.tabFlag].filter = filterRequest;
              sessionStorage.setItem('srtFltrChk', JSON.stringify(this.sortFilterCheck));
              this.dshbrdDataChange = JSON.parse(JSON.stringify(this.dshbrdDataRaw));
              this.countBkng(this.dshbrdDataChange);
            }
            this.sortFilterCheck[this.tabFlag].filter = filterRequest;
            sessionStorage.setItem('srtFltrChk', JSON.stringify(this.sortFilterCheck));
            this.pagination();
          }
        }
      } else {
        filterRequest = [];
        this.dshbrdDataChange = JSON.parse(JSON.stringify(this.dshbrdDataRaw));
        this.countBkng(this.dshbrdDataChange);
        this.sortFilterCheck[this.tabFlag].filter = filterRequest;
        sessionStorage.setItem('srtFltrChk', JSON.stringify(this.sortFilterCheck));
        this.pagination();
      }
    }
  }

  onClickOutsideFltr(event: Object, colmHdr) {
    if (event && event['value'] === true) {
      try {
        const dateFiltr = ['dudtN', 'bkdtN', 'dedtN', 'redtN', 'coldtN', 'indtN'];
        const othrFiltr = ['accN', 'srvcN', 'colnN', 'delN', 'stsN'];
        const sortFilterCheckDshbrd = JSON.parse(sessionStorage.getItem('srtFltrChk'));

        if (othrFiltr.indexOf(colmHdr) > -1) {
          if (this.filterOpened[colmHdr]) {
            this.activeFilter = ConstantsJson.activeFilter;
            if (colmHdr === 'accN') {
              this.accNCheckbox[this.tabFlag] = [];
              this.accNvalue[this.tabFlag] = [];
            } else if (colmHdr === 'srvcN') {
              this.srvcNCheckbox[this.tabFlag] = [];
              this.srvcNvalue[this.tabFlag] = [];
            } else if (colmHdr === 'colnN') {
              this.colnNCheckboxCity[this.tabFlag] = [];
              this.colnNvalue[this.tabFlag] = [];
              this.colnNCheckboxCntry[this.tabFlag] = [];
            } else if (colmHdr === 'delN') {
              this.delNCheckboxCity[this.tabFlag] = [];
              this.delNvalue[this.tabFlag] = [];
            } else if (colmHdr === 'stsN') {
              this.stsNCheckbox[this.tabFlag] = [];
              this.stsNvalue[this.tabFlag] = [];
            }

            if (sortFilterCheckDshbrd[this.tabFlag].filter) {
              for (let i = 0; i < sortFilterCheckDshbrd[this.tabFlag].filter.length; i++) {
                const chkBxValue = sortFilterCheckDshbrd[this.tabFlag].filter[i].value;
                const chkBxColm = sortFilterCheckDshbrd[this.tabFlag].filter[i].colm;
                this.activeFilter[chkBxColm] = true;
                if (chkBxValue && chkBxColm === colmHdr) {
                  for (let j = 0; j < chkBxValue.length; j++) {
                    if (colmHdr === 'accN') {
                      this.accNCheckbox[this.tabFlag][chkBxValue[j]] = true;
                      this.accNvalue[this.tabFlag].push(chkBxValue[j]);
                    } else if (colmHdr === 'srvcN') {
                      this.srvcNCheckbox[this.tabFlag][chkBxValue[j]] = true;
                      this.srvcNvalue[this.tabFlag].push(chkBxValue[j]);
                    } else if (colmHdr === 'colnN') {
                      this.colnNCheckboxCity[this.tabFlag][chkBxValue[j]] = true;
                      this.colnNvalue[this.tabFlag].push(chkBxValue[j]);
                    } else if (colmHdr === 'delN') {
                      this.delNCheckboxCity[this.tabFlag][chkBxValue[j]] = true;
                      this.delNvalue[this.tabFlag].push(chkBxValue[j]);
                    } else if (colmHdr === 'stsN') {
                      this.stsNCheckbox[this.tabFlag][chkBxValue[j]] = true;
                      this.stsNvalue[this.tabFlag].push(chkBxValue[j]);
                    }
                  }

                  this.filterOpened[colmHdr] = false;
                }
              }
            }
          } else {
            if (sortFilterCheckDshbrd[this.tabFlag].filter) {
              for (let i = 0; i < sortFilterCheckDshbrd[this.tabFlag].filter.length; i++) {
                const chkBxColm = sortFilterCheckDshbrd[this.tabFlag].filter[i].colm;
              }
            }
          }
        } else if (dateFiltr.indexOf(colmHdr) > -1) {
          if (this.filterOpened[colmHdr]) {
            for (let i = 0; i < sortFilterCheckDshbrd[this.tabFlag].filter.length; i++) {
              const chkBxValue = sortFilterCheckDshbrd[this.tabFlag].filter[i].value;
              const chkBxColm = sortFilterCheckDshbrd[this.tabFlag].filter[i].colm;

              if (chkBxValue.length && chkBxColm === colmHdr) {
                const startDate = this.splitDates(chkBxValue.sort()[0]);
                const endDate = this.splitDates(chkBxValue.sort()[chkBxValue.length - 1]);
                this.filterOpened[colmHdr] = false;

                if (colmHdr === 'dudtN') {
                  this.startdateDudtN = startDate;
                  this.enddateDudtN = endDate;
                } else if (colmHdr === 'bkdtN') {
                  this.startdateBkdtN = startDate;
                  this.enddateBkdtN = endDate;
                } else if (colmHdr === 'dedtN') {
                  this.startdateDedtN = startDate;
                  this.enddateDedtN = endDate;
                } else if (colmHdr === 'redtN') {
                  this.startdateRedtN = startDate;
                  this.enddateRedtN = endDate;
                } else if (colmHdr === 'coldtN') {
                  this.startdateColdtN = startDate;
                  this.enddateColdtN = endDate;
                } else if (colmHdr === 'indtN') {
                  this.startdateIndtN = startDate;
                  this.enddateIndtN = endDate;
                }
              }
            }
          }
        }
      } catch (err) { }
    }
  }

  splitDates(val) {
    /*
     * date format required :::: (dd-mm-yyyy)
     * example : 03-12-1991, 21-03-1999
     * return date format by splitting date string.
     */
    if (val) {
      const dt = val.split('-').reverse().join('-');
      return new Date(dt);
    }
  }

  getDeliveryDateFilterValues(tabflag, colm) {
    /*
     * set delivery date in time picker from dashboard data
     */
    const isFilter = this.sortFilterCheck[tabflag].filter.filter((el) => {
      return el.colm === colm;
    });
    if (isFilter.length) {
      isFilter.filter((el) => {
        this.startdateDedtN = this.splitDates(el.value[0]);
        this.enddateDedtN = this.splitDates(el.value[el.value.length - 1]);
      });
    } else {
      this.startdateDedtN = new Date();
      this.enddateDedtN = new Date();
    }
  }

  getDueDateFilterValues(tabflag, colm) {
    /**
     * set due date in time picker from dashboard data
     */
    const isFilter = this.sortFilterCheck[tabflag].filter.filter((el) => {
      return el.colm === colm;
    });
    if (isFilter.length) {
      isFilter.filter((el) => {
        this.startdateDudtN = this.splitDates(el.value[0]);
        this.enddateDudtN = this.splitDates(el.value[el.value.length - 1]);
      });
    } else {
      this.startdateDudtN = new Date();
      this.enddateDudtN = new Date();
    }
  }

  getInitiationDateFilterValues(tabflag, colm) {
    /**
     * set initiation date in timepicker from dashboard data
     */
    const isFilter = this.sortFilterCheck[tabflag].filter.filter((el) => {
      return el.colm === colm;
    });
    if (isFilter.length) {
      isFilter.filter((el) => {
        this.startdateIndtN = this.splitDates(el.value[0]);
        this.enddateIndtN = this.splitDates(el.value[el.value.length - 1]);
      });
    } else {
      this.startdateIndtN = new Date();
      this.enddateIndtN = new Date();
    }
  }

  dateFilterIcon(colm) {
    switch (colm) {
      case 'dudtN':
        this.getDueDateFilterValues(this.tabFlag, colm);
        break;
      case 'bkdtN':
        break;
      case 'dedtN':
        this.getDeliveryDateFilterValues(this.tabFlag, colm);
        break;
      case 'redtN':
        break;
      case 'coldtN':
        break;
      case 'indtN':
        this.getInitiationDateFilterValues(this.tabFlag, colm);
        break;
    }
  }

  resetSortFilter(tbFlg) {
    /**
     * reset all filter data from dashboard based on current tab flag
     */
    this.accNCheckbox[tbFlg] = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
    this.srvcNCheckbox[tbFlg] = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
    this.stsNCheckbox[tbFlg] = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
    this.colnNCheckboxCity[tbFlg] = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
    this.delNCheckboxCity[tbFlg] = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
    this.newActiveFilter[tbFlg] = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
    this.filtersOfFilter[tbFlg] = JSON.parse(JSON.stringify(ConstantsJson.initTabs));
    const srtFltrChk = JSON.parse(sessionStorage.getItem('srtFltrChk'));
    this.prevCol = srtFltrChk[tbFlg].sort['property'];
    this.sortFilterCheck = JSON.parse(JSON.stringify(srtFltrChk));
    const newResetData = JSON.parse(JSON.stringify(srtFltrChk));
    if (tbFlg === 'CB' || tbFlg === 'SEARCH') {
      newResetData['customSort'][tbFlg] = false;
    }
    newResetData[tbFlg] = JSON.parse(JSON.stringify(ConstantsJson.srtFltrChck))[tbFlg];
    sessionStorage.setItem('srtFltrChk', JSON.stringify(newResetData));
    if (tbFlg === 'SEARCH') {
      this.search(this.searchInputModel);
    } else {
      this.resetSF.emit(tbFlg);
    }
  }

  apiUnsubscribe(apiName) {
    if (this.apiSubscription[apiName]) { this.apiSubscription[apiName].unsubscribe(); }
  }

  retryMechanism(error, apiName, params, noBaseAPI?) {
    this.apiCallCount[apiName] = this.apiCallCount[apiName] || 1;
    this.apiCallCount[apiName]++;
    if (this._calltoken) {
      if (!noBaseAPI) { this._calltoken.callBaseService(error); }
      if (this.apiCallCount[apiName] <= ConstantsVAR.API_MAX_TRY) {
        this._calltoken.retryServiceCall(error, apiName, params);
      } else {
        this.apiCallCount[apiName] = 0;
      }
    }
  }

  retryCall(data) {
    /**
     * retry call to fetch booking and templates
     */
    switch (data.apiName) {
      case 'checkBkng': this.checkBkng(); break;
      case 'checkTmplt': this.checkTmplt(); break;
      default: break;
    }
  }

  showExceptionInfoIcon(data) {
    // this code will change in sp4 when expired booking US completed
    // flag value compare will replace string compare -- bkDtChng
    if (data['expDtls']) {
      return data['expDtls'].length === 1 ? data['bkDtChng'] : false;
    } else {
      return false;
    }
  }

}
