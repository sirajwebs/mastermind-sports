/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* Fedex 2018
 *
 * Typescript code in this page
 */
import { LabelsAndEmailsService } from './../../services/labels-and-emails.service';
import { CalltokenComponent } from './../../shared/calltoken/calltoken.component';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { BookingService } from './../../services/booking.service';
import { SharedataService } from './../../services/sharedata.service';
import { Component, OnInit, OnDestroy, ChangeDetectorRef, ViewChild, HostListener } from '@angular/core';
import { TemplateService } from './../../services/template.service';
import { Subscription } from 'rxjs/Subscription';
import { Router } from '@angular/router';
import { DashboardDataComponent } from './dashboard-data/dashboard-data.component';
import 'rxjs/add/observable/forkJoin';
import { ConstantsJson, ConstantsVAR } from '../../shared/constants/constants-var';
import { ConstantsURL } from './../../shared/constants/constants-urls';
import { AccountListDTO } from './../../shared/models/user.models';
import { JsEncoderService } from './../../services/js-encoder.service';

@Component({
  selector: 'app-booking-dashboard',
  templateUrl: './booking-dashboard.component.html',
  styleUrls: ['./booking-dashboard.component.css'],
  providers: [TemplateService, BookingService, LabelsAndEmailsService]
})

export class BookingDashBoardComponent implements OnInit, OnDestroy {
  @ViewChild(CalltokenComponent) public _calltoken: CalltokenComponent;
  @ViewChild(DashboardDataComponent) public _dshData: DashboardDataComponent;

  subscriptions: Array<Subscription> = [];
  templateList = null;
  templateListSuccess = null;
  templateListError = true;
  bookingList = JSON.parse(JSON.stringify(ConstantsJson.dshbrdDataINIT));
  bookingListSuccess = null;
  bookingListError = null;
  bookingBtnClicked = null;
  isLoaderEnabled = false;

  deleteBookingData = '';
  bookingDeleteSuccess = false;
  bookingDeleteError = false;
  bookingDeleteNtPssble = false;
  tabDataFlag = '';
  previousTab = '';
  senderConfirm = false;

  basicAccNo = '';
  tmpNmChkError = null;
  emailData = {}; // check datatype ***
  apiSubscription = [];
  paperworkStatus = '';
  resendEmailSuccess = '';
  dataCount = 0;
  sendEmailMsg = null;
  pausePDF = false;
  bookingListErrorCode = '';
  apiCallCount = [];

  draftId = ConstantsVAR.draftId;
  errorId = ConstantsVAR.errorId;
  awaitingId = ConstantsVAR.awaitingId;
  bookedId = ConstantsVAR.bookedId;
  collectedId = ConstantsVAR.collectedId;
  exceptionId = ConstantsVAR.exceptionId;
  intransitId = ConstantsVAR.intransitId;
  outfordelivery = ConstantsVAR.outfordelivery;
  deliveredId = ConstantsVAR.deliveredId;
  closedId = ConstantsVAR.closedId;
  expiredId = ConstantsVAR.expiredId;

  templateNameConflict: boolean;
  templateBtnClicked: boolean;
  errorSavingTemplate: boolean;
  tempSaveSuccess: boolean;
  templateNm = '';
  saveTempForm = new FormGroup({
    templateName: new FormControl('', Validators.required)
  });

  fixedToaster = false;
  deleteBookingDataRef = '';
  bkngSveScs = null;
  bkngSveDrftScs = null;
  bkngSortFlag = false;
  SearchInputValue = '';
  accountList = [];
  getAccount = {}; // check datatype ***
  tFlg = '';
  logCountry = '';
  sortFilterCheckDshbrd = JSON.parse(JSON.stringify(ConstantsJson.srtFltrChck));
  setDashbrdSortFilter = null;

  @HostListener('window:beforeunload', ['$event'])
  onUnloadHandler(event) {
    sessionStorage.removeItem('srtFltrChk');
  }

  constructor(private _router: Router,
    private _booking: BookingService,
    private _jsEcd: JsEncoderService,
    private _lblsEml: LabelsAndEmailsService,
    private _template: TemplateService,
    private _shrdt: SharedataService,
    private _cd: ChangeDetectorRef) {
  }

  ngOnInit() {

    this.subscriptions.push(this._shrdt.loginDetailsMsg.subscribe((loginDetails) => {
      if (loginDetails['userProfile']) {
        try {
          this.logCountry = loginDetails['userProfile'].registeredContactAndAddress.address.countryCode;
        } catch (err) { }
      }
    }));

    window.scrollTo(0, 0);
    const accKeyVal = this._jsEcd.decode(localStorage.getItem(ConstantsVAR.ACC_KEY));
    if (accKeyVal) {
      this.getAccount = JSON.parse(accKeyVal);
      this.accountList = this.getAccount['cAccNoLi'];
    }

    this.subscriptions.push(this._shrdt.getBkngURL.subscribe((url) => {
      if (url) {
        this._shrdt.getSrtFltrChck.subscribe((data) => {
          if (data) {
            this.setDashbrdSortFilter = true;
            const srtFltrChck = JSON.parse(sessionStorage.getItem('srtFltrChk'));
            this.sortFilterCheckDshbrd = srtFltrChck;
            this.tFlg = srtFltrChck['tabFlag'];
          } else if (data === false) {
            sessionStorage.removeItem('srtFltrChk');
            this._shrdt.setSearchInput('');
            this.clearSearchStorage();
          }
        });
      }
    }));

    this.clearMessage();
    this.getTemplateList();
    this.setTabFlagDefault();

    if (this.tFlg !== 'SEARCH' && this.tFlg) {
      const id = ('tabData'.concat(this.tFlg)).concat('-link');
      document.getElementById(id).click();
    } else if (this.tFlg === 'SEARCH') {
      this.tabDataFlag = 'SEARCH';
      this.getDashBoardData();
    } else {
      this.getSavedSuccessMsg();
    }

    this.subscriptions.push(this._shrdt.getSearch.subscribe((val) => {
      if (val) {
        setTimeout(() => {
          this.SearchInputValue = val;
          const srtFltrChck = JSON.parse(sessionStorage.getItem('srtFltrChk'));
          this.tFlg = srtFltrChck['tabFlag'];
          if (this.tFlg) {
            if (this.tFlg === 'SEARCH') {
              this.emitSearch(true);
            } else {
              this.clearSearchStorage();
            }
          }
        }, ConstantsVAR.MILISEC_100);
      }
    }));

  }

  clearAllSharedData() {
    setTimeout(() => {
      this._shrdt.setSearchInput('');
      this._shrdt.setSrtFltrChck(null);
      this._shrdt.setBkngURL(null);
      this.tFlg = '';
    }, ConstantsVAR.MILISEC_1000);
  }

  setTabFlagDefault() {
    const srtFltrChck = JSON.parse(sessionStorage.getItem('srtFltrChk'));
    if (srtFltrChck ? (srtFltrChck['tabFlag'] ? false : true) : true) {
      this.tabClicked('CB');
    } else {
      if (this.tFlg) {
        this.tabClicked(srtFltrChck['tabFlag']);
      } else {
        this.tabClicked('CB');
      }
    }
  }

  clearSearchStorage() {
    this.SearchInputValue = '';
    // check later
    const clearSrch = JSON.parse(sessionStorage.getItem('srtFltrChk'));
    if (clearSrch) {
      clearSrch['SEARCH'] = ConstantsJson.srtFltrChck['SEARCH'];
      sessionStorage.setItem('srtFltrChk', JSON.stringify(clearSrch));
    }
  }

  cancelSave() {
    /**
     * reset template name and close modal
     */
    this.templateBtnClicked = false;
    this.saveTempForm.reset();
    localStorage.removeItem('bkngBodyBasic');
    localStorage.removeItem('tmplBodyBasic');
  }

  templateConfirm() {
    /**
     * confrim to create template from wizard booking details
     */
    this.templateNameConflict = false;
    this.templateBtnClicked = true;
    this.saveTempForm.get('templateName').markAsTouched();
    this.templateNm = this.saveTempForm.get('templateName').value;
    this.isLoaderEnabled = true;

    const apiName = 'templateConfirm';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._template.checkTemplateName(
      this.basicAccNo, this.templateNm).subscribe((data) => {
        this.isLoaderEnabled = false;
        this.tmpNmChkError = false;
        if (data === 'true') {
          this.templateNameConflict = true;
        } else {
          this.templateNameConflict = false;
          this.saveTemp();
        }
        this.apiCallCount[apiName] = 0;
      }, error => {
        this.tmpNmChkError = true;
        this.isLoaderEnabled = false;
        this.retryMechanism(error, apiName, '');
      }));

  }

  saveTemp() {
    /**
     * save booking details to create new template from wizard booking
     */
    this.isLoaderEnabled = true;
    const tmpBody = {
      'bId': this.bkngSveScs['bId'],
      'tNm': this.templateNm,
      'tTyp': this.bkngSveScs['type']
    };
    document.getElementById('REMOVE_MODAL_BACKDROP').click();
    const apiName = 'saveTemp';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._template.createTemplate(tmpBody).subscribe(
      savedata => {
        this.isLoaderEnabled = false;
        document.getElementById('cancelModal').click();
        this.tempSaveSuccess = true;
        this.errorSavingTemplate = false;
        this.apiCallCount[apiName] = 0;
      }, error => {
        this.tempSaveSuccess = false;
        this.isLoaderEnabled = false;
        this.templateNameConflict = false;
        this.errorSavingTemplate = true;
        this.retryMechanism(error, apiName, '');
      }
    ));

  }

  viewTemp() {
    /**
     * view templates
     */
    this._router.navigate(['/booking/templatelist']);
  }

  sndrCnfrmCall(data) {
    if (data.type !== 'E') {
      if (+localStorage.getItem('emailCounter') < 1) {
        this.triggerEmailCall(data);
        window.localStorage.setItem('emailCounter', '1');
      }
    }
  }

  triggerEmailCall(data) {
    const apiName = 'triggerEmailCall';
    this.apiUnsubscribe(apiName);

    this._lblsEml.triggerEmail(data).subscribe((val) => {
      this.pausePDF = false;
      this.apiCallCount[apiName] = 0;
    }, (error) => {
      this.pausePDF = false;
      this.retryMechanism(error, apiName, data);
    });
  }

  notifyCall(data) {
    if (data.type !== 'E') {
      if (+localStorage.getItem('emailCounter') < 1) {
        this.pausePDF = true;
        const apiName = 'bookingLabels';
        this.apiUnsubscribe(apiName);

        this._lblsEml.bookingNotify(data).subscribe((doc) => {
          this.pausePDF = false;
          this.apiCallCount[apiName] = 0;
        }, (error) => {
          this.pausePDF = false;
          this.retryMechanism(error, apiName, data);
        });

        window.localStorage.setItem('emailCounter', '1');

      }
    }
  }

  getSavedSuccessMsg() {
    /**
        * show success message on successfull creation of booking from sender
        */
    this.subscriptions.push(this._shrdt.bkngSveMsg.subscribe((data) => {
      if (data) {
        this.clearMessage();
        this.bkngSveScs = data;
        this.basicAccNo = data['accNo'];

        if (data['isBasic']) {
          if (data['sCnf'] === 'S') {
            this.sndrCnfrmCall(data);
            this.bkngSortFlag = true;
            this.resetTabFilter('AC');
            setTimeout(() => {
              this.tabClicked('AC');
            }, ConstantsVAR.MILISEC_100);
          } else {
            this.notifyCall(data);
            this.resetTabFilter('CB');
            setTimeout(() => {
              this.tabClicked('CB');
            }, ConstantsVAR.MILISEC_100);
          }
          if (document.getElementById('saveTemplateLink')) {
            document.getElementById('saveTemplateLink').click();
          }
        } else {
          if (data['status']) {
            if (data['sCnf'] === 'S') {
              this.bkngSortFlag = true;
              this.sndrCnfrmCall(data);
              this.senderConfirm = true;
              this.resetTabFilter('AC');
              setTimeout(() => {
                this.tabClicked('AC');
              }, ConstantsVAR.MILISEC_100);
            } else {
              this.notifyCall(data);
              this.senderConfirm = false;
              this.fixedToaster = true;
              this.resetTabFilter('CB');
              setTimeout(() => {
                this.tabClicked('CB');
              }, ConstantsVAR.MILISEC_100);
              setTimeout(() => {
                this.fixedToaster = false;
              }, ConstantsVAR.MILISEC_4000);
            }
          }
        }
      }
    }));

    this.subscriptions.push(this._shrdt.bkngSveDrftMsg.subscribe((data) => {
      if (data) {
        if (data['status'] === true) {
          this.clearMessage();
          if (data['sCnf'] === 'S') {
            this.bkngSortFlag = true;
            this.tabClicked('AC');
          } else {
            this.resetTabFilter('CB');
            setTimeout(() => {
              this.tabClicked('CB');
            }, ConstantsVAR.MILISEC_100);
          }
          this.bkngSveDrftScs = data;
        } else {
          this.bkngSveDrftScs = data;
        }
      }
    }));
  }

  resetTabFilter(data) {
    /**
     * reset particular tab filter based on booking created
     */
    const srt = JSON.parse(sessionStorage.getItem('srtFltrChk'));
    if (srt) {
      if (data === 'CB' || data === 'SEARCH') {
        srt['customSort'][data] = false;
      }
      srt[data] = ConstantsJson.srtFltrChck[data];
      sessionStorage.setItem('srtFltrChk', JSON.stringify(srt));
      this.clearSearchStorage();
    }
  }

  refreshDashData() {
    /**
     * refresh dashboard on new token generation
     */
    setInterval(() => {
      this.getBookingList();
      this.getBookngListForASCTab();
      this.getBookngListForCompltdBookngTab();
    }, ConstantsVAR.MINUTES_60);
  }

  remDtPick() {
    /**
     * toggle date filter dropdown on other filter dropdown
     */
    if (this._dshData.dtOpened) {
      this._dshData.remDtPick('');
    }
  }

  countBkng(dshbrdDataAll) {
    /**
     * count number of booking from booking data
     */
    this.dataCount = 0;
    let errLength = 0;
    let othrsLength = 0;
    if (dshbrdDataAll) {
      if (dshbrdDataAll.err) {
        errLength = dshbrdDataAll.err.length;
      }
      if (dshbrdDataAll.othrs) {
        othrsLength = dshbrdDataAll.othrs.length;
      }
    }
    this.dataCount = errLength + othrsLength;
  }

  getBookingList() {
    /**
     * get complete list of booking from booking data
     */
    this.bookingListSuccess = false;
    this.bookingListError = false;
    this.bookingListErrorCode = '';
    const apiName = 'getBookingList';
    this.apiUnsubscribe(apiName);
    this.apiUnsubscribe('getBookngListForASCTab');
    this.apiUnsubscribe('getBookngListForCompltdBookngTab');

    this.subscriptions.push(this.apiSubscription[apiName] = this._booking.getBookingListDashboard(this.accountList).subscribe(data => {
      this.bookingList = JSON.parse(JSON.stringify(ConstantsJson.dshbrdDataINIT));
      this.dataCount = 0;
      this.countBkng(data);
      this.bookingList = data;
      if (!this._cd['destroyed']) {
        this._cd.detectChanges();
      }
      this.bookingListSuccess = true;
      this.bookingListError = false;
      this.bookingListErrorCode = '';
      this.apiCallCount[apiName] = 0;
    }, error => {
      this.bookingListSuccess = false;
      this.bookingListError = true;
      this.bookingListErrorCode = error;
      this.retryMechanism(error, apiName, '');
    }));
  }

  getTemplateList() {
    /**
     * list all active templates from template data
     */
    const accountListBody: AccountListDTO = {
      'cAccNoLi': this.accountList
    };
    const apiName = 'getTemplateList';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._template.getTemplateListDashboard(accountListBody).subscribe(data => {
      if (typeof data === typeof 'string') {
        this.templateList = null;
        this.templateListSuccess = true;
        this.templateListError = false;
      } else {
        this.templateList = data;
        this.templateListSuccess = true;
        this.templateListError = false;
      }
      this.apiCallCount[apiName] = 0;
    }, error => {
      this.templateListSuccess = false;
      this.templateListError = true;
      this.retryMechanism(error, apiName, '');
    }));
  }

  ngOnDestroy() {
    /**
     * angular inbuilt function to avoid overload of memory stack by destroying current DOM
     * removal of booking associated localstorage items, subscription, messages and data.
     */
    this._cd.detach();
    this.subscriptions.forEach((subscription: Subscription) => { subscription.unsubscribe(); });
    Object.keys(this.apiSubscription).forEach(apiName => { this.apiUnsubscribe(apiName); });

    this.clearMessage();
    this._shrdt.bkngSveDrftScs(null);
    this._shrdt.bkngSveScs(null);
    localStorage.removeItem('bkngBodyBasic');
    localStorage.removeItem('tmplBodyBasic');
    localStorage.removeItem('emailCounter');
    this._shrdt.setSrtFltrChck(null);
    this._dshData.sortFilterCheck = ConstantsJson.srtFltrChck;
  }

  emitRefresh(tabflag) {
    /**
     * refresh booking data on clicking tab based selected flag
     */
    if (tabflag === 'CB') {
      this.getBookingList();
    } else if (tabflag === 'AC') {
      this.getBookngListForASCTab();
    } else if (tabflag === 'DB') {
      this.getBookngListForCompltdBookngTab();
    } else if (tabflag === 'SEARCH') {
      this.getDashBoardData();
    }
  }

  newBookingBtn() {
    /**
     * navigate to create booking page
     * conditional -> show modal if templates are not activated
     */
    const srtFltrChck = JSON.parse(sessionStorage.getItem('srtFltrChk'));
    this.tFlg = srtFltrChck['tabFlag'];

    this.clearMessage();
    this._shrdt.bkngSveDrftScs(null);
    this._shrdt.bkngSveScs(null);
    this._shrdt.setBasicBooking('');
    document.getElementById('REMOVE_MODAL_BACKDROP').click();
    this.bookingBtnClicked = true;
    if (this.templateListSuccess && !this.templateList) {
      document.getElementById('noTemplateLink').click();
    } else if (this.templateListSuccess && this.templateList) {
      const apiName = 'newBookingBtn';
      this.apiUnsubscribe(apiName);

      this.subscriptions.push(this.apiSubscription[apiName] = this._template.checkTemplateAvailblty(this.getAccount).subscribe(val => {
        // if (val === 'true') {  // to implement
        this._router.navigate(['/booking/complete-booking']);
        // }
        this.apiCallCount[apiName] = 0;
      }, error => {
        this.retryMechanism(error, apiName, '');
        if (error === ConstantsVAR.API_STATUS_CODE_409) {
          document.getElementById('noDefTemplateLink').click();
        }
      }));
    } else if (this.templateListError) {
      this.bookingBtnClicked = true;
      this.getTemplateList();
      if (!this._cd['destroyed']) {
        this._cd.detectChanges();
      }
    }
  }

  callNwBkngBtn(e) {
    /**
     * show server error toaster message when user click on create new booking button
     */
    this.bookingBtnClicked = false;
  }

  callTmpltScs(e) {
    /**
     * show success toaster on template creation from wizard booking.
     */
    this.tempSaveSuccess = false;
  }

  clearMessage() {
    /**
     * clear all booking related events and flags
     */
    this.paperworkStatus = '';
    this.bookingBtnClicked = false;
    this.bookingDeleteSuccess = false;
    this.bookingDeleteError = false;
    this.bookingDeleteNtPssble = false;
    this.bkngSveDrftScs = null;
    this.bkngSveScs = null;
    this.sendEmailMsg = false;
  }

  createTemplateLink() {
    /**
     * show modal to user if there are no templates available for booking and navigate to wizard page
     */
    this._router.navigate(['/booking/wizard']);
  }



  deleteBookingCall(data) {
    /**
     * show modal when user want to delete a booking
     */
    if (data) {
      this.deleteBookingData = data.bId;
      this.deleteBookingDataRef = data.bSidNo;
      this.clearMessage();
      document.getElementById('deleteBookingLink').click();
    }
  }

  deleteBookingConfirm() {
    /**
     * delete booking on confirmation
     */
    this.isLoaderEnabled = true;
    this.bookingDeleteSuccess = false;
    this.bookingDeleteError = false;
    this.bookingDeleteNtPssble = false;
    this.clearMessage();

    const apiName = 'deleteBookingConfirm';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._booking.deleteBooking(this.deleteBookingData).subscribe(data => {
      this.isLoaderEnabled = false;
      this.bookingDeleteSuccess = true;
      this.bookingDeleteError = false;
      this.bookingDeleteNtPssble = false;
      this.tabClicked('DEL');
      if (!this._cd['destroyed']) {
        this._cd.detectChanges();
      }
      this.apiCallCount[apiName] = 0;
    }, error => {
      this.isLoaderEnabled = false;
      this.bookingDeleteSuccess = false;
      if (error === ConstantsVAR.API_STATUS_CODE_406) {
        this.bookingDeleteNtPssble = true;
      } else {
        this.bookingDeleteError = true;
      }
      if (!this._cd['destroyed']) {
        this._cd.detectChanges();
      }
      this.retryMechanism(error, apiName, '');
    }));
  }

  columnConfigCall(ev) {
    document.getElementById('columnConfigLink').click();
  }

  columnConfigChanges() {
  }

  tabClickedReset(data) {
    /**
     * reset filter data of particular tab
     */
    this.tabDataFlag = '';
    this.tabClicked(data);
  }

  tabClicked(flag) {
    /**
     * get list of booking on tab click and list all applied sort and data filters
     */
    window.scrollTo(0, 0);
    let srtFltChk = { previousTab: '' };
    if (sessionStorage.getItem('srtFltrChk')) {
      this.setDashbrdSortFilter = true;
      srtFltChk = JSON.parse(sessionStorage.getItem('srtFltrChk'));
    }

    if (!flag) {
      if (srtFltChk.previousTab) {
        flag = srtFltChk.previousTab;
      } else {
        flag = 'CB';
      }
    }

    if (flag === 'DEL') {
      if (this.tabDataFlag === 'SEARCH') {
        this.emitSearch(true);
      }
      flag = this.tabDataFlag;
    }

    if (flag === 'CB') {
      this.tabDataFlag = 'CB';
      this.clearSearchStorage();
      this.getBookingList();
    } else if (flag === 'AC') {
      this.clearSearchStorage();
      this.tabDataFlag = 'AC';
      this.getBookngListForASCTab();
    } else if (flag === 'DB') {
      this.clearSearchStorage();
      this.tabDataFlag = 'DB';
      this.getBookngListForCompltdBookngTab();
    }
  }

  getBookngListForASCTab() {
    /**
     * get list of all awaiting sender booking from booking data
     */
    this.bookingListSuccess = false;
    this.bookingListError = false;

    const apiName = 'getBookngListForASCTab';
    this.apiUnsubscribe(apiName);
    this.apiUnsubscribe('getBookingList');
    this.apiUnsubscribe('getBookngListForCompltdBookngTab');

    this.subscriptions.push(this.apiSubscription[apiName] =
      this._booking.getBookingListDashboardForASC(this.accountList, this.bkngSortFlag).subscribe(data => {
        this.bookingList = JSON.parse(JSON.stringify(ConstantsJson.dshbrdDataINIT));
        this.bookingList['othrs'] = data;
        this.dataCount = 0;
        this.countBkng(this.bookingList);
        if (!this._cd['destroyed']) {
          this._cd.detectChanges();
        }
        this.bookingListSuccess = true;
        this.bookingListError = false;
        this.bkngSortFlag = false;
        this.apiCallCount[apiName] = 0;
      }, error => {
        this.bookingListSuccess = false;
        this.bookingListError = true;
        this.retryMechanism(error, apiName, '');
      }));
  }

  getBookngListForCompltdBookngTab() {
    /**
     * get list of all completed booking from booking data
     */
    this.bookingListSuccess = false;
    this.bookingListError = false;
    const apiName = 'getBookngListForCompltdBookngTab';
    this.apiUnsubscribe(apiName);
    this.apiUnsubscribe('getBookngListForASCTab');
    this.apiUnsubscribe('getBookingList');

    this.subscriptions.push(this.apiSubscription[apiName] = this._booking.getBookingListDashboardForCB(this.accountList).subscribe(data => {
      this.bookingList = JSON.parse(JSON.stringify(ConstantsJson.dshbrdDataINIT));
      this.bookingList['othrs'] = data;
      this.dataCount = 0;
      this.countBkng(this.bookingList);
      if (!this._cd['destroyed']) {
        this._cd.detectChanges();
      }
      this.bookingListSuccess = true;
      this.bookingListError = false;
      this.apiCallCount[apiName] = 0;
    }, error => {
      this.bookingListSuccess = false;
      this.bookingListError = true;
      this.retryMechanism(error, apiName, '');
    }));
  }

  getDashBoardData() {
    /**
     * get list of all booked, draft, in transit and out for delivery booking from booking data
     */
    this.isLoaderEnabled = true;
    this.bookingListSuccess = false;
    this.bookingListError = false;
    const apiName = 'getDashBoardData';
    this.apiUnsubscribe(apiName);
    this.apiUnsubscribe('getBookingList');
    this.apiUnsubscribe('getBookngListForASCTab');
    this.apiUnsubscribe('getBookngListForCompltdBookngTab');

    this.subscriptions.push(this.apiSubscription[apiName] =
      this._booking.bookingSearch(this.SearchInputValue, this.accountList).subscribe((data) => {
        if (typeof data === typeof 'string') {
          this.bookingList = JSON.parse(JSON.stringify(ConstantsJson.dshbrdDataINIT));
        } else {
          this.bookingList = JSON.parse(JSON.stringify(ConstantsJson.dshbrdDataINIT));
          this.bookingList = data;
        }
        this.dataCount = 0;
        this.countBkng(this.bookingList);
        this.bookingListSuccess = true;
        this.bookingListError = false;
        this.isLoaderEnabled = false;
        this.apiCallCount[apiName] = 0;
      }, error => {
        this.bookingListSuccess = false;
        this.bookingListError = true;
        this.isLoaderEnabled = false;
        this.retryMechanism(error, apiName, '');
      }));
  }

  emitSearch(ev: boolean) {
    /**
     * emit search value from search text and get updated dashboard data list from booking data
     */
    if (ev === true) {
      this.getDashBoardData();
      if (this.tabDataFlag !== 'SEARCH') {
        this.previousTab = this.tabDataFlag;
      }
      this.tabDataFlag = 'SEARCH';
    }
  }

  paperwork(data) {
    /**
     * call paperwork API to get the file for Labels and PDFs
     */
    this.clearMessage();
    if (!this.logCountry) {
      this.logCountry = '';
    }
    const pprwrkData = {
      'bId': data['bId'],
      'country': this.logCountry,
      'accNo': data['cAccNo'].toString()
    };
    this.openHtmlPdfDocs(pprwrkData);
  }

  openHtmlPdfDocs(pprwrkData) {
    /**
     * set the session storage with the files and route to the print page
     */
    sessionStorage.setItem(pprwrkData.bId, JSON.stringify(pprwrkData));
    const bidEnc = btoa(pprwrkData.bId);
    window.open((ConstantsURL.CONST_PRINT_URL_BID).concat(bidEnc), '_blank');
  }

  emitEmail(data) {
    /**
     * show modal popup to resend email with shipment documents
     */
    this.sendEmailMsg = false;
    this.emailData = data;
    document.getElementById('resendEmailLink').click();
  }

  resendEmail() {
    /**
     * resend email to the receiver with shipment documents
     */
    this.clearMessage();
    if (!this.logCountry) {
      this.logCountry = '';
    }
    const emailData = {
      'bId': this.emailData['bId'],
      'country': this.logCountry,
      'accNo': this.emailData['cAccNo'].toString(),
      'resend': true
    };
    this.pausePDF = true;
    this.triggerEmailCall(emailData);
    this.sendEmailMsg = true;
    if (!this._cd['destroyed']) {
      this._cd.detectChanges();
    }
  }

  resendSndrEmail(data) {
    /**
     * resend email for awaiting sender bookings
     */
    if (data) {
      const emailData = {
        'bId': data['bId'],
        'country': this.logCountry,
        'accNo': data['cAccNo'].toString(),
        'resendAsc': true
      };
      this.resendEmailSuccess = null;
      this.subscriptions.push(this._lblsEml.triggerEmail(emailData).subscribe((val) => {
        this.resendEmailSuccess = (val.toLowerCase() === 'success') ? 'SCS' : 'ERR';
      }, (err => {
        this.resendEmailSuccess = 'ERR';
      })));
    }

  }

  searchTxtValue(ev: string) {
    /**
     * get search value to search in global booking list
     */
    this.clearSearchStorage();
    this.SearchInputValue = ev;
    if (!this.SearchInputValue || (this.SearchInputValue === '')) {
      this.tabClicked(this.previousTab);
    }
  }

  viewUpldBkngResults() {

  }

  apiUnsubscribe(apiName) {
    if (this.apiSubscription[apiName]) { this.apiSubscription[apiName].unsubscribe(); }
  }

  retryMechanism(error, apiName, params, noBaseAPI?) {
    /**
     * to retry the api calls when there any gateway related or authentication related error comes
     */
    this.apiCallCount[apiName] = this.apiCallCount[apiName] || 1;
    this.apiCallCount[apiName]++;
    if (this._calltoken) {
      if (!noBaseAPI) { this._calltoken.callBaseService(error); }
      if (this.apiCallCount[apiName] <= ConstantsVAR.API_MAX_TRY) {
        this._calltoken.retryServiceCall(error, apiName, params);
      } else {
        this.apiCallCount[apiName] = 0;
      }
    }
  }

  retryCall(data) {
    /**
     * retry service call when idle or service glitches
     */
    switch (data.apiName) {
      case 'getBookingList': this.getBookingList(); break;
      case 'bookingLabels': this.notifyCall(data.data); break;
      case 'triggerEmailCall': this.triggerEmailCall(data.data); break;
      case 'templateConfirm': this.templateConfirm(); break;
      case 'saveTemp': this.saveTemp(); break;
      case 'getTemplateList': this.getTemplateList(); break;
      default: this.retryCall2(data);
    }
  }

  retryCall2(data) {
    /**
     * retry service call when idle or service glitches
     */
    switch (data.apiName) {
      case 'newBookingBtn': this.newBookingBtn(); break;
      case 'deleteBookingConfirm': this.deleteBookingConfirm(); break;
      case 'getBookngListForASCTab': this.getBookngListForASCTab(); break;
      case 'getBookngListForCompltdBookngTab': this.getBookngListForCompltdBookngTab(); break;
      case 'getDashBoardData': this.getDashBoardData(); break;
      default: break;
    }
  }
}
