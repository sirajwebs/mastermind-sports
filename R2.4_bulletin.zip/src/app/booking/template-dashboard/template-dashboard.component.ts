/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { CalltokenComponent } from './../../shared/calltoken/calltoken.component';
import { Router } from '@angular/router';
import { Component, OnInit, ViewChild, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { SharedataService } from './../../services/sharedata.service';
import { Subscription } from 'rxjs/Subscription';
import { TemplateService } from './../../services/template.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ConstantsVAR } from './../../shared/constants/constants-var';
import { TemplateListDTO } from './../../shared/models/template.models';
import { AccountListDTO } from './../../shared/models/user.models';
import { RetryCallDTO } from './../../shared/models/global.models';
import { JsEncoderService } from './../../services/js-encoder.service';

@Component({
  selector: 'app-template-list',
  templateUrl: './template-dashboard.component.html',
  styleUrls: ['./template-dashboard.component.css'],
  providers: [TemplateService]
})

export class TemplateDashboardComponent implements OnInit, OnDestroy {

  subscriptions: Array<Subscription> = [];
  @ViewChild(CalltokenComponent) public _calltoken: CalltokenComponent;

  isLoaderEnabled = false;
  saveSuccessFlag: boolean;
  saveEditSuccessFlag: boolean;
  dupSameNameErrorFlag = false;
  templateName: string;
  templateListSuccess: boolean;
  templateList: TemplateListDTO[];
  accountList = [];
  templateListError: boolean;
  duplicateErrFlg = false;

  duplicateScsFlg = false;
  deleteScsFlg = false;
  templateNm: string;
  templtFetchError = null;
  duplicateTemplateBtnClicked: boolean;
  oldDefaultTid = '';
  templateId: number;
  orgTempltName = '';

  deleteErrFlg = false;
  tmpltCount = 0;
  idx = 0;
  clicked = false;
  apiSubscription = [];
  apiCallCount = [];
  accNo = '';
  dupTempForm = new FormGroup({
    duplicateTemplateName: new FormControl('', Validators.required)
  });

  constructor(private _router: Router,
    private _shrdt: SharedataService,
    private _jsEcd: JsEncoderService,
    private _cd: ChangeDetectorRef,
    private _template: TemplateService) {
    this.subscriptions.push(this._shrdt.edtDltTxt.subscribe((val: boolean) => {
      if (val === true) {
        this.deleteScsFlg = true;
      } else if (val === false) {
        this.deleteScsFlg = false;
      }
    }));

  }

  ngOnInit() {
    window.scrollTo(0, 0);

    const accKeyVal = this._jsEcd.decode(localStorage.getItem(ConstantsVAR.ACC_KEY));
    if (accKeyVal) {
      this.accountList = JSON.parse(accKeyVal)['cAccNoLi'];
    }

    this.subscriptions.push(this._shrdt.getTempDel.subscribe((value) => {
      this.templateNm = value;
    }));

    this.subscriptions.push(this._shrdt.currentMessage.subscribe((value) => {
      if (value) {
        this.saveSuccessFlag = value['saveSuccessFlag'];
        this.saveEditSuccessFlag = value['saveEditSuccessFlag'];
        this.templateName = value['templateName'];
      }
    }));

    this.subscriptions.push(this._shrdt.tempFetchError.subscribe((value) => {
      this.templtFetchError = value;
    }));

    this.templateListFetch();

  }

  templateListFetch() {
    /**
     * Fetch List of templates for logged in user from API and populate to template dashboard
     */
    const accountListBody: AccountListDTO = {
      'cAccNoLi': this.accountList
    };
    this.templateListSuccess = false;
    this.templateListError = false;
    const apiName = 'templateListFetch';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._template.getTemplateListDashboard(accountListBody).subscribe(data => {
      this.templateListSuccess = true;
      this.templateListError = false;
      if (data) {
        this.templateList = data;
        this.tmpltCount = this.templateList.length;
        for (let i = 0; i < data.length; i++) {
          if (data[i].def === true) {
            this.oldDefaultTid = data[i].tId;
          }
        }
      } else {
        this.templateList = [];
      }
      this.apiCallCount[apiName] = 0;
    }, error => {
      this.clearMessages();
      this.templateListSuccess = false;
      this.templateListError = true;
      this.retryMechanism(error, apiName, '');
    }));
  }

  newTemplate() {
    /**
     * redirect to create template screen
     */
    this.clearMessages();
    this._shrdt.setTempalteId('');
    this._router.navigate(['/booking/create-template']);
  }


  actDeactTemplateBtn(selectedTemp, i) {
    /**
     * Activate or Deactivate templates from template list by sending request to API
     * based on template id and status
     */
    const actDeactBody = {
      'tId': selectedTemp.tId,
      'act': selectedTemp.tSts
    };
    const apiName = 'actDeactTemplateBtn';
    this.apiUnsubscribe(apiName);

    this.isLoaderEnabled = true;
    this.subscriptions.push(this.apiSubscription[apiName] = this._template.actDeactTemplate(actDeactBody).subscribe(data => {
      this.isLoaderEnabled = false;
      if (selectedTemp.tSts.toLowerCase() !== 'active') {
        this.templateList[i].tSts = 'Active';
      } else {
        this.templateList[i].tSts = 'Inactive';
      }
      this.apiCallCount[apiName] = 0;
    }, error => {
      this.isLoaderEnabled = false;
      const dta = { 'selectedTemp': selectedTemp, 'i': i };
      this.retryMechanism(error, apiName, dta);
      this.templateListFetch();
    }));
  }


  clearMessages() {
    /**
     * clear all message flags
     */
    this.saveSuccessFlag = false;
    this.templateListSuccess = false;
    this.templateListError = false;
    this.templtFetchError = false;
    this.deleteScsFlg = false;
    this.duplicateScsFlg = false;
    this.duplicateErrFlg = false;
    this.dupSameNameErrorFlag = false;
  }


  deleteTemplate(val: TemplateListDTO) {
    /**
     * delete a template from template dashboard by requesting API based on template id, template name and account number
     */
    this.templateId = val.tId;
    this.templateNm = val.tNm;
    this.accNo = val.accno;
    this.isLoaderEnabled = true;
    document.getElementById('REMOVE_MODAL_BACKDROP').click();
    const apiName = 'deleteTemplate';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._template.getDeleteTemplate(val).subscribe((isSuccess) => {
      this.isLoaderEnabled = false;
      if (isSuccess) {
        document.getElementById('deleteTemplateLink').click();
      }
      this.apiCallCount[apiName] = 0;
    }, error => {
      if (error === ConstantsVAR.API_STATUS_CODE_409) {
        this.isLoaderEnabled = false;
        document.getElementById('deleteTemplateErrLink').click();
      } else {
        this.isLoaderEnabled = false;
        // FAILURE MSG TOASTER
      }
      this.retryMechanism(error, apiName, val);
    }));
  }

  deleteTemplateConfirm() {
    /**
     * Shows confirmation popup, where it waits for user activity to delete or cancel template delete
     */
    this.isLoaderEnabled = true;
    this.deleteScsFlg = null;
    this.deleteErrFlg = null;
    const apiName = 'deleteTemplateConfirm';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] =
      this._template.DeleteTemplateNew(this.templateId, this.accNo).subscribe((isSuccess) => {
      if (isSuccess) {
        this.isLoaderEnabled = false;
        this.clearMessages();
        this.deleteScsFlg = true;
        this.templateListFetch();
      } else {
        this.isLoaderEnabled = false;
      }
      this.apiCallCount[apiName] = 0;
    }, error => {
      this.deleteErrFlg = true;
      this.deleteScsFlg = false;
      this.isLoaderEnabled = false;
        this.retryMechanism(error, apiName, '');
      }));
  }

  duplicateTemplate(val: TemplateListDTO) {
    /**
     * create duplicate template
     */
    this.dupTempForm.reset();
    this.dupSameNameErrorFlag = false;
    this.templateId = val.tId;
    this.orgTempltName = val.tNm;
    this.duplicateScsFlg = null;
  }

  duplicateTemplateConfirm() {
    /**
     * Shows Confirmation popup on duplicate template creation
     */
    this.duplicateTemplateBtnClicked = true;
    this.dupTempForm.get('duplicateTemplateName').markAsTouched();
    this.templateNm = this.dupTempForm.get('duplicateTemplateName').value;
    const duplicateBody = {
      refTId: this.templateId,
      nTNm: this.templateNm
    };
    this.isLoaderEnabled = true;
    document.getElementById('REMOVE_MODAL_BACKDROP').click();
    const apiName = 'duplicateTemplateConfirm';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._template.duplicateTemplate(duplicateBody).subscribe((dupliRes) => {
      this.isLoaderEnabled = false;
      this.clearMessages();
      this.dupSameNameErrorFlag = false;
      this.duplicateScsFlg = true;
      document.getElementById('cancelModal').click();
      this.templateListFetch();
      this.dupTempForm.get('duplicateTemplateName').markAsUntouched();
      this.duplicateTemplateBtnClicked = false;
      this.dupTempForm.reset();
      this.apiCallCount[apiName] = 0;
    }, error => {
      this.isLoaderEnabled = false;
      this.dupTempForm.get('duplicateTemplateName').markAsUntouched();
      this.retryMechanism(error, apiName, '');
      if (error === ConstantsVAR.API_STATUS_CODE_409) {
        this.dupSameNameErrorFlag = true;
        this.duplicateTemplateBtnClicked = false;
        this.templateNm = this.dupTempForm.get('duplicateTemplateName').value;
      } else {
        this.dupTempForm.reset();
        this.clearMessages();
        this.templateListFetch();
        this.duplicateErrFlg = true;
        this.duplicateTemplateBtnClicked = false;
        this.dupTempForm.get('duplicateTemplateName').reset();
      }
    }));
  }

  showActionMenuBtn(i) {
    /**
     * show action menu for selected template
     */
    if (this.clicked && this.idx === i) {
      this.clicked = false;
    }
    this.idx = i;
  }

  closeActionMenu() {
    /**
     * close action menu on clicking on outside part of action menu
     */
    this.clicked = false;
  }

  editViewTemplate(tempData: TemplateListDTO) {
    /**
     * Redirect user to create template screen and populate existing values in template screen, latter user can edit
     */
    this._router.navigate(['/booking/create-template']);
    this._shrdt.setTempalteId(tempData.tId);
  }

  cancelDupl() {
    /**
     * cancel activity on Duplicate template popup
     */
    this.dupTempForm.reset();
    this.duplicateErrFlg = false;
    this.dupSameNameErrorFlag = false;
  }

  ngOnDestroy() {
    /**
     * Clear all messages on destroy
     */
    this._cd.detach();
    this.clearMessages();
    this._shrdt.editDeleteMsg('');
    this._shrdt.changeMessage(null);
    this._shrdt.templateFetchError(null);

    this._cd.detach();
    this.subscriptions.forEach((sbscrptn: Subscription) => {
      sbscrptn.unsubscribe();
    });
  }

  apiUnsubscribe(apiName) {
    if (this.apiSubscription[apiName]) { this.apiSubscription[apiName].unsubscribe(); }
  }

  retryMechanism(error, apiName, params, noBaseAPI?) {
    this.apiCallCount[apiName] = this.apiCallCount[apiName] || 1;
    this.apiCallCount[apiName]++;
    if (this._calltoken) {
      if (!noBaseAPI) { this._calltoken.callBaseService(error); }
      if (this.apiCallCount[apiName] <= ConstantsVAR.API_MAX_TRY) {
        this._calltoken.retryServiceCall(error, apiName, params);
      } else {
        this.apiCallCount[apiName] = 0;
      }
    }
  }

  retryCall(data: RetryCallDTO) {
    /**
     * Retry API Call on Failure
     */
    switch (data.apiName) {
      case 'templateListFetch': this.templateListFetch(); break;
      case 'actDeactTemplateBtn': this.actDeactTemplateBtn(data.data.selectedTemp, data.data.i); break;
      case 'deleteTemplate': this.deleteTemplate(data.data); break;
      case 'deleteTemplateConfirm': this.deleteTemplateConfirm(); break;
      case 'duplicateTemplateConfirm': this.duplicateTemplateConfirm(); break;
      default: break;
    }
  }

}
