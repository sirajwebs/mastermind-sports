/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* Fedex 2018
 *
 * Typescript code in this page
 */

/**
 * testing required imports
 */
import { TestBed, async, ComponentFixture, fakeAsync, tick } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { Location } from '@angular/common';
import { RouterTestingModule } from '@angular/router/testing';
/**
 * components required imports
 */
import { CalltokenComponent } from './../../shared/calltoken/calltoken.component';
import { TemplateDashboardComponent } from './template-dashboard.component';
import { Router, Routes } from '@angular/router';
import { Component, OnInit, ViewChild, HostListener, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { SharedataService } from './../../services/sharedata.service';
import { Subscription } from 'rxjs/Subscription';
import { TemplateService } from './../../services/template.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpModule, Http, RequestOptions } from '@angular/http';
import { HttpClient, HttpHeaders, HttpParams, HttpResponse, HttpRequest } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TextMaskPipe } from './../../shared/pipes/text-mask.pipe';
import { ToasterComponent } from './../../shared/components/toaster/toaster.component';
import { RouterModule } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { ConstantsVAR } from './../../shared/constants/constants-var';
import { AccountListDTO } from './../../shared/models/user.models';
import { RetryCallDTO } from './../../shared/models/global.models';
import * as template from './../../shared/models/template.models';
describe('TemplateDashboardComponent', () => {
  let fixture: ComponentFixture<TemplateDashboardComponent>;
  let component: TemplateDashboardComponent;
  let debugElement: DebugElement;
  let htmlElement: HTMLElement;
  let location: Location;
  let router: Router;
  let service: TemplateService;
  let http: Http;
  let HttpClient: HttpClient;
  const mockAccount = {
    cAccNoLi: ['070071313']
  }
  const mockTempList: template.TemplateListDTO[] = [{
    tId: 124,
    tNm: 'Check',
    tSts: 'Active',
    def: false,
    dt: '04-03-2019',
    accno: '070071313'
  }]
  const fetchTemplateListService = {
    getTemplateListDashboard: () => {
      return Observable.of(mockTempList);
    }
  }

  const sharedService = {
    edtDltTxt: () => {
      return true;
    }
  }
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        TemplateDashboardComponent,
        TextMaskPipe,
        ToasterComponent,
        CalltokenComponent
      ],
      imports: [
        HttpModule,
        HttpClientModule,
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule
      ],
      providers: [{ provide: TemplateService, useValue: fetchTemplateListService }, SharedataService]
    }).compileComponents();
    fixture = TestBed.createComponent(TemplateDashboardComponent);
    service = new TemplateService(http);
    debugElement = fixture.debugElement;
    fixture.autoDetectChanges();
  }));


  beforeEach(() => {
    fixture = TestBed.createComponent(TemplateDashboardComponent);
    service = new TemplateService(http);
    component = fixture.componentInstance;
    debugElement = fixture.debugElement;
    fixture.detectChanges();
  });

  // it('should create the app', async(() => {
  //   expect(fixture.debugElement.componentInstance).toBeTruthy();
  // }));

  it('template dashboard component created', () => {
    expect(component).toBeTruthy();
  })
  // it('should render title', () => {
  //   expect(fixture.debugElement.query(By.css('span.dashboard-text')).nativeElement.innerText).toEqual('Manage Templates');
  // });

  // it('should render create new template button', () => {
  //   expect(document.getElementById('new-booking-btn').innerHTML).toEqual('Create New Template');
  // });

  // it('should have table with columns: Template Name, Account, Modified Date, Status', () => {
  //   expect(document.getElementById('tmpNText').innerHTML).toEqual('Template Name');
  //   expect(document.getElementById('accNText').innerHTML).toEqual('Account');
  //   expect(document.getElementById('modDtText').innerHTML).toEqual('Modified Date');
  //   expect(document.getElementById('stsText').innerHTML).toEqual('Status');
  // });

  // it('should not render when template count is 0', () => {
  //   component.tmpltCount = 0;
  //   fixture.detectChanges();
  //   expect(document.getElementById('crrntBkngCount')).toBeNull();
  // });

  // it('should render when template count is greater than 0', () => {
  //   component.tmpltCount = 1;
  //   fixture.detectChanges();
  //   expect(document.getElementById('crrntBkngCount')).not.toBeNull();
  // });

  it('should be able to click create new template button', () => {
    spyOn(component, 'newTemplate');
    const button = document.getElementById('new-booking-btn');
    button.click();
    expect(component.newTemplate).toHaveBeenCalled();
  });

  it('should have template list', () => {
    // spyOn(component, 'templateListFetch');
    // fixture.detectChanges();
    component.templateListFetch();
    fixture.detectChanges();
    expect(component.templateList).toEqual(mockTempList);
  });
  // it('navigate user on create new template click', fakeAsync((rtr: Router, lc: Location) => {
  //   fixture.componentInstance.newTemplate();
  //   rtr.navigate(['/booking/create-template']);
  //   tick();
  //   expect(lc.path()).toBe('/booking/create-template');
  // }));

  it('should clear all messages', () => {
    component.clearMessages();
    fixture.detectChanges();
    expect(component.saveSuccessFlag).toBeFalsy();
    expect(component.templateListSuccess).toBeFalsy();
    expect(component.templateListError).toBeFalsy();
    expect(component.templtFetchError).toBeFalsy();
    expect(component.deleteScsFlg).toBeFalsy();
    expect(component.duplicateScsFlg).toBeFalsy();
    expect(component.duplicateErrFlg).toBeFalsy();
    expect(component.dupSameNameErrorFlag).toBeFalsy();
  });

   it('on canceling duplicate template popup, duplicate temp form should get reset', () => {
    component.cancelDupl();
    expect(component.duplicateErrFlg).toBeFalsy();
    expect(component.dupSameNameErrorFlag).toBeFalsy();
  });
});
