/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    window.scrollTo(0, 0);    
    /**
     * this component is only used to route and 
     * include booking module as a place holder
     * booking module contains Booking, template, wizard,
     *  multiple booking (EDI) 
     */
  }

}
