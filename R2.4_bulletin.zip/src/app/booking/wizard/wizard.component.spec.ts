/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved (c) Fedex 2018
 * Typescript code in this page
 */
import { WizardComponent } from './wizard.component';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DebugElement } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';

import { ConstantsVAR } from './../../shared/constants/constants-var';
import { SharedataService } from './../../services/sharedata.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { RouterModule, Router, Routes } from '@angular/router';
import { TextMaskPipe } from './../../shared/pipes/text-mask.pipe';

describe('WizardComponent', () => {
  let component: WizardComponent;
  let fixture: ComponentFixture<WizardComponent>;
  let debugElement: DebugElement;
  let router: Router;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ 
      WizardComponent,
      TextMaskPipe ],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule
      ],
      providers: [SharedataService]
    })
    .compileComponents();
      fixture = TestBed.createComponent(WizardComponent);
      component = fixture.componentInstance;
      debugElement = fixture.debugElement;
      fixture.autoDetectChanges();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WizardComponent);
    component = fixture.componentInstance;
    debugElement = fixture.debugElement;
    fixture.detectChanges();
  });

  it('Wizard component should get created', () => {
    expect(component).toBeTruthy();
  });

  it('should render title', () => {
    expect((document.getElementById('inboundWelcomeTitle').innerHTML).trim()).toEqual('Welcome to our Industry Portal');
  });

  it('should render title details', () => {
    expect((document.getElementById('inboundWelcomeMsg2').innerHTML).trim()).toEqual('Please select one of the options below to create a\n          <br _ngcontent-c2="">Inbound Shipment, a Return Shipment\n          <br _ngcontent-c2=""\>or a Template.');
  });

  it('should be able to click create new template button', () => {
    spyOn(component, 'templateClick');
    const button = document.getElementById('emptyBtn');
    button.click();
    expect(component.templateClick).toHaveBeenCalled();
  });

  it('should be able to click create Inbound Booking button', () => {
    spyOn(component, 'returnOrInboundBooking');
    const button = document.getElementById('inboundBtn');
    button.click();
    expect(component.returnOrInboundBooking).toHaveBeenCalled();
  });

  it('should be able to click create Return Booking button', () => {
    spyOn(component, 'returnOrInboundBooking');
    const button = document.getElementById('returnBtn');
    button.click();
    expect(component.returnOrInboundBooking).toHaveBeenCalled();
  });
 

});
