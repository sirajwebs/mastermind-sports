/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { CalltokenComponent } from './../../shared/calltoken/calltoken.component';
import { SharedataService } from './../../services/sharedata.service';
import { LoginService } from './../../services/login.service';
import { Component, OnInit, Input, OnChanges, ChangeDetectorRef, OnDestroy, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ConstantsVAR } from './../../shared/constants/constants-var';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit, OnChanges, OnDestroy {

  loggedinUser = '';
  isLoggedIn = false;
  userName: string;
  @Input() noAccount;
  @Input() hideHeaderFooter;
  @ViewChild(CalltokenComponent) public _calltoken: CalltokenComponent;
  apiCallCount = [];
  apiSubscription = [];
  subscriptions: Array<Subscription> = [];

  constructor(private _router: Router,
    private _loginService: LoginService,
    private _sharedataService: SharedataService,
    private _cd: ChangeDetectorRef) {
    /**
     * to check if the user loggedIn to show the header
     */
    this.subscriptions.push(this._sharedataService.isLoggedInSubMsg.subscribe((data) => {
      if (data === true) {
        this.isLoggedIn = true;
      } else {
        this.isLoggedIn = false;
      }
    }));
  }

  ngOnInit() {
    /**
    * to check if the user loggedIn to show the header and  user details
    */
    window.scrollTo(0, 0);
    this.subscriptions.push(this._sharedataService.loginDetailsMsg.subscribe((loginDetails) => {
      if (loginDetails) {
        if (loginDetails['userProfile']) {
          const uDtls = loginDetails['userProfile'].registeredContactAndAddress.contact.personName;
          this.userName = uDtls.firstName + ' ' + uDtls.lastName;
          this._cd.detectChanges();
          this.isLoggedIn = true;
        } else {
          if (localStorage.getItem('isLoggedIn') === 'true') {
            this.isLoggedIn = false;
            this.logout('');
          }
        }
      }
    }));
  }

  ngOnChanges() {
    /**
     * check if the loggined user has account to use application
     */
    this.subscriptions.push(this._sharedataService.noAccountMsg.subscribe(data => {
      if (data === true) {
        this.noAccount = true;
        localStorage.setItem('noAccount', 'true');
        this._cd.detectChanges();
      } else if (localStorage.getItem('noAccount') === 'true') {
        this.noAccount = true;
        this._cd.detectChanges();
      }
    }));
  }

  navbarClickCkhBookingUrl() {
    this._sharedataService.setSearchInput('');
  }

  windowReload() {
    /**
     * Navigate to login component and change window reference url to login
     * and reload the window
     */
    this._router.navigate(['/login']);
    window.location.href = this.getBaseURL() + '/login';
    window.location.reload();
  }

  logout(flag) {
    /**
     * logout and delete localstorage and navigate back to login
     */
    const apiName = 'logout';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._loginService.logout().subscribe((data) => {
      this.isLoggedIn = false;
      this._sharedataService.setNoAccount(false);
      this.logoutHandling(flag);
      this.apiCallCount[apiName] = 0;
    }, error => {
      this.retryMechanism(error, apiName, flag);
      if (this._calltoken) {
        if (this.apiCallCount[apiName] > ConstantsVAR.API_MAX_TRY) {
          /**
           * if 3 times logout try is failed , logout explicitly
           */
          this.logoutHandling(flag);
        }
      }
    }));
  }

  logoutHandling(flag) {
    this.isLoggedIn = false;

    this._loginService.deleteAllCookies();
    localStorage.clear();
    sessionStorage.clear();
    sessionStorage.setItem('logoutFlag', flag);
    this.windowReload();
  }

  getBaseURL() {
    let url = window.location.href;
    try { url = url.slice(0, url.indexOf('#') + 1); } catch (error) { }
    return url;
  }

  ngOnDestroy() {
    this._cd.detach();
    this.subscriptions.forEach((subscription: Subscription) => { subscription.unsubscribe(); });
    Object.keys(this.apiSubscription).forEach(apiName => { this.apiUnsubscribe(apiName); });
  }

  apiUnsubscribe(apiName) {
    if (this.apiSubscription[apiName]) { this.apiSubscription[apiName].unsubscribe(); }
  }

  retryMechanism(error, apiName, params, noBaseAPI?) {
    this.apiCallCount[apiName] = this.apiCallCount[apiName] || 1;
    this.apiCallCount[apiName]++;
    if (this._calltoken) {
      if (!noBaseAPI) { this._calltoken.callBaseService(error); }
      if (this.apiCallCount[apiName] <= ConstantsVAR.API_MAX_TRY) {
        this._calltoken.retryServiceCall(error, apiName, params);
      } else {
        this.apiCallCount[apiName] = 0;
      }
    }
  }

  retryCall(data) {
    if (data.apiName === 'logout') {
      this.logout(data.data);
    }
  }
}
