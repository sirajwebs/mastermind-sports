/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { CalltokenComponent } from './../../shared/calltoken/calltoken.component';
import { TokenService } from './../../services/token.service';
import { BookingService } from './../../services/booking.service';
import { SharedataService } from './../../services/sharedata.service';
import { LoginService } from './../../services/login.service';
import { Router } from '@angular/router';
import { Component, OnInit, ChangeDetectorRef, ViewChild, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ConstantsVAR, FedexLoginConstants, AddressBookConst } from './../../shared/constants/constants-var';
import { ConstantsURL } from './../../shared/constants/constants-urls';
import { Subscription } from 'rxjs/Subscription';
import { AccountListDTO } from './../../shared/models/user.models';
import { JsEncoderService } from './../../services/js-encoder.service';
import { LoginResponseV2, AssociatedAccRequest } from './../../shared/models/login.models';
import { FedexLogonService } from './../../services/fedex-logon.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [LoginService, FedexLogonService]
})
export class LoginComponent implements OnInit, OnDestroy {
  @ViewChild(CalltokenComponent) public _calltoken: CalltokenComponent;

  loginTimeout: boolean;
  loginWrong: boolean;
  loginServerError: boolean;
  isLoaderEnabled: boolean;
  noAccount = false;
  login500Error = '';
  apiCallCount = [];
  apiSubscription = [];
  loginDetails: any; // *** CHECK DATATYPE

  loginForm = new FormGroup({
    userId: new FormControl('', Validators.required),
    pass: new FormControl('', [Validators.required]),
    rembr: new FormControl(''),
  });
  isLoggedIn = false;
  accountList = [];
  defaultAcc = '';
  subscriptions: Array<Subscription> = [];

  constructor(private _router: Router,
    private _loginService: LoginService,
    private _jsEcd: JsEncoderService,
    private _fdxLogin: FedexLogonService,
    private _tokenSrvce: TokenService,
    private _sharedataService: SharedataService,
    private _cd: ChangeDetectorRef,
    private _bookingService: BookingService) {

    /**
     * when user timeout happened, check if idle session over, then show the error message.
     */
    if (sessionStorage.getItem('logoutFlag')) {
      if (sessionStorage.getItem('logoutFlag') === 'TIMEOUT') {
        this.loginTimeout = true;
      } else if (sessionStorage.getItem('logoutFlag') === 'ACTC' ||
        sessionStorage.getItem('logoutFlag') === 'FCL') {
        this.loginServerError = true;
      }
    }
  }

  ngOnInit() {
    document.getElementById('REMOVE_MODAL_BACKDROP').click();
    window.scrollTo(0, 0);
    this.loginForm.patchValue({ 'userId': '', 'pass': '' });
    this.getLastActiveUser();
    /**
     * when user refresh page , need to check this validation to detect if user
     *  is already logged in or not
     */
   
    this.subscriptions.push(this._sharedataService.loginDetailsMsg.subscribe((loginDetails) => {
      if (loginDetails) {
        if (loginDetails['userProfile']) {
          this._cd.detectChanges();
          this.isLoggedIn = true;
        } else {
          if (localStorage.getItem('isLoggedIn') === 'true') {
            this.isLoggedIn = false;
          }
        }
      }
    }));

    /**
    * check if the loggined user has account to show message
    */
    this.subscriptions.push(this._sharedataService.noAccountMsg.subscribe(data => {
      if (data === true) {
        this.noAccount = true;
        localStorage.setItem('noAccount', 'true');
        this._cd.detectChanges();
      } else if (localStorage.getItem('noAccount') === 'true') {
        this.noAccount = true;
        this._cd.detectChanges();
      }
    }));
    this.loginForm.get('pass').setValue('');
    this.loginForm.get('pass').markAsUntouched();
  }

  login() {
    /**
     * call fedex token then call on login functions on success
     */
    this.loginForm.get('userId').markAsTouched();
    this.loginForm.get('pass').markAsTouched();

    if (this.loginForm.value.userId && this.loginForm.value.pass) {
      this._loginService.deleteAllCookies();
      localStorage.setItem('isLoggedIn', '');
      const loginBody = {
        user: this.loginForm.get('userId').value,
        pass: this.loginForm.get('pass').value
      };

      const apiName = 'login';
      this.apiUnsubscribe(apiName);
      const tknPrprty = this._tokenSrvce.assignTokenCallProperty(ConstantsVAR.FEDEX_TOKEN_API);
      this.isLoaderEnabled = true;

      this.subscriptions.push(this.apiSubscription[apiName] =
        this._tokenSrvce.getToken(tknPrprty.clientID, tknPrprty.clientSecret, tknPrprty.tokenURL).subscribe((data) => {
          this._tokenSrvce.setToken(tknPrprty, data.access_token);
          this.isLoaderEnabled = false;
          this.loginCall(loginBody);
          this.apiCallCount[apiName] = 0;
        }, error => {
          this.loginServerError = true;
          this.loginTimeout = false;
          this.loginWrong = false;
          this.isLoaderEnabled = false;
          this.retryMechanism(error, apiName, '', true);
        }));

      this.assignTokenCall(ConstantsVAR.ACCESS_TOKEN_API);
    }
  }

  assignTokenCall(tokenType) {
    /**
     * assign the token to its respective calls
     */

    const tokenProperty = this._tokenSrvce.assignTokenCallProperty(tokenType);
    this.getTokenNew(tokenType, tokenProperty);
  }

  getTokenNew(apiName, tknPrprty) {
    /**
    * to get token for service call (TNT,FEDEX,OAUTH, etc..,
    */
    this.apiUnsubscribe(apiName);
    this.subscriptions.push(this.apiSubscription[apiName] =
      this._tokenSrvce.getToken(tknPrprty.clientID, tknPrprty.clientSecret, tknPrprty.tokenURL).subscribe((data) => {
        if (data.hasOwnProperty('access_token')) {
          this._tokenSrvce.setToken(tknPrprty, data.access_token);
        }
        this.apiCallCount[apiName] = 0;
      }, error => {
        this.retryMechanism(error, apiName, '', true);
      }));
  }

  loginCall(loginBody) {
    /**
     * validate the login data with fedex API
     */
    this.loginTimeout = false;
    this.isLoaderEnabled = true;
    const apiName = 'loginCall';
    this.apiUnsubscribe(apiName);
    this.subscriptions.push(this.apiSubscription[apiName] = this._loginService.postLogin(loginBody).subscribe((data) => {
      if (this.loginForm.value.rembr === true) {
        document.cookie = ConstantsVAR.LAST_ACTIVE_ACCOUNT + '=' + this.loginForm.value.userId;
      } else {
        document.cookie = ConstantsVAR.LAST_ACTIVE_ACCOUNT + '=';
      }

      this.loginServerError = false;
      this.isLoaderEnabled = false;
      if (data.output) {
        this._sharedataService.setLoginDetails(data.output);
        this.setSuccessfulLogin();
        this._sharedataService.setIsLoggedInSub(true);
        this.callAccounts(data);
      } else {
        this.loginFailure();
      }
      this.apiCallCount[apiName] = 0;
    }, (error) => {
      this.isLoaderEnabled = false;
      this.loginServerError = true;
      this.loginTimeout = false;
      this.loginWrong = false;
      try {
        this.login500Error = error._body.charAt(0) !== '<' ? JSON.parse(error._body).userMessage : '';
        this.login500Error = 'Sorry! ' + this.login500Error.replace('your local ', '');
      } catch (err) { }
      this.retryMechanism(error, apiName, loginBody);
    }));
  }

  setSuccessfulLogin() {
    this.isLoggedIn = true;
    this.loginWrong = false;
    localStorage.setItem('isLoggedIn', 'true');
    sessionStorage.removeItem('logoutFlag');
    this.getFedexAccount();
  }

  loginFailure() {
    this.isLoggedIn = false;
    this._router.navigate(['/login']);
    this._sharedataService.setLoginDetails(null);
    this._sharedataService.setIsLoggedInSub(false);
    this.loginServerError = true;
  }

  callAccounts(val: LoginResponseV2) {
    /**
     * call the all account list and default account henceforth
     */
    this.accountList = [];
    if (val.output ? val.output.userProfile : null) {
      if (val.output.userProfile.isManaged || val.output.userProfile.isManaged === false) { // if login if no account
        const accntList = val.output.userProfile.expandedAccounts;
        for (let i = 0; i < accntList.length; i++) {
          const accntRqstBdy: AssociatedAccRequest = {
            accountNumber: accntList[i].account.accountNumber
          };
          this.getAccounts(accntRqstBdy, val.output, accntList.length, i);
        }
      } else {
        this.logout('FCL');
      }
    } else {
      this.logout('FCL');
    }
  }

  windowReload() {
    /**
     * Navigate to login component and change window reference url to login
     * and reload the window
     */
    this._router.navigate(['/login']);
    window.location.href = this.getBaseURL() + ConstantsURL.CONST_LOGIN_URL;
    window.location.reload();
  }

  logout(flag) {
    /**
     * logout and delete localstorage and cookies
     */
    const apiName = 'logout';
    this.apiUnsubscribe(apiName);
    this.isLoaderEnabled = true;

    this.subscriptions.push(this.apiSubscription[apiName] = this._loginService.logout().subscribe((data) => {
      this.logoutHandling(flag);
      this.apiCallCount[apiName] = 0;
    }, error => {
      this.retryMechanism(error, apiName, flag);
      this.logoutHandling(flag);
    }));
  }

  logoutHandling(flag) {
    this.isLoggedIn = false;
    const rUrl = sessionStorage.getItem('returnEdiURL');
    this.isLoaderEnabled = false;
    this._loginService.deleteAllCookies();
    localStorage.clear();
    sessionStorage.clear();
    if (rUrl) { sessionStorage.setItem('returnEdiURL', rUrl) };
    sessionStorage.setItem('logoutFlag', flag);
    this.windowReload();
  }

  ngOnDestroy() {
    try { sessionStorage.removeItem('returnEdiURL'); } catch (err) { }
    this._cd.detach();
    this.subscriptions.forEach((subscription: Subscription) => { subscription.unsubscribe(); });
    Object.keys(this.apiSubscription).forEach(apiName => { this.apiUnsubscribe(apiName); });
  }

  getBaseURL() {
    let url = window.location.href;
    try { url = url.slice(0, url.indexOf('#') + 1); } catch (error) { }
    return url;
  }

  getDefaultAccount(val) {
    /**
     * get the default account to set from list of account
     */
    if (val ? val.userProfile : false) {
      const accntRqstBdy = {
        'accountNumber': val.userProfile.defaultAccount
      };

      const apiName = 'getDefaultAccount';
      this.apiUnsubscribe(apiName);
      this.isLoaderEnabled = true;

      this.subscriptions.push(this.apiSubscription[apiName] = this._loginService.actc(accntRqstBdy).subscribe((data) => {
        this.isLoaderEnabled = false;
        const assocAccounts = data.output.associatedAccounts;
        if (assocAccounts) {
          for (let i = 0; i < assocAccounts.length; i++) {
            if (assocAccounts[i]) {
              if (ConstantsVAR.COMPANY_IDENTIFIER.includes(assocAccounts[i].companyIdentifier)) {
                this.defaultAcc = assocAccounts[i].accountNumber.substr(ConstantsVAR.ACCOUNT_TRIM_POS);
                localStorage.setItem(ConstantsVAR.DEF_ACC_KEY, this._jsEcd.encode(this.defaultAcc));
              }
            }
          }
        }
        this.apiCallCount[apiName] = 0;
        const accVal = this.setAccount();
        this.isBookingsExist(accVal);
      }, error => {
        this.isLoaderEnabled = false;
        const accVal = this.setAccount();
        this.isBookingsExist(accVal);
        this.retryMechanism(error, apiName, val);
      }));
    } else {
      const accVal = this.setAccount();
      this.isBookingsExist(accVal);
    }
  }

  getAccounts(val, defVal, accntListLength: number, i: number) {
    /**
     * get list of account from TNT account linked
     */
    const apiName = 'getAccounts' + i;
    this.apiUnsubscribe(apiName);
    this.isLoaderEnabled = true;

    this.subscriptions.push(this.apiSubscription[apiName] = this._loginService.actc(val).subscribe((data) => {
      const assocAccounts = data.output.associatedAccounts;
      if (assocAccounts) {
        for (const value of assocAccounts) {
          const acc = value.accountNumber.substr(ConstantsVAR.ACCOUNT_TRIM_POS);
          // check for unique account no. values
          if (ConstantsVAR.COMPANY_IDENTIFIER.includes(value.companyIdentifier)
            && this.accountList.indexOf(acc) === -1) {
            this.accountList.push(acc);
          }
        }
        this.noAccount = false;
        this._sharedataService.setNoAccount(false);
        localStorage.setItem('noAccount', '');
      } else {
        this.noAccount = true;
        this._sharedataService.setNoAccount(true);
        localStorage.setItem('noAccount', 'true');
      }
      if (i === accntListLength - 1) { this.getDefaultAccount(defVal); }
      this.apiCallCount[apiName] = 0;
    }, error => {
      const dta = { 'val': val, 'defVal': defVal, 'accntListLength': accntListLength, 'i': i };
      this.retryMechanism(error, apiName, dta);
      this.logout('ACTC');
      this.isLoaderEnabled = false;
    }));
  }

  setAccount() {
    /**
    * create the account array to store in storage
    */
    if (this.defaultAcc) {
      if (this.accountList.length) {
        const acc = this.accountList.filter((val) => {
          return val === this.defaultAcc;
        });
        if (!acc || !acc.length) {
          this.accountList.push(this.defaultAcc);
        }
      } else {
        this.accountList.push(this.defaultAcc);
      }
    } else {
      if (this.accountList.length === 1) {
        localStorage.setItem(ConstantsVAR.DEF_ACC_KEY, this._jsEcd.encode(this.accountList[0]));
      }
    }

    const arr = [...this.accountList].sort();
    const filteredArray = arr.filter(function (item, pos) {
      return arr.indexOf(item) === pos;
    });

    const customerAccounts: AccountListDTO = {
      cAccNoLi: filteredArray
    };
    localStorage.setItem(ConstantsVAR.ACC_KEY, this._jsEcd.encode(JSON.stringify(customerAccounts)));
    return customerAccounts;
  }

  isBookingsExist(requestBody) {
    /**
    * check if booking is exist in the database, navigate based on the response.
    */
    if (sessionStorage.getItem('returnEdiURL')) {
      window.location.href = sessionStorage.getItem('returnEdiURL');
    } else {
      this.isLoaderEnabled = true;
      const apiName = 'isBookingsExist';
      this.apiUnsubscribe(apiName);

      this.subscriptions.push(this.apiSubscription[apiName] =
        this._bookingService.checkBkngAvailbility(requestBody).subscribe((val) => {
          this.isLoaderEnabled = false;
          if (val === 'true') {
            this._router.navigate(['/booking/dashboard']);
          } else if (val === 'false') {
            this._router.navigate(['/booking/wizard']);
          } else {
            this._router.navigate(['/login']);
          }
          this.apiCallCount[apiName] = 0;
        }, error => {
          this.isLoaderEnabled = false;
          this.retryMechanism(error, apiName, requestBody);
        }));
    }
  }

  frgtPsswrd() {
    window.open(ConstantsURL.CONST_FORGOT_PASSWORD + ConstantsURL.CONST_LOCALE, '_blank');
  }

  getLastActiveUser() {
    /**
     * get the last active user from the browser cookies
     */
    const cookies = document.cookie.split(';');
    for (let i = 0; i < cookies.length; i++) {
      const cookie = cookies[i];
      const eqPos = cookie.indexOf('=');
      const name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;

      if (name === ConstantsVAR.LAST_ACTIVE_ACCOUNT) {
        const uName = cookie.split('=')[1] !== 'undefined' ? cookie.split('=')[1] : '';
        this.loginForm.patchValue({ 'userId': uName });
        if (this.loginForm.get('userId').value) {
          this.loginForm.get('rembr').setValue(true);
        }
      }
    }
  }

  apiUnsubscribe(apiName) {
    if (this.apiSubscription[apiName]) { this.apiSubscription[apiName].unsubscribe(); }
  }

  retryMechanism(error, apiName, params, noBaseAPI?) {
    this.apiCallCount[apiName] = this.apiCallCount[apiName] || 1;
    this.apiCallCount[apiName]++;
    if (this._calltoken) {
      if (!noBaseAPI) { this._calltoken.callBaseService(error); }
      if (this.apiCallCount[apiName] <= ConstantsVAR.API_MAX_TRY) {
        this._calltoken.retryServiceCall(error, apiName, params);
      } else {
        this.apiCallCount[apiName] = 0;
      }
    }
  }

  retryCall(data) {
    /**
     * retry call mechanism
     */
    if (data.apiName === 'login') {
      this.login();
    }
    if (data.apiName === ConstantsVAR.ACCESS_TOKEN_API) {
      this.assignTokenCall(ConstantsVAR.ACCESS_TOKEN_API);
    }
    if (data.apiName === 'loginCall') {
      this.loginCall(data.data);
    }
    if (data.apiName === 'logout') {
      this.logout(data.data);
    }
    if (data.apiName === 'getDefaultAccount') {
      this.getDefaultAccount(data.data);
    }
    // check for 'includes' for iterative actc calls
    if (data.apiName.includes('getAccounts')) {
      this.getAccounts(data.data.val, data.data.defVal, data.data.accntListLength, data.data.i);
    }
    if (data.apiName === 'isBookingsExist') {
      this.isBookingsExist(data.data);
    }
  }

  /**** FEDEX LOGIN INTEGRATION ****/
  getFedexAccount() {
    this.isLoaderEnabled = true;
    const apiName = 'getFedexAccount';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] =
      this._fdxLogin.getShipAdminInfoAPI().subscribe((data) => {
        this.isLoaderEnabled = false;
        this._fdxLogin.setShipAdminInfo(data);
        this.apiCallCount[apiName] = 0;
      }, error => {
        this.retryMechanism(error, apiName, '');
        // this.loginFailure();
        this.isLoaderEnabled = false;
      }));
  }
  /**** FEDEX LOGIN INTEGRATION ****/
}

