/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Http } from '@angular/http';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-support',
  templateUrl: './support.component.html',
  styleUrls: ['./support.component.css']
})
export class SupportComponent implements OnInit, OnDestroy {
  supportList = null;
  subscriptions: Array<Subscription> = [];

  constructor(private httpService: Http) { }

  getEmpty(val) {
    /**
     * Replace empty values in json data to "dash"
     */
    return (val === '') ? '-' : val;
  }

  ngOnInit() {
    /**
     * get data from internal JSON file store in assets folder and populate data
     */
    this.subscriptions.push(this.httpService.get('./assets/support.json').subscribe(
      data => {
        this.supportList = data.json();
    this.supportList.forEach(element => {
      element.extrnl = this.getEmpty(element.extrnl);
      element.nfa = this.getEmpty(element.nfa);
    });
    this.supportList.sort(function (a, b) {
      return (a.cNme.toLowerCase() > b.cNme.toLowerCase()) ?
        1 : ((b.cNme.toLowerCase() > a.cNme.toLowerCase()) ? -1 : 0);
        });
      }, (err) => {
      }));
  }

  ngOnDestroy() {
    this.subscriptions.forEach((subscription: Subscription) => { subscription.unsubscribe(); });
  }
}
