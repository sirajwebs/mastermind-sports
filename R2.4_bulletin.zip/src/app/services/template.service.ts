/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved (c) Fedex 2018
 *
 * Typescript code in this page
 */
import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';
import { ConstantsURL as Constants } from '../shared/constants/constants-urls';
import { BaseService } from './base.service';
import { ConstantsVAR } from './../shared/constants/constants-var';

@Injectable()
export class TemplateService extends BaseService {

  constructor(
    private _http: Http,
  ) { super(); }

  getServiceListDrpdwn(): Observable<any> {
    return this._http
      .get(Constants.CONST_CREATE_TEMPLATE_DROPDOWN_SERVICE_LIST_URL, this.setOptions())
      .map((res: Response) => {
        return this.extractData(res)
      }).catch(this.handleError);
  }

  getPackageListDrpdwn(): Observable<any> {
    return this._http
      .get(Constants.CONST_CREATE_TEMPLATE_DROPDOWN_PACKAGE_LIST_URL, this.setOptions())
      .map((res: Response) => {
        return this.extractData(res)
      }).catch(this.handleError);
  }

  saveTemplate(requestBody, fileVal): Observable<any> {
    return this._http.post(Constants.CONST_CREATE_TEMPLATE_SAVE_TEMPLATE_URL, this.formDataOp(requestBody, fileVal), this.setOptions())
      .map((res: Response) => {
        return this.extractDataText(res)
      }).catch(this.handleError);
  }

  updateTemplate(requestBody, fileVal): Observable<any> {
    return this._http.post(Constants.CONST_TEMPLATE_CONTEXT +
      Constants.CONST_UPDATE_EDIT_TEMPLATE, this.formDataOp(requestBody, fileVal), this.setOptions())
      .map((res: Response) => {
        return this.extractDataText(res)
      }).catch(this.handleError);
  }

  getTemplateListDashboard(custAccNo): Observable<any> {
    return this._http.post(Constants.CONST_TEMPLATE_LIST_DASHBOARD_URL, custAccNo, this.setOptions())
      .map((res: Response) => {
        return this.extractDataNStatus(res)
      }).catch(this.handleError);
  }

  makeTemplateDefault(requestBody, custAccNo): Observable<any> {
    return this._http.get(Constants.CONST_TEMPLATE_CONTEXT + requestBody.nDtId +
      Constants.CONST_MAKE_TEMPLATE_DEFAULT_URL + custAccNo, this.setOptions())
      .map((res: Response) => {
        return this.extractDataText(res)
      }).catch(this.handleError);
  }

  createTemplate(requestBody): Observable<any> {
    return this._http.post(Constants.CONST_TEMPLATE_BASIC_CREATE, requestBody, this.setOptions())
      .map((res: Response) => {
        return this.extractDataText(res)
      }).catch(this.handleError);
  }

  actDeactTemplate(requestBody): Observable<any> {
    return this._http.get(Constants.CONST_TEMPLATE_CONTEXT + requestBody.tId +
      Constants.CONST_ACT_DEACT_TEMPLATE_URL + requestBody.act, this.setOptions())
      .map((res: Response) => {
        return this.extractDataText(res)
      }).catch(this.handleError);
  }

  duplicateTemplate(requestBody): Observable<any> {
    return this._http.get(Constants.CONST_TEMPLATE_CONTEXT + requestBody.refTId +
      Constants.CONST_DUPLICATE_TEMPLATE + requestBody.nTNm, this.setOptions())
      .map((res: Response) => {
        return this.extractDataText(res)
      }).catch(this.handleError);
  }

  getTemplateDetails(data): Observable<any> {
    return this._http
      .get(Constants.CONST_FETCH_TEMPLATE_DETAILS_URL + data, this.setOptions())
      .map((res: Response) => {
        return this.extractData(res)
      }).catch(this.handleError);
  }

  getDeleteTemplate(val): Observable<any> {
    const getDeleteTemplate = Constants.CONST_TEMPLATE_CONTEXT + val.tId + Constants.CONST_TEMP_DELETE_GET + val.accno;
    return this._http
      .get(getDeleteTemplate, this.setOptions())
      .map((res: Response) => {
        return this.extractDataBoolean(res)
      }).catch(this.handleError);
  }

  DeleteTemplateNew(id, accno): Observable<any> {
    const DeleteTemplate = Constants.CONST_TEMPLATE_CONTEXT + id + Constants.CONST_TEMP_BOOKING_DELETE + accno;
    return this._http
      .delete(DeleteTemplate, this.setOptions())
      .map((res: Response) => {
        return this.extractDataBoolean(res)
      }).catch(this.handleError);
  }

  checkTemplateName(accNo, tmpNm): Observable<any> {
    return this._http
      .get(Constants.CONST_CHECK_TEMPLATE_NAME + '?acc_no=' + accNo + '&temp_nm=' + tmpNm, this.setOptions())
      .map((res: Response) => {
        return this.extractDataText(res)
      }).catch(this.handleError);
  }

  checkTemplateAvailblty(requestBody) {
    return this._http
      .post(Constants.CONST_TEMPLATE_EXISTS, requestBody, this.setOptions())
      .map((res: Response) => {
        return this.extractDataText(res)
      }).catch(this.handleError);
  }

  setOptions() {
    const headers = new Headers({ 'Authorization': 'Bearer ' + localStorage.getItem(ConstantsVAR.ACCESS_TOKEN) });
    return new RequestOptions({ headers: headers });
  }

  formDataOp(requestBody, fileVal) {
    const formData = new FormData();
    formData.append('template.json', JSON.stringify(requestBody));
    if (fileVal) {
      for (let i = 0; i < fileVal.length; i++) {
        formData.append('ip.file', fileVal[i]);
      }
    }
    return formData;
  }

}

