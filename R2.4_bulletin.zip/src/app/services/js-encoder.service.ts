/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved (c) Fedex 2018
 *
 * Typescript code in this page
 */

import { Injectable } from '@angular/core';

@Injectable()
export class JsEncoderService {

  encode(val) {
    const val_e = btoa(val).replace(/=/g, '');
    return btoa(val_e).replace(/=/g, '');
  }

  decode(val) {
    const val_e = atob(val);
    return atob(val_e);
  }

  encodeString(str) {
    return window.btoa(encodeURIComponent(str));
  }

  decodeString(str) {
    return decodeURIComponent((window.atob(str)));
  }

}
