/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved (c) Fedex 2018
 *
 * Typescript code in this page
 */

import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';
import { ConstantsURL as Constants } from '../shared/constants/constants-urls';
import { BaseService } from './base.service';
import { ConstantsVAR } from './../shared/constants/constants-var';

@Injectable()
export class LabelsAndEmailsService extends BaseService {

  constructor(private _http: Http) {
    super();
  }

  triggerEmail(data): Observable<any> {

    let emailURL;
    if (data.resend) {
      emailURL = Constants.CONST_RESEND_EMAIL;
    } else {
      emailURL = Constants.CONST_TRIGGER_EMAIL;
    }

    if (data.resendAsc) {
      emailURL = Constants.CONST_RESEND_ASC_EMAIL;
    }

    return this._http
      .post(emailURL, this.setBody(data), this.setOptions())
      .map((res) => {
        return this.extractDataText(res)
      }).catch(this.handleError);
  }

  downloadPaperwork(data) {
    return this._http
      .post(Constants.CONST_BOOKING_DOWNLOAD, this.setBody(data), this.setOptions())
      .map((res) => {
        return this.extractData(res)
      }).catch(this.handleError);
  }

  bookingNotify(data) {
    return this._http
      .post(Constants.CONST_BOOKING_NOTIFY, this.setBody(data), this.setOptions())
      .map((res) => {
        return this.extractDataText(res)
      }).catch(this.handleError);
  }

  setOptions() {
    const headers = new Headers({ 'Authorization': 'Bearer ' + localStorage.getItem(ConstantsVAR.ACCESS_TOKEN) });
    return new RequestOptions({ headers: headers });
  }

  setBody(data) {
    const requestBody = {
      'bId': data['bId'],
      'cntyCd': data['country'],
      'accNm': data['accNo'].toString()
    };

    return requestBody;
  }

}
