/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { JsEncoderService } from './js-encoder.service';
import { ConstantsVAR, ConstantsJson } from './../shared/constants/constants-var';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { UserProfile } from './../shared/models/login.models';
import { AddressCopyData } from 'app/shared/models/addressbook.models';

@Injectable()
export class SharedataService {

  private basicBookingSubject = new BehaviorSubject<string>('');
  basicBooking = this.basicBookingSubject.asObservable();

  private wizardTemp = new BehaviorSubject<string>('');
  wizardTempMsg = this.wizardTemp.asObservable();

  private noAccount = new BehaviorSubject<boolean>(null);
  noAccountMsg = this.noAccount.asObservable();

  private isLoggedInSub = new BehaviorSubject<boolean>(null);
  isLoggedInSubMsg = this.isLoggedInSub.asObservable();

  private loginDetails = new BehaviorSubject<object>(this.getuserDetails());
  loginDetailsMsg = this.loginDetails.asObservable();

  private source = new BehaviorSubject<object>(null);
  currentMessage = this.source.asObservable();

  private tempdata = new BehaviorSubject<boolean>(null);
  tempFetchError = this.tempdata.asObservable();

  private editDltMsg = new BehaviorSubject<boolean>(false);
  edtDltTxt = this.editDltMsg.asObservable();

  private bkngSave = new BehaviorSubject<object>(null);
  bkngSveMsg = this.bkngSave.asObservable();

  private bkngDrftSave = new BehaviorSubject<object>(null);
  bkngSveDrftMsg = this.bkngDrftSave.asObservable();

  private bookingId = new BehaviorSubject<string>('');
  getBkngID = this.bookingId.asObservable();

  private searchData = new BehaviorSubject<string>('');
  getSearch = this.searchData.asObservable();

  private templateId = new BehaviorSubject<string>('');
  gettempId = this.templateId.asObservable();

  private trackURL = new BehaviorSubject<boolean>(null);
  getBkngURL = this.trackURL.asObservable();

  // Sort filter check
  private srtFltrCheck = new BehaviorSubject<boolean>(null);
  getSrtFltrChck = this.srtFltrCheck.asObservable();

  // filters of filter check
  private filtersOfFilters = new BehaviorSubject<any>(0);  // check
  getFiltersOfFilters = this.filtersOfFilters.asObservable();

  private tempDel = new BehaviorSubject<string>('');
  getTempDel = this.tempDel.asObservable();

  private pprwrkDataBase64 = new BehaviorSubject<any>('');
  getPprwrkDataBase64 = this.pprwrkDataBase64.asObservable();

  private addrBkCopyData = new BehaviorSubject<AddressCopyData>(ConstantsJson.addrBkDataInit);
  getAddrBkCopyData = this.addrBkCopyData.asObservable();

  constructor(private _jsEcd: JsEncoderService) { };

  setPprwrkDataBase64(data) {
    this.pprwrkDataBase64.next(data);
  }

  // filters of filter check
  setFiltersOfFilter(flofltr) {
    this.filtersOfFilters.next(flofltr);
  }

  // Sort filter check
  setSrtFltrChck(srtfltr) {
    this.srtFltrCheck.next(srtfltr);
  }

  setTempDel(data) {
    this.tempDel.next(data);
  }

  setBkngURL(srt) {
    this.trackURL.next(srt);
  }

  setTempalteId(tId) {
    this.templateId.next(tId);
  }

  setSearchInput(val) {
    this.searchData.next(val);
  }

  setBkngID(bId) {
    this.bookingId.next(bId);
  }

  changeMessage(message) {
    this.source.next(message);
  }

  templateFetchError(data) {
    this.tempdata.next(data);
  }

  editDeleteMsg(data) {
    this.editDltMsg.next(data);
  }

  bkngSveScs(data) {
    this.bkngSave.next(data);
  }

  bkngSveDrftScs(data) {
    this.bkngDrftSave.next(data);
  }

  setLoginDetails(data) {
    try {
      localStorage.setItem(ConstantsVAR.USER_DETAILS, data ? this._jsEcd.encode(JSON.stringify(data)) : '');
    } catch (error) { }
    this.loginDetails.next(data);
  }

  getuserDetails(): UserProfile {
    try {
      const data = localStorage.getItem(ConstantsVAR.USER_DETAILS);
      return data ? JSON.parse(this._jsEcd.decode(data)) : null;
    } catch (error) { return null; }
  }

  setIsLoggedInSub(data) {
    this.isLoggedInSub.next(data);
  }

  setBasicBooking(data) {
    this.basicBookingSubject.next(data);
  }

  setWizardTemp(data) {
    this.wizardTemp.next(data);
  }

  setNoAccount(data) {
    this.noAccount.next(data);
  }

  setAddrBkCopyData(data) {
    this.addrBkCopyData.next(data);
  }
}

