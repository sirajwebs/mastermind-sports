/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';
import { ConstantsVAR, RequestHeaders } from './../shared/constants/constants-var';
import { Response, RequestOptions, Headers} from '@angular/http';

@Injectable()
export class BaseService {

  constructor() { }

  extractData(res: Response) {
    const body = res.json();
    return body;
  }

  extractDataText(res: Response) {
    const body = res.text();
    return body;
  }

  extractDataNStatus(res: Response) {
    if (res.status === ConstantsVAR.API_STATUS_CODE_204) {
      return res.text();
    } else {
      return res.json();
    }
  }

  extractDataBoolean(res: Response) {
    return (res.status === 200) ? true : false;
  }
  
  handleError(error: Response) {
    // Server Error ::: Status ERROR:
      return Observable.throw(error.status);
  }

  handleErrorAll(error: Response) {
    // Server Error ::: ALL ERROR:
      return Observable.throw(error);
  }

  handleErrorMsg(error: Response) {
    // Server Error ::: TEXT OR JSON:
    if (error.status === ConstantsVAR.API_STATUS_CODE_409) {
      return Observable.throw(error.text());
    } else {
      return Observable.throw(error.json());
    }
  }

  setRequestOptions(tokenName: string) {
    /**
     * setting request headers for API
     */
    const headers = new Headers({
      'Authorization': RequestHeaders.Authorization + localStorage.getItem(tokenName)
    });

    if (tokenName === ConstantsVAR.FEDEX_TOKEN) {
        headers.append('Content-Type', RequestHeaders.ContentType);
        headers.append('Accept', RequestHeaders.Accept);
        headers.append('X-locale', RequestHeaders.XLocale);
        headers.append('X-loggedin', RequestHeaders.XLoggedin);
        headers.append('X-clientid', RequestHeaders.XClientid);
        headers.append('X-clientversion', RequestHeaders.XClientversion);
        return new RequestOptions({ headers: headers, withCredentials: true });
    }
    return new RequestOptions({ headers: headers});
  }
}
