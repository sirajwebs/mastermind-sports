/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved (c) FedEx 2018
 *
 * Typescript code in this page
 */

import { ConstantsVAR, DateConstants } from './../shared/constants/constants-var';
import { Injectable } from '@angular/core';

@Injectable()
export class SharedFunctionsService {

  constructor() { }

  getDateInJson(val) {
    /**
     * convert any date object format to UTC date object format
     * "YYYY-MM-DD'T'HH:mm:ss.mmm'Z'  = 2019-03-20T14:39:22.444Z
     */
    const dt = new Date(val);
    const year = dt.getFullYear();
    const month = this.appendZeroToVal(dt.getMonth() + 1);
    const date = this.appendZeroToVal(dt.getDate());
    const hours = this.appendZeroToVal(dt.getHours());
    const minutes = this.appendZeroToVal(dt.getMinutes());
    const seconds = this.appendZeroToVal(dt.getSeconds());
    const milliseconds = dt.getMilliseconds();
    const ftime = year + '-' + month + '-' + date + 'T' + hours + ':' + minutes + ':' + seconds + '.' + milliseconds + 'Z';
    return ftime;
  }

  getOnlyDate(val) {
    /**
     * return only date in YYYY-MM-DD format
     * example 2019-05-25
     */
    const dt = new Date(val);
    const year = dt.getFullYear();
    const month = this.appendZeroToVal(dt.getMonth() + 1);
    const date = this.appendZeroToVal(dt.getDate());
    const ftime = year + '-' + month + '-' + date;
    return ftime;
  }

  getTommorrowDate() {
    /**
     * return tommorrow date in relative to current date
     * Tue Jul 23 2019 14:29:09 GMT+0530 (India Standard Time) - Today
     * Wed Jul 24 2019 14:29:09 GMT+0530 (India Standard Time) - Tommorrow
     */
    return new Date(new Date().setDate(new Date().getDate() + 1));
  }

  getOnlyTimeInHourMinutes(val) {
    /**
     * return only time in hh:mm format in 24 hour
     * example 14:56
     */
    const dt = new Date(val);
    const hh = this.appendZeroToVal(dt.getHours());
    const mm = this.appendZeroToVal(dt.getMinutes());
    const ftime = hh + ':' + mm;
    return ftime;
  }

  appendZeroToVal(val) {
    /**
     * append zero to number which are less than 10
     * FORMAT --- 9 will be '09'
     */
    return (val < ConstantsVAR.DIGIT_10) ? ('0' + val) : val;
  }

  convertDateToUserFormat(val) {
    /**
    * convert date object to string date format
    * FORMAT --- Monday, June 07 2019 (day, month date year) 
    */
    const dt = new Date(val);
    const days = DateConstants.DAYS;
    const months = DateConstants.MONTHS;
    const strDate = days[dt.getDay()] + ', ' + months[dt.getMonth()] + ' ' + this.appendZeroToVal(dt.getDate()) + ' ' + dt.getFullYear();
    return strDate;
  }

  getDateFromTimezone(data) {
    /**
     * get Date from different time zone by passing offset value to current time zone
     */
    let date;
    const offsets = (data.dstOffset + data.rawOffset);
    date = new Date(new Date().getTime() + (new Date().getTimezoneOffset() *
      ConstantsVAR.MINUTES_1) + (ConstantsVAR.MILISEC_TO_SEC * offsets));
    return date;
  }

  formatDate(dt) {
    /**
     * date response format :::: "Tuesday, February 26 2019"
     */
    if (dt) {
      let date, month;
      const months = DateConstants.MONTHS;
      const dateTemp = dt.split(' ');
      for (let i = 0; i < months.length; i++) {
        if (months[i] === dateTemp[ConstantsVAR.DATE_POS_1]) {
          (i < ConstantsVAR.DIGIT_10 - 1) ? month = '0' + (i + 1) : month = i + 1;
        }
      }
      date = dateTemp[ConstantsVAR.DATE_POS_3] + '-' + month + '-' + dateTemp[ConstantsVAR.DATE_POS_2] + 'T00:00:00.000Z';
      return date;
    }
  }

  sameDay(d1, d2) {
    /**
     * compare two date object for same day
     */
    return (d1.getFullYear() === d2.getFullYear()) &&
      (d1.getMonth() === d2.getMonth()) &&
      (d1.getDate() === d2.getDate());
  }


  checkObjectProprtsForNull(obj) {
    /**
     * iterate through object to check if all properties are null
     */
    for (const key in obj) {
      if (obj[key]) {
        return false;
      }
    }
    return true;
  }

  emptyForNull(val) {
    /**
     * return null or undefined values as emptystring '',
     */
    return (val) ? val : ConstantsVAR.EMPTY_STRING;
  }

  isObjectsEquivalent(a, b) {
    // Create arrays of property names
    const aProps = Object.getOwnPropertyNames(a),
      bProps = Object.getOwnPropertyNames(b);

    // If number of properties is different,
    // objects are not equivalent
    if (aProps.length !== bProps.length) {
      return false;
    }

    for (let i = 0; i < aProps.length; i++) {
      const propName = aProps[i];

      // If values of same property are not equal,
      // objects are not equivalent

      if (this.emptyForNull(a[propName]).trim() !== this.emptyForNull(b[propName]).trim()) {
        return false;
      }
    }

    // If we made it this far, objects
    // are considered equivalent
    return true;
  }

}
