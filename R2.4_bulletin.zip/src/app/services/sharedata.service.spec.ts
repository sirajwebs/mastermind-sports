/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { TestBed, inject } from '@angular/core/testing';

import { SharedataService } from './sharedata.service';

describe('SharedataService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SharedataService]
    });
  });

  it('should be created', inject([SharedataService], (service: SharedataService) => {
    expect(service).toBeTruthy();
  }));
});
