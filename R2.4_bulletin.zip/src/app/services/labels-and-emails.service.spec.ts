/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { TestBed, inject } from '@angular/core/testing';

import { LabelsAndEmailsService } from './labels-and-emails.service';

describe('LabelsAndEmailsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LabelsAndEmailsService]
    });
  });

  it('should be created', inject([LabelsAndEmailsService], (service: LabelsAndEmailsService) => {
    expect(service).toBeTruthy();
  }));
});
