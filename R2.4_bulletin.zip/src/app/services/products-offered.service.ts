/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved (c) Fedex 2018
 *
 * Typescript code in this page
 */
import { Injectable } from '@angular/core';

@Injectable()
export class ProductsOfferedService {

  constructor() { }

}
