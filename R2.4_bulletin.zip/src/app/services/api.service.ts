/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved (c) Fedex 2018
 *
 * Typescript code in this page
 */
import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';
import { ConstantsURL as Constants } from '../shared/constants/constants-urls';
import { BaseService } from './base.service';
import { ConstantsVAR } from './../shared/constants/constants-var';

@Injectable()
export class ApiService extends BaseService {

    constructor(private _http: Http) {
        super();
    }

    validateApi(countryCode: string, postCode): Observable<any> {
        return this._http
            .get(Constants.CONST_VALIDATE_CITY + countryCode + Constants.CONST_VALIDATE_CITY_CHILD_URL + postCode, this.setOptions()) 
            .map((res) => {
                return this.extractData(res)
            }).catch(this.handleError);
    }

    postalAware(countryCode: string): Observable<any> {
        return this._http
            .get(Constants.CONST_COUNTRY_POSTAL_CHECK + countryCode, this.setOptions()) 
            .map((res) => {
                return this.extractData(res)
            }).catch(this.handleError);
    }

    postalNonAwareCity(countryCode: string, city): Observable<any> {
        return this._http
            .get(Constants.CONST_VALIDATE_CITY_NOPOSTAL + countryCode +
                Constants.CONST_VALIDATE_CITY_CHILD_NOPOSTAL + city, this.setOptions())
            .map((res) => {
                return this.extractData(res)
            }).catch(this.handleError);
    }

    setOptions() {
        const headers = new Headers({ 'Authorization': 'Bearer ' + localStorage.getItem(ConstantsVAR.ACCESS_TOKEN) });
        return new RequestOptions({ headers: headers });
    }


}
