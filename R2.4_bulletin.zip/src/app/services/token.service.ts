/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved (c) Fedex 2018
 *
 * Typescript code in this page
 */
import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';
import { ConstantsURL } from './../shared/constants/constants-urls';
import { ConstantsVAR, SearchParams, TokenProperty } from './../shared/constants/constants-var';
import { TokenPropertyDTO } from 'app/shared/models/shared.models.';

@Injectable()
export class TokenService {

    constructor(private _http: Http) {
    }

    assignTokenCallProperty(tokenType) {
        /**
         * assign the token to its respective calls
         */
        let tokenProperty: TokenPropertyDTO;
        switch (tokenType) {
            case ConstantsVAR.ACCESS_TOKEN_API: {
                tokenProperty = {
                    clientID: ConstantsURL.CONST_AUTH_TOKEN_CLIENT_ID,
                    clientSecret: ConstantsURL.CONST_AUTH_TOKEN_CLIENT_SECRET,
                    tokenURL: ConstantsURL.CONST_AUTH_TOKEN_URL,
                    tokenExpireTime: TokenProperty.OAUTH.SET_TOKEN_EXPIRE_TIME,
                    tokenExpireName: TokenProperty.OAUTH.GET_TOKEN_EXPIRE_NAME,
                    tokenCreatedName: TokenProperty.OAUTH.GET_TOKEN_CREATED_NAME,
                    tokenName: TokenProperty.OAUTH.TOKEN_NAME
                }
                break;
            }
            case ConstantsVAR.FEDEX_TOKEN_API: {
                tokenProperty = {
                    clientID: ConstantsURL.CONST_FDX_AUTH_TOKEN_CLIENT_ID,
                    clientSecret: ConstantsURL.CONST_FDX_AUTH_TOKEN_CLIENT_SECRET,
                    tokenURL: ConstantsURL.CONST_FEDEX_AUTH_TOKEN_URL,
                    tokenExpireTime: TokenProperty.FEDEX.SET_TOKEN_EXPIRE_TIME,
                    tokenExpireName: TokenProperty.FEDEX.GET_TOKEN_EXPIRE_NAME,
                    tokenCreatedName: TokenProperty.FEDEX.GET_TOKEN_CREATED_NAME,
                    tokenName: TokenProperty.FEDEX.TOKEN_NAME
                }
                break;
            }
        }
        return tokenProperty;
    }

    getToken(clientID, clientSecret, tokenURL): Observable<any> {
        const headers = new Headers({
            'Content-Type': 'application/x-www-form-urlencoded',
        });

        const params = new URLSearchParams();
        params.set(SearchParams.GRANT_TYPE, SearchParams.CLIENT_CREDENTIALS);
        params.set(SearchParams.CLIENT_ID, clientID);
        params.set(SearchParams.CLIENT_SECRET, clientSecret);
        params.set(SearchParams.SCOPE, SearchParams.OOB);

        const options = new RequestOptions({ headers: headers });
        return this._http.post(tokenURL, params.toString(), options)
            .map((res) => {
                return this.extractData(res);
            }).catch(this.handleError);
    }

    setToken(tknPrprty, tokenData) {
        /**
         * set token creation time, expiration time and token name in localstorage
         * token expiration time is set in minutes
         */
        const date = new Date();
        switch (tknPrprty.tokenExpireTime) {
            case ConstantsVAR.ONE_HOUR_IN_MINUTES: date.setMinutes(date.getMinutes() + ConstantsVAR.ONE_HOUR_IN_MINUTES);
                break;
            case ConstantsVAR.MINUTES_30: date.setMinutes(date.getMinutes() + ConstantsVAR.MINUTES_30);
                break;
        }
        localStorage.setItem(tknPrprty.tokenExpireName, date.toString());
        localStorage.setItem(tknPrprty.tokenCreatedName, new Date().toString());
        localStorage.setItem(tknPrprty.tokenName, tokenData);
    }

    extractData(res: Response) {
        const body = res.json();
        return body;
    }

    handleError(error: Response) {
        return Observable.throw(error.status);
    }
}
