/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { Injectable } from '@angular/core';
import { AddressbookPrivilegeService } from './addressbook-privilege.service';

@Injectable()
export class AllPrivilegesService {

  constructor(private _fdxAddrBkPrvlg: AddressbookPrivilegeService) { }

  // write a service to detect privelege and shipadmininfo are present when loading

  bookingPrvlg() {
    return {
      general: {},
      addrBk: this._fdxAddrBkPrvlg.addressBookPrvlg()
    }
  }
}
