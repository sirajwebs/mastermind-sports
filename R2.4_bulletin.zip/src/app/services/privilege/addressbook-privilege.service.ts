/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { FedexLogonService } from '../fedex-logon.service';
import { Injectable } from '@angular/core';
import { AddressBookConst, FedexLoginConstants } from 'app/shared/constants/constants-var';

@Injectable()
export class AddressbookPrivilegeService {
  usrPrvlgInfo = [];
  isCompanyAdmin = null;

  constructor(private _fdxLogin: FedexLogonService) { }

  extractUserPrivilegeJson(privilegeID: string) {
    const usrPrvlg = this.usrPrvlgInfo.length ? this.usrPrvlgInfo : this.fetchPrvlg();
    const val = usrPrvlg.filter((el) => {
      return el.privilegeID === privilegeID;
    });
    return (val.length ? val[0].authorization === AddressBookConst.Authorization.Y : false);
  }

  addressBookPrvlg() {
    // required for central book privilege - not in 2.4 release
    const isAdmin = this.isCompanyAdmin !== null ? this.isCompanyAdmin : this.isCompAdmin();

    return {
      personalCtrl: this.extractUserPrivilegeJson('PERSONAL_ADDRESS_BOOK_RECIPIENT_CONTROL'),
      // required for central book privilege - not in 2.4 release
      /*  centralView: this.extractUserPrivilegeJson('CENTRAL_ADDRESS_BOOK_RECIPIENT_VIEW'),
       centralMod: isAdmin ? this.extractUserPrivilegeJson('CENTRAL_ADDRESS_BOOK_RECIPIENT_MODIFY') : false,
       sharedView: this.extractUserPrivilegeJson('SHARED_ADDRESS_BOOK_VIEW'),
       senderAdd: this.extractUserPrivilegeJson('PERSONAL_ADDRESS_BOOK_SENDER_ADD'), */
    }
  }

  fetchPrvlg() {
    this.usrPrvlgInfo = this._fdxLogin.fetchPrvlgFromStorage();
    return this.usrPrvlgInfo;
  }

  isCompAdmin() {
    const shpAdmnInfo = this._fdxLogin.getShpAdmnFromStorage();
    this.isCompanyAdmin = shpAdmnInfo.length ? shpAdmnInfo[FedexLoginConstants.FEDEX_ADMIN_DETAILS]['companyAdministrator'] : false;
    return this.isCompanyAdmin;
  }

}
