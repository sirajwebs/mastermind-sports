/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { CanActivate, Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { ConstantsVAR } from './../shared/constants/constants-var';
import { ConstantsURL } from 'app/shared/constants/constants-urls';
import { SharedataService } from './sharedata.service';

@Injectable()
export class RouterGuardService implements CanActivate {

  CloseEdiDwnld = ConstantsVAR.CLOSE_EDI_DWNLD;
  constructor(private _router: Router, private _shrdDtaSrvc: SharedataService) { }

  canActivate() {
    const url = window.location.href;
    let allow = false;
    if (localStorage.getItem('isLoggedIn') === 'true') {
      if (localStorage.getItem('noAccount') ? localStorage.getItem('noAccount') !== 'true' : true) {
        allow = true;
      } else {
        allow = false;
      }
    } else {
      allow = false;
    }

    if (!allow) {
      const ediPopup = <HTMLElement>document.getElementById(this.CloseEdiDwnld);
      try {
        document.getElementById('REMOVE_MODAL_BACKDROP').click();
        ediPopup.click();
      } catch (err) { }
      let waitTime = 0;
      if (ediPopup) { waitTime = ConstantsVAR.MILISEC_200; }
      setTimeout(() => {
        this._router.navigate(['/login']);
        // need to check this window.location redirection later
        window.location.href = window.location.pathname + '#' + ConstantsURL.CONST_LOGIN_URL;
      }, waitTime);
      if (!sessionStorage.getItem('returnEdiURL')) {
        sessionStorage.setItem('returnEdiURL', url);
      }
    }
    return allow;
  }
}
