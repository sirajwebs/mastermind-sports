/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved (c) Fedex 2018
 *
 * Typescript code in this page
 */

import { TestBed, inject } from '@angular/core/testing';
import { JsEncoderService } from './js-encoder.service';

describe('JsEncoderService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [JsEncoderService]
    });
  });

  it('should be created', inject([JsEncoderService], (service: JsEncoderService) => {
    expect(service).toBeTruthy();
  }));
});
