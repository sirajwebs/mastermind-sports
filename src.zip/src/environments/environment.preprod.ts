// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

/**
 * PRE-PROD ENVIRONMENT : L5
 */
/* export const environment = {
  production: true,
  URL: 'https://apitest.emea.fedex.com/',
  TNT_URL: 'https://apitest.emea.fedex.com/digital/',
  SPIRIT_TOKEN_URL: 'https://apitest.emea.fedex.com/',
  FDX_TOKEN_URL: 'https://apitest.fedex.com/',
  CONST_LOGIN: 'https://apitest.fedex.com',
  CONST_AUTH_TOKEN_CLIENT_ID: 'ba0bbfbd-5af5-498d-9f10-7e0f3f171111',
  CONST_AUTH_TOKEN_CLIENT_SECRET: '0a3a5fe6-01f3-4c38-b536-0be9f810900a',
  CONST_FDX_AUTH_TOKEN_CLIENT_ID: 'l7xx191e8e9f11c047188707190bd9930951',
  CONST_FDX_AUTH_TOKEN_CLIENT_SECRET: 'd0e80fe0951843a0be4198fd701263d9',
  GOOGLE_CHANNEL_ID: 'spiritL6',
}; */

// delete below
export const environment = {
  production: true,
  URL: 'https://apitest.emea.fedex.com/',
  TNT_URL: 'https://apitest.emea.fedex.com/digital/',
  SPIRIT_TOKEN_URL: 'https://apitest.emea.fedex.com/',
  FDX_TOKEN_URL: 'https://api.fedex.com/',
  CONST_LOGIN: 'https://api.fedex.com',
  CONST_AUTH_TOKEN_CLIENT_ID: 'ba0bbfbd-5af5-498d-9f10-7e0f3f171111',
  CONST_AUTH_TOKEN_CLIENT_SECRET: '0a3a5fe6-01f3-4c38-b536-0be9f810900a',
  CONST_FDX_AUTH_TOKEN_CLIENT_ID: 'L7xxd303f7141cbf47e2a01b6eb46691be15',
  CONST_FDX_AUTH_TOKEN_CLIENT_SECRET: '72f965dda9874c67a9ee2ac9b550c3df',
  GOOGLE_CHANNEL_ID: 'spiritL6',
};
