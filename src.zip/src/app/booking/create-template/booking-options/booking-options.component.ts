/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */

import { Component, OnInit, OnChanges, SimpleChanges, Input, OnDestroy } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { bookingOptions, bookingExpiration } from '../../../shared/constants/constants-var';
import { MinMaxValue } from 'app/services/validators.service';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-booking-options',
  templateUrl: './booking-options.component.html',
  styleUrls: ['./booking-options.component.css','./../create-template.component.css']
})
export class BookingOptionsComponent implements OnInit, OnChanges, OnDestroy {
  @Input() public showSender: boolean;
  @Input() public editTmpltExprdBkngValue: number;

  subscriptions: Array<Subscription> = [];
  emailDays = new Array(bookingOptions.EMAIL_DAYS);

  bookingOptionForm = new FormGroup({
    showContentRef: new FormControl(false),
    showBkngExpr: new FormControl(false),
    bkngExprNoOfDays: new FormControl(bookingExpiration.DEFAULT_DAYS,
      [Validators.required, MinMaxValue(bookingExpiration.MINIMUM_DAYS, bookingExpiration.MAX_DAYS)]),
    showReminderEmail: new FormControl(false),
    showAdditionalMessage: new FormControl(false),
    reminderEmailDays: new FormControl(bookingOptions.DEFAULT_DAYS)
  });
  constructor() {
    this.onChangeValidation();
  }

  ngOnInit() {  }

  ngOnChanges(changes: SimpleChanges){
    this.setDefaultBookingOptions();
  }

  setDefaultBookingOptions() {
    if(this.showSender){
      if (this.editTmpltExprdBkngValue) {
        this.bookingOptionForm.patchValue({
          bookingOptions: true,
          bkngExprNoOfDays: this.editTmpltExprdBkngValue
        });
      } else {
        this.bookingOptionForm.patchValue({ bookingOptions: false });
      }
    }
  }

  formValidations() {
    return this.bookingOptionForm.valid;
  }

  onChangeValidation() {
    /**
     * check for value changes and update the respective object value 
     * to reflect in selectable field options
     */
    this.subscriptions.push(this.bookingOptionForm.get('showBkngExpr').valueChanges.subscribe(formData => {
      this.bookingOptionForm.get('bkngExprNoOfDays').markAsUntouched();
      if (this.bookingOptionForm.get('showBkngExpr').value) {
        this.bookingOptionForm.get('bkngExprNoOfDays').setValue(bookingExpiration.DEFAULT_DAYS);
        this.bookingOptionForm.get('bkngExprNoOfDays').setValidators(
          [Validators.required, MinMaxValue(bookingExpiration.MINIMUM_DAYS, bookingExpiration.MAX_DAYS)]);
      } else {
        this.bookingOptionForm.get('bkngExprNoOfDays').clearValidators();
        this.bookingOptionForm.get('bkngExprNoOfDays').updateValueAndValidity();
      }
    }));

  }

  ngOnDestroy() {
    this.subscriptions.forEach((subscription: Subscription) => { subscription.unsubscribe(); });
  }
}
