/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */

import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ProductsOfferedComponent } from './products-offered.component';

describe('ProductsOfferedComponent', () => {
  let component: ProductsOfferedComponent;
  let fixture: ComponentFixture<ProductsOfferedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductsOfferedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductsOfferedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
