/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved (c) Fedex 2018
 *
 * Typescript code in this page
 */
import { ConstantsURL as Constants } from '../shared/constants/constants-urls';
import { BaseService } from '../services/base.service';
import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';
import { ConstantsVAR } from './../shared/constants/constants-var';

@Injectable()
export class GoogleapisService extends BaseService {

  constructor(private _http: Http) {
    super();
  }
  setOptions() {
    const headers = new Headers({ 'Authorization': 'Bearer ' + localStorage.getItem(ConstantsVAR.ACCESS_TOKEN) });
    return new RequestOptions({ headers: headers });
  }

  getTimezone(lat, lng, tmstmp, signtr?): Observable<any> {
    return this._http
      .get(Constants.GOOGLE_APIS + lat + ',' + lng + '&timestamp=' + tmstmp + '&key=' +
        Constants.GOOGLE_API_KEY)
      .map((res) => {
        return this.extractData(res)
      }).catch(this.handleError);
  }
}

