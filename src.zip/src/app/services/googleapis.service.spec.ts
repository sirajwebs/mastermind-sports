/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { TestBed, inject } from '@angular/core/testing';

import { GoogleapisService } from './googleapis.service';

describe('GoogleapisService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [GoogleapisService]
    });
  });

  it('should be created', inject([GoogleapisService], (service: GoogleapisService) => {
    expect(service).toBeTruthy();
  }));
});
