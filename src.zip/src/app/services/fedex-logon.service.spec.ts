/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { TestBed, inject } from '@angular/core/testing';
import { FedexLogonService } from './fedex-logon.service';

describe('FedexLogonService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FedexLogonService]
    });
  });

  it('should be created', inject([FedexLogonService], (service: FedexLogonService) => {
    expect(service).toBeTruthy();
  }));
});
