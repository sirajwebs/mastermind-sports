/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */

export interface TemplateListDTO {
    accno: string,
    def: boolean,
    dt: string,
    tId: number,
    tNm: string,
    tSts: string,
};

export interface TemplateBodyDTO {
    tNm: string,
    tId: number,
    cAccNo: number,
    pyr: string,
    gSidReFn: boolean,
    ctRfSmeBkRf: boolean,
    sSidRef: boolean,
    cRFg: boolean,
    sPrEs: boolean,
    cnRFg: boolean,
    sCnf: string,
    gDsc: string,
    insV: number,
    insC: string,
    invcV: number,
    invcC: string,
    svcs: Array<ServicesDTO>,
    pkgs: Array<Object>,
    adr: Array<Object>,
    aSCDt: string,
    sSrvs: string,
    aShTm: number,
    aPkDm: string,
    defTmp: boolean,
    ptId: number,
    docs: Array<Object>
}

export interface ServicesDTO {
    id: number,
    e: boolean,
    d: boolean
}

export interface TemplateAddressDTO {
    cNme: string,
    cPsn: string,
    cd: string,
    cntry: string,
    cty: string,
    e: string,
    l1: string,
    l2: string,
    pCd: string,
    pIn: string,
    tel: string,
    typ: string,
}

export interface SenderOptionsDTO {
    aSCDt: string,
    aPkDm: string,
    sSrvs: string,
    aShTm: string
}

export interface SenderOptions {
    modifySendRcvDetails: string,
    modifyPkgDetails: string,
    showSenderServices: string,
    enableBookingForward: string
}

export interface BookingOptionDTO {
    bkngExp: boolean
}


