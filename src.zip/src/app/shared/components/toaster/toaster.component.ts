/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { Component, OnInit, Input, OnChanges, EventEmitter, Output, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-toaster',
  templateUrl: './toaster.component.html',
  styleUrls: ['./toaster.component.css']
})
export class ToasterComponent implements OnInit, OnChanges {
  @Input() public toaster_msg;
  @Output() public callBtn = new EventEmitter<any>();

  constructor() { }

  ngOnInit() {
    this.toasterCall();

  }
  ngOnChanges(changes: SimpleChanges) {
    this.toasterCall();
  }

  toasterCall() {
    /**
     * toaster msg component to show flash message (reusable component), 
     * empty emit trigger used for action performed after msg shown
     */
    if (this.toaster_msg === 'SC') {
      /**
       * success messages block, time limit 4s
       */
      const success = document.getElementById('success-block');
      success.className = 'show';
      setTimeout(function () {
        success.className = success.className.replace('show', '');
      }, 4000);
    } else if (this.toaster_msg === 'ER') {
      /**
       * error messages block, time limit 4s
       */
      const error = document.getElementById('error-block');
      error.className = 'show';
      setTimeout(function () {
        error.className = error.className.replace('show', '');
      }, 4000);
    } else if (this.toaster_msg === 'ER_D') {
      /**
       * error detailed block, time limit 7s
       */
      const error = document.getElementById('error-block-dlg');
      error.className = 'show';
      setTimeout(function () {
        error.className = error.className.replace('show', '');
        if (this.callBtn) { this.callBtn.emit(''); }
      }, 7000);
    } else if (this.toaster_msg === 'SC_D') {
      /**
       * success detailed block, time limit 7s
       */
      const error = document.getElementById('success-block-dlg');
      error.className = 'show';
      setTimeout(function () {
        error.className = error.className.replace('show', '');
        if (this.callBtn) { this.callBtn.emit(''); }
      }, 7000);
    } else if (this.toaster_msg === 'SC_D2') {
      /**
       * success detailed block (white), time limit 7s
       */
      const error = document.getElementById('success-block-dlg-white');
      error.className = 'show';
      setTimeout(function () {
        error.className = error.className.replace('show', '');
        if (this.callBtn) { this.callBtn.emit(''); }
      }, 7000);
    }
  }

  close() {
    /**
     * action performed after close button is clicked
     */
    if (this.toaster_msg === 'SC') {
      const success = document.getElementById('success-block');
      success.className = '';
    } else if (this.toaster_msg === 'ER') {
      const error = document.getElementById('error-block');
      error.className = '';
    } else if (this.toaster_msg === 'ER_D') {
      const error = document.getElementById('error-block-dlg');
      error.className = '';
      this.callBtn.emit('');
    } else if (this.toaster_msg === 'SC_D') {
      const error = document.getElementById('success-block-dlg');
      error.className = '';
      this.callBtn.emit('');
    } else if (this.toaster_msg === 'SC_D2') {
      const error = document.getElementById('success-block-dlg-white');
      error.className = '';
      this.callBtn.emit('');
    }
  }

}
