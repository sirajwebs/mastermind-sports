/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DebugElement } from '@angular/core';
import { InsuranceInvoiceComponent } from './insurance-invoice.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UploadComponent } from '../upload-files/upload.component';
import { OverFlowPipe } from 'app/shared/pipes/overFlow.pipe';
import { Component, OnInit, Output, EventEmitter, OnDestroy, Input, OnChanges, SimpleChanges } from '@angular/core';
describe('InsuranceInvoiceComponent', () => {
  let component: InsuranceInvoiceComponent;
  let fixture: ComponentFixture<InsuranceInvoiceComponent>;
  let debugElement: DebugElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [InsuranceInvoiceComponent, UploadComponent, OverFlowPipe],
      imports: [FormsModule,
        ReactiveFormsModule]
    })
    .compileComponents();
    fixture = TestBed.createComponent(InsuranceInvoiceComponent);
    debugElement = fixture.debugElement;
    fixture.autoDetectChanges();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InsuranceInvoiceComponent);
    component = fixture.componentInstance;
    debugElement = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
  
  it('should be reset upload component', async () => {
    component.resetUploadCmpnt();
    fixture.detectChanges();
    expect(component._upld.resetAllData).toBeTruthy();
  });

  it('should be show uploded files', () => {
    const value = [123];
    component.filesUploaded(value);
    fixture.detectChanges();
    component.fileData.emit(value);
    expect(component.fileData).not.toBeNull();
  });

  it('should get documents from template', () => {
    const val = [123]
    component.getDocs(val);
    fixture.detectChanges();
    component.getDocDetails.emit(val);
    expect(component.getDocDetails).not.toBeNull();
  });


  it('should check invoice value is invalid', () => {
    const sampleValue = 'invoiceValue';
    component.checkInvalid(sampleValue);
    fixture.detectChanges();
    expect(sampleValue).toBe('invoiceValue');
    expect(component.invalidInvoice).toBe(true);
  });

  it('should check insurance value is invalid', () => {
  const fieldValue = "insuranceValue";
  component.checkInvalid(fieldValue);
  fixture.detectChanges();
  expect(fieldValue).toBe("insuranceValue");
  expect(component.invalidInsr).toBe(true);
  });

  it('should check invoice value is valid', () => {
    const value = 'invoiceValue';
    component.setValid(value);
    fixture.detectChanges();
    expect(value).toBe('invoiceValue');
    expect(component.invalidInvoice).toBeFalsy();
  });

  it('should check insurance value is valid', () => {
    const tempValue = 'insuranceValue';
    component.setValid(tempValue);
    fixture.detectChanges();
    expect(tempValue).toBe('insuranceValue');
    expect(component.invalidInsr).toBeFalsy();
  });
  
  it('check for invalid entry - if value length is equal to 1', () => {
    spyOn(component, 'checkInvalid');
    const fieldValue = "insuranceValue";
    const tempValue = '.';
    component.checkDot(tempValue, fieldValue);
    component.checkInvalid(fieldValue);
    fixture.detectChanges();
    expect(fieldValue).toBe("insuranceValue");
    expect(component.checkInvalid).toBeTruthy();
  });

  it('check for invalid entry - if value length is more than 1 and dot index is 0', () => {
    spyOn(component, 'checkInvalid');
    const fieldValue = "insuranceValue";
    const tempValue = '..';
    component.checkDot(tempValue, fieldValue);
    fixture.detectChanges();
    expect(component.checkInvalid).toBeTruthy();
  });

  it('check for valid entry - if dot index is greater than 0', () => {
    spyOn(component, 'setValid');
    const fieldValue = "insuranceValue";
    const tempValue = '12.';
    component.checkDot(tempValue, fieldValue);
    fixture.detectChanges();
    expect(component.setValid).toBeTruthy();
  });


  it('check for valid entry - if insurence value is equal to 0', () => {
    spyOn(component, 'setValid');
    const fieldValue = "insuranceValue";
    const tempValue = '';
    component.checkDot(tempValue, fieldValue);
    fixture.detectChanges();
    expect(component.setValid).toBeTruthy();
  });


  it('should clear validators on 0 value of insurance', () => {
    const formValue = {
      goodsDescription: 'good description',
      invoiceValue: 100,
      insuranceCurrency: 'EUR',
      insuranceValue: 0,
      invoiceCurrency: 'EUR',
      uploadTextInvoice: '',
      browseFile: '',
    }
    component.insuranceForm.setValue(formValue);
    component.formValidation();
    fixture.detectChanges();
    const val = component.insuranceForm.get('insuranceValue');
    expect(val).toBeTruthy();

  });


  it('check minimum and maximum value', () => {
    const formValue = {
      goodsDescription: 'good description',
      invoiceValue: 100,
      insuranceCurrency: 'EUR',
      insuranceValue: 0.1,
      invoiceCurrency: 'EUR',
      uploadTextInvoice: '',
      browseFile: '',
    }
    component.insuranceForm.setValue(formValue);
    component.formValidation();
    fixture.detectChanges();
    const val = component.insuranceForm.get('insuranceValue');
    expect(val).toBeTruthy();

  });


  it('should check invalid form value', () => {
    const formValue = {
      goodsDescription: 'good description',
      invoiceValue: 0,
      insuranceCurrency: 'EUR',
      insuranceValue: 0,
      invoiceCurrency: 'EUR',
      uploadTextInvoice: '',
      browseFile: '',
    }
    component.insuranceForm.setValue(formValue);
    component.formValidation();
    fixture.detectChanges();
    const val = component.insuranceForm;
    expect(val).toBeTruthy();
  });

  it('should check percentage - Insurance value must not exceed 110 % of Invoice value', () => {
    const formValue = {
      goodsDescription: 'good description',
      invoiceValue: 100,
      insuranceCurrency: 'EUR',
      insuranceValue: 123333,
      invoiceCurrency: 'EUR',
      uploadTextInvoice: '',
      browseFile: '',
    }
    component.insuranceForm.setValue(formValue);
    fixture.detectChanges();
    const val = component.insuranceForm;
    expect(val).toBeTruthy();
    expect(component.invoiceExceeds).toBe(true);
  });


  it('should be disable insurance and invoice block on view booking ', () => {
    const formValue = {
      goodsDescription: 'good description',
      invoiceValue: 10,
      insuranceCurrency: 'EUR',
      insuranceValue: 10,
      invoiceCurrency: 'EUR',
      uploadTextInvoice: '',
      browseFile: '',
    }
    component.insuranceForm.setValue(formValue);
    component.disableFieldsForView();
    fixture.detectChanges();
    const val = component.insuranceForm;
    expect(val).toBeTruthy();
    expect(val.disabled).toBeTruthy();
  });

  it('should be disable all field when user is on view screen', () => {
    component.readonlyField = true;
    component.setInsrncDataFlag = true;
      const formValue = {
        goodsDescription: 'test',
        invoiceValue: 100,
        insuranceCurrency: '',
        insuranceValue: 10,
        invoiceCurrency: '',
        uploadTextInvoice: '',
        browseFile: '',
      }
      let errors = {};
      component.insuranceForm.setValue(formValue);
      component.setInsrncDataFetch();
      fixture.detectChanges();
      const val = component.insuranceForm.get('goodsDescription');
      errors = val.errors || {};
      expect(errors['required']).toBeFalsy();
      expect(component.setInsrncDataFlag).toBeTruthy();
      expect(component.disableFieldsForView).toBeTruthy();
      expect(component.readonlyField).toBeTruthy();
     
    });

    it('check difference', () => {
      const changes: SimpleChanges = {};
      component.ngOnChanges(changes);
      fixture.detectChanges();
      expect(component.setInsrncDataFetch).toBeTruthy();
    
    });
  
});