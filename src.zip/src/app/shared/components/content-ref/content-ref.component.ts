/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { ConstantsVAR } from './../../constants/constants-var';

@Component({
  selector: 'app-content-ref',
  templateUrl: './content-ref.component.html',
  styleUrls: ['./content-ref.component.css']
})
export class ContentRefComponent implements OnInit, OnChanges {
  @Input() cRefNum;
  @Input() readonlyField;
  @Output() public contentRefNumbers = new EventEmitter<any>();

  contentRefForm = new FormGroup({
    contentRefNo: new FormControl('', [Validators.pattern('[a-zA-Z0-9 _-]*')])
  });

  contentRefBody = []; // check datatype ***
  totalContentRefFlag = false;
  constructor() { }

  ngOnInit() {  this.contentRefNumbers.emit(this.contentRefBody);}

  ngOnChanges(changes: SimpleChanges) {
    if (changes) {
      if (changes.cRefNum) {
        if (changes.cRefNum.previousValue !== changes.cRefNum.currentValue) {
          if (this.cRefNum) {
            this.contentRefBody = this.cRefNum;
          }
        } else if (changes.cRefNum.firstChange) {
          this.contentRefBody = this.cRefNum;
        }
      }
    }
  }

  addContentRef() {
    /**
     * add / append content refrence number to booking body.
     */
    const tempCntntRefno = (this.contentRefForm.get('contentRefNo').value === null) ?
    '' : this.contentRefForm.get('contentRefNo').value.trim();
    if (tempCntntRefno && this.contentRefForm.valid) {
      if (this.contentRefBody) {
        if ((this.contentRefBody.length >= 1) && (this.contentRefBody.length < ConstantsVAR.CONTENT_REF_MAX)) {
          this.totalContentRefFlag = false;
            this.contentRefBody.push(tempCntntRefno);
            this.emitAndReset();
        } else if ((this.contentRefBody.length < 1)) {
          /**
           *  check for length of array.
           */
          this.totalContentRefFlag = false;
          this.contentRefBody = [tempCntntRefno];
          this.emitAndReset();
        } else {
          this.totalContentRefFlag = true;
        }
      } else {
        this.contentRefBody = [tempCntntRefno];
        this.emitAndReset();
      }
    }
  }

  emitAndReset() {
    this.contentRefNumbers.emit(this.contentRefBody);
    this.contentRefForm.get('contentRefNo').reset('');
  }

  deleteContentRefNo(index) {
    /**
     * delete content refrence number on click event.
     */
    this.contentRefBody.splice(index, 1);
    this.contentRefNumbers.emit(this.contentRefBody);
    this.totalContentRefFlag = false;
  }

  isFieldRequired(field) {
    /**
     * return true or false based on required field.
     */
    return ((this.contentRefForm.get(field).touched && this.contentRefForm.get(field).invalid)
      && this.contentRefForm.get(field).hasError('required'));
  }

}
