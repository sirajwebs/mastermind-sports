/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AddressComponent } from './address.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ApiService } from './../../../services/api.service';
import { AutofillDrpdwnComponent } from './autofill-drpdwn/autofill-drpdwn.component';
import { CountryApiDirective } from 'app/shared/utils/country-api.directive';
import { PostalApiDirective } from 'app/shared/utils/postal-api.directive';
import { HttpModule } from '@angular/http';
import { CalltokenComponent } from './../../calltoken/calltoken.component';
import { GoogleapisService } from './../../../services/googleapis.service';

describe('AddressComponent', () => {
  let component: AddressComponent;
  let fixture: ComponentFixture<AddressComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AddressComponent,
        CalltokenComponent,
        AutofillDrpdwnComponent,
        CountryApiDirective,
        PostalApiDirective,
      ],
      imports: [
        FormsModule,
        ReactiveFormsModule
      ],
      providers: [
        ApiService,
        GoogleapisService
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
