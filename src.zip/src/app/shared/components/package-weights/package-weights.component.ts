/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { CalltokenComponent } from './../../calltoken/calltoken.component';
import { TemplateService } from 'app/services/template.service';
import { Subscription } from 'rxjs/Subscription';
import { Component, OnInit, Output, EventEmitter, ViewChild, ElementRef, Input, OnChanges, OnDestroy, SimpleChanges } from '@angular/core';
import { FormControl, FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MinMaxValue } from 'app/services/validators.service';
import { ConstantsVAR, PckgWghtCONST } from '../../constants/constants-var';

@Component({
  selector: 'app-package-weights',
  templateUrl: './package-weights.component.html',
  styleUrls: ['./package-weights.component.css']
})
export class PackageWeightsComponent implements OnInit, OnChanges, OnDestroy {
  @ViewChild(CalltokenComponent) public _calltoken: CalltokenComponent;

  @ViewChild('packageType') public packageTypeSelect: ElementRef;
  @Output() public packageData = new EventEmitter<any>();
  @Output() public packageDimensionsData = new EventEmitter<any>();
  @Input() public setPckgDataFlag;
  @Input() public setPckgDetails;
  @Input() public bookingFlag;

  previousFormValue: any = {}; // check datatype ***
  checkOrNot = null;
  @Input() public readonlyField;
  apiSubscription = [];

  totalQuantity: number;
  public packageForm: FormGroup;
  itemRows: FormArray;
  packagetype: FormControl;
  packageLimit: Number = 19;
  showEnvelope = false;
  subscriptions: Array<Subscription> = [];
  packageList = []; 
  defaultPackageBOX = PckgWghtCONST.PCKG_TYPE_ID_BOX;
  defaultQuantity: Number = 1;

  totalVolume: number;
  totalWeight = 0;
  formBuilder: any; // *** check datatypes
  serverError = null;
  numbers = [];
  addPackageFlag = false;
  valuechange = false;
  prType: string;
  apiCallCount = [];
  evelopeValueGoods = 'Goods (non documents)';
  envelopeDocs = 'Documents (paper only)';
  maxPackLength = ConstantsVAR.MAXIMUM_PACKAGE;
  @Output() packgValueChange = new EventEmitter<any>();
  @Output() packgValueChangeEmit = new EventEmitter<any>();

  constructor(private _template: TemplateService, private _fb: FormBuilder) {
    this.numbers = new Array(99).fill('', 0, 99).map((x, i) => i + 1);
  }

  ngOnInit() {
    /**
     * package types logic a/c to business need (mapped with packages id)
     */
    if (this.setPckgDetails) {
      for (let i = 0; i < this.setPckgDetails.length; i++) {
        if ((this.setPckgDetails[i].id === PckgWghtCONST.PCKG_TYPE_ID_PALLET) ||
          (this.setPckgDetails[i].id === PckgWghtCONST.PCKG_TYPE_ID_BOX) ||
          (this.setPckgDetails[i].id === PckgWghtCONST.PCKG_TYPE_ID_ENVELOPE && (this.setPckgDetails[i].enc === this.evelopeValueGoods))) {
          this.prType = 'N';
        } else if (this.setPckgDetails[i].id === PckgWghtCONST.PCKG_TYPE_ID_ENVELOPE &&
          (this.setPckgDetails[i].enc === this.envelopeDocs)) {
          this.prType = 'D';
        } else {
          this.prType = null;
        }
      }
    }

    this.packageForm = this._fb.group({
      itemRows: this._fb.array([this.initItemRows()])
    });

    this.fetchPackageList();
    this.OnBookingTemplateChange();

    this.subscriptions.push(this.packageForm.valueChanges.subscribe(val => {
      /**
       * emit this when there is any changes in the packages sections
       */
      this.packgValueChangeEmit.emit(true);
      if (!this.addPackageFlag) {
        this.getValues();
        for (let i = 0; i < (<FormArray>this.packageForm.controls['itemRows']).value.length; i++) {
          let keepGoing = true;
          Object.keys((<FormGroup>(<FormArray>this.packageForm.controls['itemRows']).controls[i]).controls).forEach(key => {
            if (keepGoing) {
              if ((<FormGroup>(<FormArray>this.packageForm.controls['itemRows']).controls[i]).get(key).dirty) {
                this.packgValueChange.emit(true);
                keepGoing = false;
              }
            }
          });
        }
      }
    }));

    this.formOnChanges();
    this.getValues();
  }

  ngOnDestroy() {
    this.subscriptions.forEach((subscription: Subscription) => { subscription.unsubscribe(); });
    Object.keys(this.apiSubscription).forEach(apiName => { this.apiUnsubscribe(apiName); });
}

  fetchPackageList() {
    /**
     * get the default packages types stored into the DB
     */
    const apiName = 'fetchPackageList';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] = this._template.getPackageListDrpdwn().subscribe(data => {
      this.packageList = data;
      this.serverError = false;
      this.apiCallCount[apiName] = 0;
    }, error => {
      this.serverError = true;
      this.retryMechanism(error, apiName, '');
    }));
  }

  ngOnChanges(changes: SimpleChanges) {
    /**
     * trigger this whenever theere is any change in the packages data input values
     */
    if (changes.setPckgDetails) {
      if ((changes.setPckgDetails.previousValue !== changes.setPckgDetails.currentValue) && changes.setPckgDetails.currentValue) {
        this.OnBookingTemplateChange();
        this.getValues();
      }
    }
  }

  emitChanges() {
    this.formOnChanges();
    this.packgValueChangeEmit.emit(true);
  }

  OnBookingTemplateChange() {
    /**
     * create the form array for the package component along with the validators
     */
    if (this.setPckgDataFlag) {
      this.packageForm = this._fb.group({
        itemRows: this._fb.array([this.initItemRows()])
      });

      this.deleteAllPack();
      const packValArr = [];
      if (this.packageForm) {
        const control = <FormArray>this.packageForm.controls['itemRows'];
        if (this.setPckgDetails) {
          let formGroupValue;
          for (let i = 0; i < this.setPckgDetails.length; i++) {
            if (this.bookingFlag) {
              /**
               * validators for booking page
               */
              formGroupValue = {
                packagetype: new FormControl(this.setPckgDetails[i].id, Validators.required),
                quantity: new FormControl(this.setPckgDetails[i].q, Validators.required),
                packageHeight: new FormControl(this.setPckgDetails[i].h,
                  [Validators.required, MinMaxValue(PckgWghtCONST.MIN_PCKG_LWH, PckgWghtCONST.MAX_PCKG_LWH)]),
                packageWidth: new FormControl(this.setPckgDetails[i].wd,
                  [Validators.required, MinMaxValue(PckgWghtCONST.MIN_PCKG_LWH, PckgWghtCONST.MAX_PCKG_LWH)]),
                packageLength: new FormControl(this.setPckgDetails[i].l,
                  [Validators.required, MinMaxValue(PckgWghtCONST.MIN_PCKG_LWH, PckgWghtCONST.MAX_PCKG_LWH)]),
                packageWeight: new FormControl(this.setPckgDetails[i].wg,
                  [Validators.required, Validators.min(PckgWghtCONST.MIN_PCKG_WGHT), Validators.max(PckgWghtCONST.MAX_PCKG_WGHT)]),
                envelope: new FormControl(this.setPckgDetails[i].enc)
              };
            } else {
              /**
               * validators for template page
               */
              formGroupValue = {
                packagetype: new FormControl(this.setPckgDetails[i].id),
                quantity: new FormControl(this.setPckgDetails[i].q),
                packageHeight: new FormControl(this.setPckgDetails[i].h, 
                  MinMaxValue(PckgWghtCONST.MIN_PCKG_LWH, PckgWghtCONST.MAX_PCKG_LWH)),
                packageWidth: new FormControl(this.setPckgDetails[i].wd, 
                  MinMaxValue(PckgWghtCONST.MIN_PCKG_LWH, PckgWghtCONST.MAX_PCKG_LWH)),
                packageLength: new FormControl(this.setPckgDetails[i].l,
                   MinMaxValue(PckgWghtCONST.MIN_PCKG_LWH, PckgWghtCONST.MAX_PCKG_LWH)),
                packageWeight: new FormControl(this.setPckgDetails[i].wg,
                  [Validators.min(PckgWghtCONST.MIN_PCKG_WGHT), Validators.max(PckgWghtCONST.MAX_PCKG_WGHT)]),
                envelope: new FormControl(this.setPckgDetails[i].enc)
              };
            }
            control.push(this._fb.group(formGroupValue));
          };
        }
      }
    }
  }

  formOnChanges() {
    /**
     * Calls on form value changes 
     * to emit default values to parent component
     */
    this.packageBodyCreator(this.packageForm.get('itemRows').value);
    this.subscriptions.push(this.packageForm.get('itemRows').valueChanges.subscribe((formData) => {
      if (!this.addPackageFlag) {
        this.checkDocType(formData);
        this.onChangeValidation();
        this.packageBodyCreator(formData);
        formData.forEach((formEle, index) => {
          if (formEle.packagetype) {
            if (formEle.packagetype === '3') {
              this.showEnvelope = true;
            } else {
              this.showEnvelope = false;
            }
          }
        });
      }
    }));
  }



  /**
   * Logic to check every field if it is valid or not.  
   * First remove unwanted controls for envelope. 
   *  If FormArray is invalid iterate over array and den iterate over controls.  
   * Check if formcontrol is valid  and touched, if satisifes push true to tempArray else push false.
   *   then check for true in temp arra if availble show error message else hide   
   */

  onChangeValidation() {
    this.getValues();
    this.packageBodyCreator(this.packageForm.get('itemRows').value);
  }

  checkDocType(formData) {
     /**
     * package types logic a/c to business need (mapped with packages id)
     */
    const pcktypArray = [];
    for (let i = 0; i < formData.length; i++) {
      pcktypArray.push(+(formData[i].packagetype));
      if (i === (formData.length - 1)) {
        for (let j = 0; j < pcktypArray.length; j++) {
          if ((pcktypArray[j] === PckgWghtCONST.PCKG_TYPE_ID_BOX) || (pcktypArray[j] === PckgWghtCONST.PCKG_TYPE_ID_PALLET) ||
            (pcktypArray[j] === PckgWghtCONST.PCKG_TYPE_ID_ENVELOPE && (formData[j].envelope === this.evelopeValueGoods))) {
            this.prType = 'N';
          } else if (pcktypArray[j] === PckgWghtCONST.PCKG_TYPE_ID_ENVELOPE && (formData[j].envelope === this.envelopeDocs)) {
            this.prType = 'D';
          } else {
            this.prType = null;
          }
        }
      }
    }
  }

  getEnvelope(val) {
    if (+(val.get('packagetype').value) === PckgWghtCONST.PCKG_TYPE_ID_ENVELOPE) {
      return true;
    } else {
      return false;
    };
  }

  getValues() {
    this.totalWeight = 0;
    let volumeTemp = 0;
    this.totalQuantity = 0;
    /**
     * to check whether a row is touched or not & if touched whether values are entered or not
     *  If not entered-  showReqError -is made to true
     */
    (<FormArray>this.packageForm.get('itemRows')).controls.forEach((element, index) => {
      let packWeight;
      let packHeight;
      let packLength;
      let packWidth;
      const packagetype = element.get('packagetype').value;
      const quan = element.get('quantity').value;

      if (element.get('packageWeight')) {
        packWeight = element.get('packageWeight').value * quan;
      }
      if (element.get('packageHeight')) {
        packHeight = element.get('packageHeight').value;
      }
      if (element.get('packageLength')) {
        packLength = element.get('packageLength').value;
      }
      if (element.get('packageWidth')) {
        packWidth = element.get('packageWidth').value;
      }

      if (packWeight) {
        this.totalWeight += parseFloat(packWeight);
        this.totalWeight = Math.round(this.totalWeight * ConstantsVAR.DIGIT_3_ROUNDUP) / ConstantsVAR.DIGIT_3_ROUNDUP;
      }
      if (!this.totalWeight) {
        this.totalWeight = 0;
      }

      if (+packagetype === PckgWghtCONST.PCKG_TYPE_ID_ENVELOPE) {
        packHeight = 1; packLength = 1; packWidth = 1;
      }

      if ((!isNaN(parseFloat(packLength))) && (!isNaN(parseFloat(packHeight))) && (!isNaN(parseFloat(packWidth)))) {
        volumeTemp += +((parseFloat(packLength) * parseFloat(packHeight) * parseFloat(packWidth)) * quan) / 1000000;
      }

      if (isNaN(volumeTemp)) {
        if (isNaN(this.totalVolume)) {
          this.totalVolume = 0;
        }
      } else {
        this.totalVolume = +volumeTemp;
        this.totalVolume = Math.round(this.totalVolume * ConstantsVAR.DIGIT_3_ROUNDUP) / ConstantsVAR.DIGIT_3_ROUNDUP;
      }

      this.totalQuantity += +parseInt(quan, ConstantsVAR.DIGIT_10);
      if (this.totalQuantity > 99) {
        this.packageForm.controls.itemRows.setErrors({});
      }
      const dimensionData = {
        'vol': +volumeTemp,
        'quant': this.totalQuantity,
        'wt': this.totalWeight,
        'prType': this.prType
      };

      if (this.packageForm.get('itemRows').value.length - 1 === index) {
        this.packageDimensionsData.emit(dimensionData);
      }
    });

  }

  initItemRows() {
    /**
     * Initialize an Empty Row
     */
    this.valuechange = false;
    this.formBuilder = this._fb.group({
      packagetype: new FormControl('2', Validators.required),
      quantity: new FormControl('1', Validators.required),
      packageHeight: new FormControl('', [Validators.required, MinMaxValue(PckgWghtCONST.MIN_PCKG_LWH, PckgWghtCONST.MAX_PCKG_LWH)]),
      packageWidth: new FormControl('', [Validators.required, MinMaxValue(PckgWghtCONST.MIN_PCKG_LWH, PckgWghtCONST.MAX_PCKG_LWH)]),
      packageLength: new FormControl('', [Validators.required, MinMaxValue(PckgWghtCONST.MIN_PCKG_LWH, PckgWghtCONST.MAX_PCKG_LWH)]),
      packageWeight: new FormControl('', [Validators.required,
      Validators.min(PckgWghtCONST.MIN_PCKG_WGHT), Validators.max(PckgWghtCONST.MAX_PCKG_WGHT)]),
      envelope: new FormControl(this.evelopeValueGoods)
    });

    if (this.bookingFlag) {
      this.checkOrNot = true;
    } else {
      this.checkOrNot = false;
      this.formBuilder.get('packageHeight').clearValidators();
      this.formBuilder.get('packageHeight').setValidators(MinMaxValue(PckgWghtCONST.MIN_PCKG_LWH, PckgWghtCONST.MAX_PCKG_LWH));
      this.formBuilder.get('packageHeight').updateValueAndValidity();

      this.formBuilder.get('packageWidth').clearValidators();
      this.formBuilder.get('packageWidth').setValidators(MinMaxValue(PckgWghtCONST.MIN_PCKG_LWH, PckgWghtCONST.MAX_PCKG_LWH));
      this.formBuilder.get('packageWidth').updateValueAndValidity();

      this.formBuilder.get('packageLength').clearValidators();
      this.formBuilder.get('packageLength').setValidators(MinMaxValue(PckgWghtCONST.MIN_PCKG_LWH, PckgWghtCONST.MAX_PCKG_LWH));
      this.formBuilder.get('packageLength').updateValueAndValidity();

      this.formBuilder.get('packageWeight').clearValidators();
      this.formBuilder.get('packageWeight').setValidators(
        [Validators.min(PckgWghtCONST.MIN_PCKG_WGHT), Validators.max(PckgWghtCONST.MAX_PCKG_WGHT)]);
      this.formBuilder.get('packageWeight').updateValueAndValidity();
    }

    return this.formBuilder;
  }

  addPackageRow() {
    /**
     * Adds a Row and call the validations change method
     */
    this.valuechange = false;
    this.addPackageFlag = true;
    const control = <FormArray>this.packageForm.controls['itemRows'];
    control.push(this.initItemRows());
    this.addPackageFlag = false;
    this.onChangeValidation();
  }


  packageBodyCreator(formData) {
    /**
     *  Create body and pass data to create template component 
     */
    const packageBody = [];
    try {
      if (formData) {
        for (let i = 0; i < formData.length; i++) {
          if (formData[i].packagetype === '3' || formData[i].packagetype === PckgWghtCONST.PCKG_TYPE_ID_ENVELOPE) {
            packageBody.push(
              {
                'id': formData[i].packagetype,
                'q': formData[i].quantity,
                'enc': formData[i].envelope,
                'wg': formData[i].packageWeight
              });
          } else {
            packageBody.push(
              {
                'id': formData[i].packagetype,
                'q': formData[i].quantity,
                'l': formData[i].packageLength,
                'wd': formData[i].packageWidth,
                'h': formData[i].packageHeight,
                'wg': formData[i].packageWeight
              });
          }
          if (formData.length - 1 === i) {
            this.packageData.emit(packageBody);
          }
        }
      }
    } catch (error) { }
  }


  deletePackageConfirm(index: number) {
    /**
     * delete a package row data along with the formcontrols
     */
    if (this.packageForm) {
      try {
        const control = <FormArray>this.packageForm.controls['itemRows'];
        control.removeAt(index);
        this.onChangeValidation();
        this.valuechange = true;
        this.packgValueChangeEmit.emit(true);
      } catch (error) { }
    }
  }

  deleteAllPack() {
    /**
     * delete the complete forms control array
     */
    if (this.packageForm) {
      const control = <FormArray>this.packageForm.controls['itemRows'];
      for (let i = 0; i < ((<FormArray>this.packageForm.controls['itemRows']).controls).length; i++) {
        control.removeAt(i);
      }
    }
  }

  formValidation() {
    /**
     *  Validate Form on click of save in create template page
     */
    this.removeControls();
    if (this.packageForm.get('itemRows').invalid) {
      if ((<FormArray>this.packageForm.controls['itemRows']).value) {
        for (let i = 0; i < (<FormArray>this.packageForm.controls['itemRows']).value.length; i++) {
          const controlNameArr = Object.keys((<FormGroup>(<FormArray>this.packageForm.controls['itemRows']).controls[i]).controls);
          for (let ind = 0; ind < controlNameArr.length; ind++) {
            (<FormGroup>(<FormArray>this.packageForm.controls['itemRows']).controls[i]).controls[controlNameArr[ind]]
              .markAsTouched({ onlySelf: true });
          }
        }
      }
      return false;
    } else {
      return true;
    }
  }

  formValidationRequiredField() {
    this.removeControls();
    if (this.packageForm.get('itemRows').invalid) {
      return false;
    } else {
      return true;
    }
  }

  removeControls() {
    /**
     * remove the length , width and height formcontrol when packgae type pallete is selected
     */
    for (let i = 0; i < (<FormArray>this.packageForm.controls['itemRows']).value.length; i++) {
      if (+((<FormGroup>(<FormArray>this.packageForm.controls['itemRows']).controls[i]).get('packagetype').value)
        === PckgWghtCONST.PCKG_TYPE_ID_ENVELOPE) {
        (<FormGroup>(<FormArray>this.packageForm.controls['itemRows']).controls[i]).removeControl('packageLength');
        (<FormGroup>(<FormArray>this.packageForm.controls['itemRows']).controls[i]).removeControl('packageHeight');
        (<FormGroup>(<FormArray>this.packageForm.controls['itemRows']).controls[i]).removeControl('packageWidth');
      }
    }
  }

  onpackageTypeChange(lt) {
    /**
     * reset the selected row fomcontrol when package type changes 
     */
    lt.patchValue({
      'quantity': 1
    });
    lt.get('packageLength').reset();
    lt.get('packageWidth').reset();
    lt.get('packageHeight').reset();
    lt.get('packageWidth').reset();
    lt.get('packageWeight').reset();
    lt.get('envelope').reset();
    lt.get('envelope').setValue(this.evelopeValueGoods);

    this.onChangeValidation();
  }

  apiUnsubscribe(apiName) {
    if (this.apiSubscription[apiName]) { this.apiSubscription[apiName].unsubscribe(); }
  }

  retryMechanism(error, apiName, params, noBaseAPI?) {
    this.apiCallCount[apiName] = this.apiCallCount[apiName] || 1;
    this.apiCallCount[apiName]++;
    if (this._calltoken) {
      if (!noBaseAPI) { this._calltoken.callBaseService(error); }
      if (this.apiCallCount[apiName] <= ConstantsVAR.API_MAX_TRY) {
        this._calltoken.retryServiceCall(error, apiName, params);
      } else {
        this.apiCallCount[apiName] = 0;
      }
    }
  }

  retryCall(data) {
    if (data.apiName === 'fetchPackageList') {
      this.fetchPackageList();
    }
  }

}
