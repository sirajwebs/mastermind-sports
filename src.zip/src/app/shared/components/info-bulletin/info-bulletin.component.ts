/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* FedEx 2018
 *
 * Typescript code in this page
 */
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Http } from '@angular/http';
import { Subscription } from 'rxjs/Subscription';
import { SharedataService } from './../../../services/sharedata.service';

@Component({
  selector: 'app-info-bulletin',
  templateUrl: './info-bulletin.component.html',
  styleUrls: ['./info-bulletin.component.css']
})
export class InfoBulletinComponent implements OnInit, OnDestroy {

  subscriptions: Array<Subscription> = [];
  infoBulletin = '';
  bulletinColor = '';
  hideBulletin = false;

  constructor(private httpService: Http, private _shrd: SharedataService) {
    this._shrd.getHideBulletin.subscribe(val => {
      if (val) { this.hideBulletin = true; }
    });
  }

  ngOnInit() {
    /**
     * get data from internal JSON file store in assets folder and populate data
     */
    this.subscriptions.push(this.httpService.get('./assets/bulletin/bulletin.json')
      .subscribe(data => {
        try {
          this.infoBulletin = data.json().message;
          this.bulletinColor = data.json().backgroundColor;
        } catch (error) { }
      }));
  }

  hideBulletinFn() {
    this._shrd.setHideBulletin(true);
  }

  ngOnDestroy() {
    this.subscriptions.forEach((subscription: Subscription) => { subscription.unsubscribe(); });
  }

}
