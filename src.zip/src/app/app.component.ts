/**
 * This file is protected by copyright and trademark laws under US and International law.
 *  All rights reserved *copyright* Fedex 2018
 *
 * Typescript code in this page
 */
import { ConstantsURL, ConstantsURL_Others } from './shared/constants/constants-urls';
import { CalltokenComponent } from './shared/calltoken/calltoken.component';
import { BookingService } from './services/booking.service';
import { SharedataService } from './services/sharedata.service';
import { Router } from '@angular/router';
import { LoginService } from './services/login.service';
import { TokenService } from './services/token.service';
import { Component, OnInit, ViewChild, OnChanges, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { Location } from '@angular/common';
import { ConstantsVAR } from './shared/constants/constants-var';
import { Subscription } from 'rxjs/Subscription';
import { AccountListDTO } from './shared/models/user.models';
import { JsEncoderService } from './services/js-encoder.service';
import { TokenProperty } from './shared/constants/constants-var';
import { LoginResponseV2 } from './shared/models/login.models';
import { FedexLogonService } from './services/fedex-logon.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [FedexLogonService]
})
export class AppComponent implements OnInit, OnChanges, OnDestroy {
  @ViewChild(CalltokenComponent) public _calltoken: CalltokenComponent;

  isBrowserNonSupport = false;
  defaultAcc = '';
  accountList = [];
  previousUrl = '';
  count = 1;
  loginsuccess = false;
  noAccount = false;
  isLoaderEnabled = false;
  apiCallCount = [];
  apiSubscription = [];
  idleTimeoutLimit = 30;    // timeout limit (in minutes)
  hideHeaderFooter = false;
  CloseEdiDwnld = ConstantsVAR.CLOSE_EDI_DWNLD;
  subscriptions: Array<Subscription> = [];
  currYear = new Date().getFullYear();

  constructor(private _router: Router,
    private _cd: ChangeDetectorRef,
    private _jsEcd: JsEncoderService,
    private _fdxLogin: FedexLogonService,
    private _tokenSrvce: TokenService,
    private _loginService: LoginService, private _bookingService: BookingService,
    private _sharedDataService: SharedataService,
    _location: Location) {
    this.subscriptions.push(_router.events.subscribe((val) => {
      const url = _location.path();
      if (this.previousUrl) {
        if ((this.previousUrl.indexOf('/complete-booking') > -1) && (url.indexOf('/dashboard') > -1)) {
          this._sharedDataService.setBkngURL(true);
        } else if ((this.previousUrl.indexOf('/complete-booking') === -1) && (url.indexOf('/dashboard') === -1)) {
          this._sharedDataService.setBkngURL(false);
        }
      }
      this.previousUrl = url;
    }));

  }

  ngOnInit() {
    this.setGoogleMapsScriptTag();
    window.scrollTo(0, 0);
    this.isBrowserNonSupport = (navigator.appName === 'Microsoft Internet Explorer' || !!(navigator.userAgent.match(/Trident/)
      || navigator.userAgent.match(/rv:11/)));
    if (!this.isBrowserNonSupport) {
      this.callToken();
      if (!this.loginsuccess && localStorage.getItem('isLoggedIn') === 'true') {
        if (!this.getURL().includes(ConstantsURL.CONST_PRINT_URL)) {
          this.checkforActcFailure();
        }
      }
      this.sessionTimeout();
    } else {
      localStorage.clear();
      sessionStorage.clear();
    }
    this.checkPrintUrl();
  }

  ngOnDestroy() {
    this._cd.detach();
    this.subscriptions.forEach((subscription: Subscription) => { subscription.unsubscribe(); });
    Object.keys(this.apiSubscription).forEach(apiName => { this.apiUnsubscribe(apiName); });
  }

  setGoogleMapsScriptTag() {
    const scriptElement = document.createElement('script');
    scriptElement.id = ConstantsURL_Others.GOOGLE_SCRIPT_TAG;
    scriptElement.src = ConstantsURL_Others.GOOGLE_MAP_SCRIPT;
    document.getElementsByTagName('head')[0].appendChild(scriptElement);
  }

  getURL() {
    let url = window.location.href;
    try { url = url.slice(url.indexOf('#') + 1, url.length); } catch (error) { }
    return url;
  }

  getBaseURL() {
    let url = window.location.href;
    try { url = url.slice(0, url.indexOf('#') + 1); } catch (error) { }
    return url;
  }

  ngOnChanges() {
    this.checkPrintUrl();
  }

  checkPrintUrl() {
    if (this.getURL().includes(ConstantsURL.CONST_PRINT_URL)) {
      this.hideHeaderFooter = true;
      this._cd.detectChanges();
    }
  }

  sessionTimeout() {
    /**
     * to check the session timeout every minutes if there is no user event like
     * mouse move, key press , then timeout after 30 minutes
     */
    const IDLE_TIMEOUT = this.idleTimeoutLimit;
    let _idleSecondsTimer = null;
    let _idleSecondsCounter = 0;
    const self = this;

    document.onclick = function () { _idleSecondsCounter = 0; };
    document.onmousemove = function () { _idleSecondsCounter = 0; };
    document.onkeypress = function () { _idleSecondsCounter = 0; };
    _idleSecondsTimer = window.setInterval(CheckIdleTime, 1 * ConstantsVAR.MINUTES_1);    // min * sec * milisec = minutes

    function CheckIdleTime() {
      _idleSecondsCounter++;
      if (_idleSecondsCounter >= IDLE_TIMEOUT) {
        window.clearInterval(_idleSecondsTimer);
        try { sessionStorage.removeItem('returnEdiURL'); } catch (err) { }
        if (localStorage.getItem('isLoggedIn')) {
          if (localStorage.getItem('isLoggedIn') === 'true') {
            self.logout('TIMEOUT');
          }
        }
      }
    }
  }

  callToken() {
    /**
     * call access_token, tnt_token, fdx_token if the validity of the tokens are over
     */

    this.checkAndUpdateTokenOnExpiry(ConstantsVAR.ACCESS_TOKEN_API, ConstantsVAR.ACCESS_TOKEN, TokenProperty.OAUTH.GET_TOKEN_EXPIRE_NAME);
    this.checkAndUpdateTokenOnExpiry(ConstantsVAR.FEDEX_TOKEN_API, ConstantsVAR.FEDEX_TOKEN, TokenProperty.FEDEX.GET_TOKEN_EXPIRE_NAME);
  }

  checkAndUpdateTokenOnExpiry(tokenType, tokenKey, tokenTimeKey) {
    /**
     * check for the token expiry at regular interval and recall if expired
     */
    if (localStorage.getItem(tokenKey)) {
      setInterval(() => {
        if (localStorage.getItem(tokenKey)) {
          const currentDate = new Date();
          currentDate.setMinutes(currentDate.getMinutes() + ConstantsVAR.MINUTES_5);
          const previousDate = new Date(localStorage.getItem(tokenTimeKey));
          if (previousDate <= currentDate) {
            this.assignTokenCall(tokenType);
          }
        } else {
          this.assignTokenCall(tokenType);
        }
      }, ConstantsVAR.MINUTES_1);
    } else {
      this.assignTokenCall(tokenType);
    }
  }

  assignTokenCall(tokenType) {
    /**
     * assign the token to its respective calls
     */
    const tokenProperty = this._tokenSrvce.assignTokenCallProperty(tokenType);
    this.getTokenNew(tokenType, tokenProperty);
  }

  getTokenNew(apiName, tknPrprty) {
    /**
  * to get token for service call (TNT, OAUTH, etc..,)
  * set token creation time, expiration time and token name in localstorage
  */
    this.apiUnsubscribe(apiName);
    this.isLoaderEnabled = true;
    this.subscriptions.push(this.apiSubscription[apiName] =
      this._tokenSrvce.getToken(tknPrprty.clientID, tknPrprty.clientSecret, tknPrprty.tokenURL).subscribe((data) => {
        if (data.hasOwnProperty('access_token')) {
          this._tokenSrvce.setToken(tknPrprty, data.access_token);
        }
        this.apiCallCount[apiName] = 0;
        this.isLoaderEnabled = false;
      }, error => {
        this.isLoaderEnabled = false;
        this.retryMechanism(error, apiName, '', true);
      }));
  }

  loginFailure() {
    /**
     * if the login/actc api is failed, then this section handle failure messages
     */
    localStorage.setItem('isLoggedIn', '');
    sessionStorage.setItem('logoutFlag', 'FCL');
    const ediPopup = <HTMLElement>document.getElementById(this.CloseEdiDwnld);
    try {
      document.getElementById('REMOVE_MODAL_BACKDROP').click();
      ediPopup.click();
    } catch (err) { }
    let waitTime = 0;
    if (ediPopup) {
      waitTime = ConstantsVAR.MILISEC_200;
    }
    setTimeout(() => {
      this._router.navigate(['/login']);
      this._sharedDataService.setLoginDetails(null);
      this._sharedDataService.setIsLoggedInSub(false);
    }, waitTime);
  }

  callAccounts(val) {
    /**
    * call the all account list and default account henceforth
    */
    this.accountList = [];
    if (val) {
      if (val.isManaged || val.isManaged === false) { // for no account
        const accntList = val.expandedAccounts;
        for (let i = 0; i < accntList.length; i++) {
          const accntRqstBdy = {
            'accountNumber': accntList[i].account.accountNumber
          };
          this.getAccounts(accntRqstBdy, val, accntList.length, i);
        }
      } else {
        this.logout('FCL');
      }
    } else {
      this.logout('FCL');
    }
  }

  getDefaultAccount(val) {
    /**
    * get the default account to set from list of account
    */
    if (val ? val.defaultAccount : false) {
      const accntRqstBdy = {
        'accountNumber': val.defaultAccount
      };
      const apiName = 'getDefaultAccount';
      this.apiUnsubscribe(apiName);
      this.isLoaderEnabled = true;

      this.subscriptions.push(this.apiSubscription[apiName] = this._loginService.actc(accntRqstBdy).subscribe((data) => {
        this.isLoaderEnabled = false;
        const assocAccounts = data.output.associatedAccounts;
        if (assocAccounts) {
          for (const value of assocAccounts) {
            if (ConstantsVAR.COMPANY_IDENTIFIER.includes(value.companyIdentifier)) {
              this.defaultAcc = value.accountNumber.substr(ConstantsVAR.ACCOUNT_TRIM_POS);
              localStorage.setItem(ConstantsVAR.DEF_ACC_KEY, this._jsEcd.encode(this.defaultAcc));
            }
          }
        }
        this.apiCallCount[apiName] = 0;
        const accVal = this.setAccount();
        this.isBookingsExist(accVal);
      }, error => {
        this.isLoaderEnabled = false;
        const accVal = this.setAccount();
        this.isBookingsExist(accVal);
        this.retryMechanism(error, apiName, val);
      }));
    } else {
      const accVal = this.setAccount();
      this.isBookingsExist(accVal);
    }
  }

  windowReload() {
    /**
     * Navigate to login component and change window reference url to login
     * and reload the window
     */
    const ediPopup = <HTMLElement>document.getElementById(this.CloseEdiDwnld);
    try {
      document.getElementById('REMOVE_MODAL_BACKDROP').click();
      ediPopup.click();
    } catch (err) { }
    let waitTime = 0;
    if (ediPopup) {
      waitTime = ConstantsVAR.MILISEC_200;
    }
    setTimeout(() => {
      this._router.navigate(['/login']);
      window.location.href = this.getBaseURL() + ConstantsURL.CONST_LOGIN_URL;
      window.location.reload();
    }, waitTime);
  }

  logout(flag) {
    /**
    * logout and delete localstorage and cookies
    */
    const apiName = 'logout';
    this.apiUnsubscribe(apiName);
    this.isLoaderEnabled = true;

    this.subscriptions.push(this.apiSubscription[apiName] = this._loginService.logout().subscribe((data) => {
      this.logoutHandling(flag);
      this.apiCallCount[apiName] = 0;
    }, error => {
      this.retryMechanism(error, apiName, flag);
      this.logoutHandling(flag);
    }));
  }

  logoutHandling(flag) {
    const rUrl = sessionStorage.getItem('returnEdiURL');
    this.isLoaderEnabled = false;
    this._loginService.deleteAllCookies();
    localStorage.clear();
    sessionStorage.clear();
    if (rUrl) { sessionStorage.setItem('returnEdiURL', rUrl) };
    sessionStorage.setItem('logoutFlag', flag);
    this.windowReload();
  }

  getAccounts(val, defVal, accntListLength: number, i: number) {
    /**
    * get list of account from TNT account linked
    */
    if (val) {
      const apiName = 'getAccounts' + i;
      this.apiUnsubscribe(apiName);
      this.isLoaderEnabled = true;

      this.subscriptions.push(this.apiSubscription[apiName] = this._loginService.actc(val).subscribe((data) => {
        const assocAccounts = data.output.associatedAccounts;
        if (assocAccounts) {
          for (const value of assocAccounts) {
            const acc = value.accountNumber.substr(ConstantsVAR.ACCOUNT_TRIM_POS);
            // check for unique account no. values
            if (ConstantsVAR.COMPANY_IDENTIFIER.includes(value.companyIdentifier)
              && this.accountList.indexOf(acc) === -1) {
              this.accountList.push(acc);
            }
          }
          this.noAccount = false;
          this._sharedDataService.setNoAccount(false);
          localStorage.setItem('noAccount', '');
        } else {
          this.noAccount = true;
          this._sharedDataService.setNoAccount(true);
          localStorage.setItem('noAccount', 'true');
        }
        if (i === accntListLength - 1) { this.getDefaultAccount(defVal); }
        this.apiCallCount[apiName] = 0;
      }, error => {
        this.isLoaderEnabled = false;
        const dta = { 'val': val, 'defVal': defVal };
        this.retryMechanism(error, apiName, dta);
        this.logout('ACTC');
      }));
    }
  }

  setAccount() {
    /**
     * create the account array to store in storage
     */
    if (this.defaultAcc) {
      if (this.accountList.length) {
        const acc = this.accountList.filter((val) => {
          return val === this.defaultAcc;
        });
        if (!acc || !acc.length) {
          this.accountList.push(this.defaultAcc);
        }
      } else {
        this.accountList.push(this.defaultAcc);
      }
    } else {
      if (this.accountList.length === 1) {
        localStorage.setItem(ConstantsVAR.DEF_ACC_KEY, this._jsEcd.encode(this.accountList[0]));
      }
    }

    const arr = [...this.accountList].sort();
    const filteredArray = arr.filter(function (item, pos) {
      return arr.indexOf(item) === pos;
    });

    const customerAccounts: AccountListDTO = {
      cAccNoLi: filteredArray
    };
    localStorage.setItem(ConstantsVAR.ACC_KEY, this._jsEcd.encode(JSON.stringify(customerAccounts)));
    return customerAccounts;
  }

  isBookingsExist(requestBody) {
    /**
     * check if booking is exist in the database, navigate based on the response.
     */
    if (sessionStorage.getItem('returnEdiURL')) {
      window.location.href = sessionStorage.getItem('returnEdiURL');
    } else {
      this.isLoaderEnabled = true;
      const apiName = 'isBookingsExist';
      this.apiUnsubscribe(apiName);

      this.subscriptions.push(this.apiSubscription[apiName] =
        this._bookingService.checkBkngAvailbility(requestBody).subscribe((val) => {
          this.isLoaderEnabled = false;
          if (val === 'true') {
            this.navigateBackToURL('/booking/dashboard');
          } else if (val === 'false') {
            this.navigateBackToURL('/booking/wizard');
          } else {
            this._router.navigate(['/login']);
          }
          this.apiCallCount[apiName] = 0;
        }, error => {
          this.isLoaderEnabled = false;
          this.retryMechanism(error, apiName, requestBody);
        }));
    }
  }

  navigateBackToURL(redirectUrl) {
    if (this.getURL() ? !this.getURL().includes(ConstantsURL.CONST_PRINT_URL) : false) {
      if (!this.getURL().includes(ConstantsURL.CONST_MULTIPLE_BOOKINGS_URL_WITH_PARAM)) {
        this._router.navigate([this.getURL()]);
      }
    } else {
      this._router.navigate([redirectUrl]);
    }
  }

  apiUnsubscribe(apiName) {
    if (this.apiSubscription[apiName]) { this.apiSubscription[apiName].unsubscribe(); }
  }

  retryMechanism(error, apiName, params, noBaseAPI?) {
    /**
     * to retry the api calls when there any gateway related or authentication related error comes
     */
    this.apiCallCount[apiName] = this.apiCallCount[apiName] || 1;
    this.apiCallCount[apiName]++;
    if (this._calltoken) {
      if (!noBaseAPI) { this._calltoken.callBaseService(error); }
      if (this.apiCallCount[apiName] <= ConstantsVAR.API_MAX_TRY) {
        this._calltoken.retryServiceCall(error, apiName, params);
      } else {
        this.apiCallCount[apiName] = 0;
      }
    }
  }

  retryCall(data) {
    /**
    * retry call mechanism
    */
    if (data.apiName === ConstantsVAR.FEDEX_TOKEN_API) {
      this.assignTokenCall(ConstantsVAR.FEDEX_TOKEN_API);
    }
    if (data.apiName === ConstantsVAR.ACCESS_TOKEN_API) {
      this.assignTokenCall(ConstantsVAR.ACCESS_TOKEN_API);
    }
    if (data.apiName === 'getDefaultAccount') {
      this.getDefaultAccount(data.data);
    }
    // check for 'includes' for iterative actc calls
    if (data.apiName.includes('getAccounts')) {
      this.getAccounts(data.data.val, data.data.defVal, data.data.accntListLength, data.data.i);
    }
    if (data.apiName === 'logout') {
      this.logout(data.data);
    }
    if (data.apiName === 'isBookingsExist') {
      this.isBookingsExist(data.data);
    }
    if (data.apiName === 'getFedexAccount') {
      this.getFedexAccount();
    }
  }


  checkforActcFailure() {
    this.loginsuccess = true;
    const data = this._sharedDataService.getuserDetails();

    if (data ? data['userProfile'] : false) {
      this._sharedDataService.setLoginDetails(data);
      this._sharedDataService.setIsLoggedInSub(true);
      localStorage.setItem('isLoggedIn', 'true');
      this.getFedexAccount();
      this.callAccounts(data['userProfile']);
      sessionStorage.removeItem('logoutFlag');
    } else {
      this.loginFailure();
    }
  }

  /**** FEDEX LOGIN INTEGRATION   ****/
  getFedexAccount() {
    this.isLoaderEnabled = true;
    const apiName = 'getFedexAccount';
    this.apiUnsubscribe(apiName);

    this.subscriptions.push(this.apiSubscription[apiName] =
      this._fdxLogin.getShipAdminInfoAPI().subscribe((data) => {
        this.isLoaderEnabled = false;
        this._fdxLogin.setShipAdminInfo(data);
        this.apiCallCount[apiName] = 0;
      }, error => {
        // this.loginFailure();
        this.isLoaderEnabled = false;
        this.retryMechanism(error, apiName, '');
      }));
  }
  /**** FEDEX LOGIN INTEGRATION   ****/

}
