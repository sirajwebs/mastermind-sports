
	
	File Name : bulletin.json


	To Update the Bulletin :

	  "message" :  <type your information message here>

	  "backgroundColor" --options :

		"red"     : This is a high priority/critical alert
  		"yellow"  : This is a warning alert
  		"green"   : This is a success/broadcast alert
  		"blue"    : This is a general info alert
  		"grey"    : This is a light alert


	--------------------------------------------------
  	Sample JSON :

	  {
  		"message": "Your message here",
  		"backgroundColor": "red"
  	  }





