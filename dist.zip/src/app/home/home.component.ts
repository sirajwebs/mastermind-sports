// import { DataShareService } from './../datashare.service';
// import { ApicallService } from './../apicall.service';
import { Component, OnInit } from '@angular/core';
// import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  // providers: [ApicallService]
})

export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  
}
